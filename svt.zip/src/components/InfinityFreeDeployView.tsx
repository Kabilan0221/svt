import React, { useState } from 'react';
import { PHP_BACKEND_FILES, ExportFile } from '../services/phpBackendTemplates';
import JSZip from 'jszip';
import {
  Download,
  Copy,
  Check,
  Server,
  Database,
  Smartphone,
  ExternalLink,
  Code2,
  BookOpen,
  CheckCircle2,
  Globe,
  Terminal,
  Cpu,
} from 'lucide-react';

interface Props {
  apiConfig: { mode: 'local' | 'infinityfree'; infinityFreeApiUrl: string };
  onUpdateApiConfig: (config: { mode: 'local' | 'infinityfree'; infinityFreeApiUrl: string }) => void;
}

export const InfinityFreeDeployView: React.FC<Props> = ({
  apiConfig,
  onUpdateApiConfig,
}) => {
  const [selectedFile, setSelectedFile] = useState<ExportFile>(PHP_BACKEND_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [testLoading, setTestLoading] = useState(false);
  const [activeGuideTab, setActiveGuideTab] = useState<'walkthrough' | 'code' | 'android' | 'live_test'>('walkthrough');

  const [customApiUrl, setCustomApiUrl] = useState(apiConfig.infinityFreeApiUrl);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Add all backend files
      PHP_BACKEND_FILES.forEach((file) => {
        zip.file(file.path, file.content);
      });

      // Add a comprehensive README
      zip.file(
        'README_INFINITYFREE_HOSTING.txt',
        `========================================================================
SRI SVT TRADERS - INFINITYFREE PHP + MYSQL HOSTING DEPLOYMENT PACKAGE
========================================================================

STACK:
- Frontend: React + TypeScript + Vite (Compiled via npm run build)
- Backend: PHP 8.2 REST API with PDO Prepared Statements
- Database: MySQL / MariaDB (InnoDB engine with Foreign Keys)
- Hosting: InfinityFree (Free PHP & MySQL Web Hosting)
- Mobile: Android Kotlin WebView (com.srisvttraders.app)

QUICK DEPLOYMENT STEPS:
1. Log in to InfinityFree Client Area -> Control Panel (vPanel).
2. Go to "MySQL Databases" -> Create a new database named "svt_db".
   Note down:
   - MySQL Host Name (e.g. sql300.infinityfree.com)
   - MySQL User Name (e.g. if0_38000000)
   - MySQL Password (your hosting password)
   - MySQL Database Name (e.g. if0_38000000_svt_db)

3. Open phpMyAdmin from the InfinityFree Control Panel.
   - Select your new database.
   - Click "Import" tab -> choose 'schema.sql' from this zip -> Click "Go".
   - All 10 tables (products, invoices, production_logs, labour, etc.) will be created.

4. Open 'config/db.php' in a text editor:
   - Replace DB_HOST, DB_USER, DB_PASS, DB_NAME with your real credentials.

5. In this web application or project folder:
   - Run: npm run build
   - It will generate static production assets in the 'dist/' folder.

6. Connect via FTP (FileZilla or InfinityFree Online File Manager):
   - Navigate to /htdocs/
   - Upload the contents of 'dist/' (index.html, assets/) directly into /htdocs/
   - Upload the 'api/' and 'config/' directories directly into /htdocs/
   - Upload '.htaccess' into /htdocs/

7. Open your browser and navigate to:
   https://yourdomain.infinityfreeapp.com/

ANDROID APP (KOTLIN WEBVIEW):
- Open Android Studio -> New Project -> Empty Views Activity.
- Copy android/MainActivity.kt into your app's package.
- Copy android/AndroidManifest.xml permissions.
- Change the URL to your InfinityFree domain.
- Build APK!
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'sri-svt-traders-infinityfree-backend.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('ZIP generation failed:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const handleTestEndpoint = async () => {
    setTestLoading(true);
    setTestResult(null);
    try {
      const url = customApiUrl.endsWith('/') ? customApiUrl : `${customApiUrl}/`;
      const res = await fetch(`${url}reports.php?view=summary`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
      });
      const data = await res.json();
      setTestResult(
        `HTTP ${res.status} OK: Connected successfully to ${customApiUrl}!\nResponse: ${JSON.stringify(
          data,
          null,
          2
        )}`
      );
    } catch (err: any) {
      setTestResult(
        `Connection Notice: Direct browser cross-origin requests to InfinityFree free subdomains require CORS headers (provided in our .htaccess & db.php). Error details: ${err.message}`
      );
    } finally {
      setTestLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Module 8
            </span>
            <span className="text-xs text-slate-500">InfinityFree Hosting Hub</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
            PHP + MySQL + InfinityFree Deployment Center
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Production-ready PHP REST backend, MySQL relational schema, InfinityFree cPanel setup guide, and Android Kotlin WebView wrapper.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs transition-colors self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          {isZipping ? 'Packaging ZIP...' : 'Download Backend Package (.zip)'}
        </button>
      </div>

      {/* Architecture Match Card */}
      <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 shadow-xs">
        <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-3">
          Architecture Verified Against Handwritten Specifications:
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/60">
            <p className="text-slate-400 text-[11px]">1. Frontend</p>
            <p className="font-bold text-white mt-0.5">React + TS + Vite</p>
            <p className="text-[10px] text-emerald-400 mt-1">✓ Complete SPA Built</p>
          </div>
          <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/60">
            <p className="text-slate-400 text-[11px]">2. Backend</p>
            <p className="font-bold text-white mt-0.5">PHP 8.2 REST API</p>
            <p className="text-[10px] text-sky-400 mt-1">✓ 6 API Endpoints Ready</p>
          </div>
          <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/60">
            <p className="text-slate-400 text-[11px]">3. Database</p>
            <p className="font-bold text-white mt-0.5">MySQL Relational</p>
            <p className="text-[10px] text-amber-400 mt-1">✓ schema.sql Dump</p>
          </div>
          <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/60">
            <p className="text-slate-400 text-[11px]">4. Hosting</p>
            <p className="font-bold text-white mt-0.5">InfinityFree cPanel</p>
            <p className="text-[10px] text-purple-400 mt-1">✓ Free Host Configured</p>
          </div>
          <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/60 col-span-2 sm:col-span-1">
            <p className="text-slate-400 text-[11px]">5. Android</p>
            <p className="font-bold text-white mt-0.5">Kotlin WebView</p>
            <p className="text-[10px] text-teal-400 mt-1">✓ Native Wrapper Code</p>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-200">
        <button
          onClick={() => setActiveGuideTab('walkthrough')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors ${
            activeGuideTab === 'walkthrough'
              ? 'border-amber-500 text-slate-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          InfinityFree Step-by-Step Guide
        </button>
        <button
          onClick={() => setActiveGuideTab('code')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors ${
            activeGuideTab === 'code'
              ? 'border-amber-500 text-slate-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          PHP & MySQL Code Viewer ({PHP_BACKEND_FILES.length} Files)
        </button>
        <button
          onClick={() => setActiveGuideTab('android')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors ${
            activeGuideTab === 'android'
              ? 'border-amber-500 text-slate-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Android Kotlin WebView Wrapper
        </button>
        <button
          onClick={() => setActiveGuideTab('live_test')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors ${
            activeGuideTab === 'live_test'
              ? 'border-amber-500 text-slate-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          API Connectivity Tester
        </button>
      </div>

      {/* Tab 1: InfinityFree Walkthrough */}
      {activeGuideTab === 'walkthrough' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              How to Host "Sri SVT Traders" on InfinityFree with MySQL
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              InfinityFree is a 100% free hosting provider that gives you full PHP 8.2, free MySQL databases, phpMyAdmin, and free subdomains.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Step 1 */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-amber-400 font-bold flex items-center justify-center text-xs">
                  1
                </span>
                <h3 className="font-bold text-slate-900 text-sm">Create Free Account & Domain</h3>
              </div>
              <p className="text-slate-600 leading-relaxed">
                Visit <a href="https://infinityfree.com" target="_blank" rel="noreferrer" className="text-amber-600 font-semibold underline">infinityfree.com</a> and sign up for a free account. Create a new hosting account and choose a free domain (e.g., <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono text-[11px]">srisvttraders.infinityfreeapp.com</code>).
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-amber-400 font-bold flex items-center justify-center text-xs">
                  2
                </span>
                <h3 className="font-bold text-slate-900 text-sm">Create MySQL Database in cPanel</h3>
              </div>
              <p className="text-slate-600 leading-relaxed">
                Open your InfinityFree Control Panel (vPanel) and click <strong>MySQL Databases</strong>. Create a database named <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono text-[11px]">svt_db</code>. Note down your <strong>MySQL Host Name</strong> (e.g. <code className="font-mono">sql300.infinityfree.com</code>) and username.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-amber-400 font-bold flex items-center justify-center text-xs">
                  3
                </span>
                <h3 className="font-bold text-slate-900 text-sm">Import schema.sql via phpMyAdmin</h3>
              </div>
              <p className="text-slate-600 leading-relaxed">
                Click <strong>phpMyAdmin</strong> in your InfinityFree control panel. Select your created database, click the <strong>Import</strong> tab, select the downloaded <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono text-[11px]">schema.sql</code> file, and click <strong>Go</strong>. All tables and default data will be created!
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-900 text-amber-400 font-bold flex items-center justify-center text-xs">
                  4
                </span>
                <h3 className="font-bold text-slate-900 text-sm">Upload Frontend & PHP to /htdocs/</h3>
              </div>
              <p className="text-slate-600 leading-relaxed">
                Open the Online File Manager or FileZilla FTP. In <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono text-[11px]">/htdocs/</code>, upload the compiled <code className="font-mono">dist/</code> folder contents, the <code className="font-mono">api/</code> directory, <code className="font-mono">config/</code> directory, and <code className="font-mono">.htaccess</code>.
              </p>
            </div>
          </div>

          <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-950 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">Pre-Configured for InfinityFree Free Plan Constraints:</p>
              <p className="mt-1 leading-relaxed text-amber-900">
                Our PHP backend scripts use native PDO with standard MySQL ports (3306), handle CORS headers directly in PHP, and include an Apache <code className="font-mono font-bold">.htaccess</code> file that prevents InfinityFree 404 rewrite issues on single-page React apps.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: PHP & MySQL Code Viewer */}
      {activeGuideTab === 'code' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col md:flex-row h-[620px]">
          {/* File Sidebar */}
          <div className="w-full md:w-64 bg-slate-900 text-slate-300 border-r border-slate-800 p-3 overflow-y-auto shrink-0">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
              Backend Package Files
            </p>
            <div className="space-y-1 mt-2">
              {PHP_BACKEND_FILES.map((file) => {
                const isSelected = selectedFile.path === file.path;
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-mono transition-colors flex items-center justify-between ${
                      isSelected
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <span className="truncate">{file.path}</span>
                    <span className="text-[9px] uppercase px-1 rounded bg-slate-800 text-slate-400 shrink-0 ml-1">
                      {file.category}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-hidden">
            <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-mono text-xs font-bold text-amber-400">
                  {selectedFile.path}
                </span>
                <p className="text-[11px] text-slate-400">{selectedFile.description}</p>
              </div>

              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-white transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied!' : 'Copy Code'}
              </button>
            </div>

            <pre className="flex-1 p-4 overflow-auto text-xs font-mono leading-relaxed text-slate-300 selection:bg-amber-900">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      )}

      {/* Tab 3: Android Kotlin WebView */}
      {activeGuideTab === 'android' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div className="flex items-center gap-3">
            <Smartphone className="w-6 h-6 text-amber-600" />
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Android Kotlin + WebView App Setup
              </h2>
              <p className="text-xs text-slate-500">
                As written in your notebook ("Android - Kotlin + Android WebView"), this code wraps your web ERP into an Android application APK.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                Instructions for Android Studio:
              </h3>
              <ol className="list-decimal list-inside text-xs text-slate-600 space-y-1.5 leading-relaxed">
                <li>Open <strong>Android Studio</strong> and click <strong>New Project → Empty Views Activity</strong>.</li>
                <li>Set Language to <strong>Kotlin</strong> and Minimum SDK to <strong>API 24 (Android 7.0+)</strong>.</li>
                <li>In <code className="font-mono bg-white px-1 border border-slate-200 rounded">AndroidManifest.xml</code>, add Internet permissions and set <code className="font-mono">android:usesCleartextTraffic="true"</code>.</li>
                <li>Replace <code className="font-mono bg-white px-1 border border-slate-200 rounded">MainActivity.kt</code> with the code from our package.</li>
                <li>Set your live InfinityFree URL in <code className="font-mono bg-white px-1 border border-slate-200 rounded">val appUrl = "https://your-domain.infinityfreeapp.com/"</code>.</li>
                <li>Click <strong>Build → Build APK</strong> or run directly on your Android phone!</li>
              </ol>
            </div>

            <div className="p-3 bg-slate-950 text-slate-200 rounded-xl border border-slate-800">
              <div className="flex justify-between items-center pb-2 border-b border-slate-800 mb-2">
                <span className="font-mono text-xs text-amber-400">MainActivity.kt (Preview)</span>
              </div>
              <pre className="text-xs font-mono text-slate-300 overflow-x-auto p-2 max-h-56">
                {PHP_BACKEND_FILES.find((f) => f.path.includes('MainActivity'))?.content}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: API Connectivity Tester */}
      {activeGuideTab === 'live_test' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              InfinityFree Live API Configuration & Ping
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Switch between local simulated relational storage (default) or connect live to your InfinityFree PHP API.
            </p>
          </div>

          <div className="space-y-4 max-w-xl text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                InfinityFree API Base URL:
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={customApiUrl}
                  onChange={(e) => setCustomApiUrl(e.target.value)}
                  placeholder="https://srisvttraders.infinityfreeapp.com/api"
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs focus:outline-hidden focus:border-amber-500"
                />
                <button
                  onClick={handleTestEndpoint}
                  disabled={testLoading}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs"
                >
                  {testLoading ? 'Pinging...' : 'Test Ping'}
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Points to <code className="font-mono">/api/reports.php?view=summary</code> on your InfinityFree host.
              </p>
            </div>

            {testResult && (
              <div className="p-3 bg-slate-900 text-slate-200 rounded-lg font-mono text-xs whitespace-pre-wrap border border-slate-800">
                {testResult}
              </div>
            )}

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <h4 className="font-bold text-slate-800">Current Storage Mode:</h4>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="apiMode"
                    checked={apiConfig.mode === 'local'}
                    onChange={() => onUpdateApiConfig({ ...apiConfig, mode: 'local' })}
                    className="accent-amber-600"
                  />
                  <span className="font-semibold text-slate-800">Local Relational Storage</span>
                  <span className="text-[11px] text-slate-500">(Active in preview)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="apiMode"
                    checked={apiConfig.mode === 'infinityfree'}
                    onChange={() => onUpdateApiConfig({ ...apiConfig, mode: 'infinityfree', infinityFreeApiUrl: customApiUrl })}
                    className="accent-amber-600"
                  />
                  <span className="font-semibold text-slate-800">InfinityFree Live Endpoint</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
