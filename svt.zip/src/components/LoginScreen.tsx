import React, { useState } from 'react';
import { User, Role } from '../types';
import { StorageService } from '../services/storage';
import {
  Shield,
  KeyRound,
  UserCheck,
  Lock,
  Building2,
  CheckCircle2,
  ArrowRight,
  Eye,
  EyeOff,
  Sparkles,
} from 'lucide-react';

interface Props {
  onLoginSuccess: (user: User) => void;
}

export const LoginScreen: React.FC<Props> = ({ onLoginSuccess }) => {
  const [activePortal, setActivePortal] = useState<'owner' | 'manager'>('owner');
  const [username, setUsername] = useState('owner');
  const [password, setPassword] = useState('owner123');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handlePortalSwitch = (portal: 'owner' | 'manager') => {
    setActivePortal(portal);
    setError('');
    if (portal === 'owner') {
      setUsername('owner');
      setPassword('owner123');
    } else {
      setUsername('manager');
      setPassword('manager123');
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      const result = StorageService.login(username, password, activePortal);
      setLoading(false);

      if (result.success && result.user) {
        onLoginSuccess(result.user);
      } else {
        setError(result.error || 'Invalid credentials.');
      }
    }, 200);
  };

  const handleQuickDemoLogin = (role: 'owner' | 'manager') => {
    const userToLogin = role === 'owner' ? 'owner' : 'manager';
    const pass = role === 'owner' ? 'owner123' : 'manager123';
    setUsername(userToLogin);
    setPassword(pass);
    const result = StorageService.login(userToLogin, pass, role);
    if (result.success && result.user) {
      onLoginSuccess(result.user);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Subtle Background Glows */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-md relative z-10">
        {/* Brand Lockup */}
        <div className="text-center mb-6">
          <p className="text-[11px] font-mono tracking-widest text-amber-400 uppercase font-bold">
            || Sri Murugan Thunai ||
          </p>
          <div className="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-tr from-amber-600 to-amber-400 text-slate-950 font-black text-2xl rounded-2xl shadow-lg shadow-amber-500/20 my-2">
            SVT
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white uppercase">
            Sri SVT Traders
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Enterprise ERP & Billing Management Portal
          </p>
        </div>

        {/* Portal Login Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-md">
          {/* Two-Portals Toggle: Owner vs Manager */}
          <div className="grid grid-cols-2 p-1.5 bg-slate-950/60 border-b border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => handlePortalSwitch('owner')}
              className={`py-3 px-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${
                activePortal === 'owner'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Owner Login</span>
            </button>

            <button
              type="button"
              onClick={() => handlePortalSwitch('manager')}
              className={`py-3 px-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${
                activePortal === 'manager'
                  ? 'bg-blue-600 text-white shadow-md font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              <span>Manager Login</span>
            </button>
          </div>

          {/* Portal Information Banner */}
          <div
            className={`px-6 py-3 text-xs border-b ${
              activePortal === 'owner'
                ? 'bg-amber-500/10 border-amber-500/20 text-amber-300'
                : 'bg-blue-500/10 border-blue-500/20 text-blue-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-semibold">
                {activePortal === 'owner' ? '👑 Owner / Proprietor Portal' : '📋 Operations & Yard Manager Portal'}
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-950/40 uppercase">
                {activePortal === 'owner' ? 'Full Authority' : 'Restricted Access'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-normal">
              {activePortal === 'owner'
                ? 'Full financial access, margins, labour salary settlements & user account control.'
                : 'Trade dispatch, customer billing, stock counts, batch production & estimations.'}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Username or ID
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={activePortal === 'owner' ? 'owner' : 'manager'}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-500 transition-colors font-mono"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-300">
                  Password / Secure PIN
                </label>
                <span className="text-[11px] text-slate-500 font-mono">
                  Default: {activePortal === 'owner' ? 'owner123' : 'manager123'}
                </span>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-500 transition-colors font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer ${
                activePortal === 'owner'
                  ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }`}
            >
              <span>{loading ? 'Authenticating...' : `Sign In as ${activePortal === 'owner' ? 'Owner' : 'Manager'}`}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Access Bar */}
          <div className="px-6 py-4 bg-slate-950/80 border-t border-slate-800 text-xs">
            <p className="text-[11px] text-slate-400 font-medium mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Quick 1-Click Demo Login:</span>
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('owner')}
                className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 rounded-lg text-[11px] font-mono font-medium transition-colors text-center"
              >
                👑 S.V. Thangavel (Owner)
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('manager')}
                className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-blue-400 border border-slate-700 rounded-lg text-[11px] font-mono font-medium transition-colors text-center"
              >
                📋 R. Rajesh (Manager)
              </button>
            </div>
          </div>
        </div>

        {/* System Footer */}
        <div className="mt-6 text-center text-slate-500 text-xs">
          <span>Sri SVT Traders</span>
          <span className="mx-2">·</span>
          <span>InfinityFree PHP & MySQL Architecture</span>
        </div>
      </div>
    </div>
  );
};
