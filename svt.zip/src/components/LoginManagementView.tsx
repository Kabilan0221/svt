import React, { useState } from 'react';
import { User, Role, UserPermissions } from '../types';
import {
  Shield,
  UserCheck,
  UserPlus,
  KeyRound,
  Lock,
  Unlock,
  CheckCircle2,
  AlertTriangle,
  Edit2,
  Trash2,
  Phone,
  Calendar,
  Sparkles,
  Check,
  X,
} from 'lucide-react';

interface Props {
  users: User[];
  currentUser: User;
  onSaveUser: (user: Omit<User, 'id' | 'createdDate'> & { id?: string }) => void;
  onDeleteUser: (userId: string) => void;
  onSwitchUser: (user: User) => void;
}

export const LoginManagementView: React.FC<Props> = ({
  users,
  currentUser,
  onSaveUser,
  onDeleteUser,
  onSwitchUser,
}) => {
  const isOwner = currentUser.role === 'owner';

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // Form states
  const [formName, setFormName] = useState('');
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('manager123');
  const [formPhone, setFormPhone] = useState('');
  const [formRole, setFormRole] = useState<Role>('manager');
  const [formStatus, setFormStatus] = useState<'Active' | 'Inactive'>('Active');
  const [formPermissions, setFormPermissions] = useState<UserPermissions>({
    canManageUsers: false,
    canViewTurnoverReports: true,
    canManageLabourSalaries: false,
    canDeleteInvoices: false,
    canAdjustPrices: true,
  });

  // Self password change for manager
  const [selfNewPassword, setSelfNewPassword] = useState('');
  const [selfPasswordMessage, setSelfPasswordMessage] = useState('');

  const openAddUser = () => {
    setSelectedUser(null);
    setFormName('');
    setFormUsername('');
    setFormPassword('manager123');
    setFormPhone('');
    setFormRole('manager');
    setFormStatus('Active');
    setFormPermissions({
      canManageUsers: false,
      canViewTurnoverReports: true,
      canManageLabourSalaries: false,
      canDeleteInvoices: false,
      canAdjustPrices: true,
    });
    setIsModalOpen(true);
  };

  const openEditUser = (u: User) => {
    setSelectedUser(u);
    setFormName(u.name);
    setFormUsername(u.username);
    setFormPassword(u.password || 'manager123');
    setFormPhone(u.phone || '');
    setFormRole(u.role);
    setFormStatus(u.status);
    setFormPermissions(
      u.permissions || {
        canManageUsers: u.role === 'owner',
        canViewTurnoverReports: true,
        canManageLabourSalaries: u.role === 'owner',
        canDeleteInvoices: u.role === 'owner',
        canAdjustPrices: true,
      }
    );
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formUsername.trim()) return;

    onSaveUser({
      id: selectedUser?.id,
      name: formName.trim(),
      username: formUsername.trim().toLowerCase(),
      password: formPassword.trim(),
      role: formRole,
      phone: formPhone.trim() || undefined,
      status: formStatus,
      lastLogin: selectedUser?.lastLogin,
      permissions: {
        ...formPermissions,
        canManageUsers: formRole === 'owner', // Owner always has user management
      },
    });

    setIsModalOpen(false);
  };

  const handleSelfPasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selfNewPassword || selfNewPassword.length < 4) {
      setSelfPasswordMessage('Password must be at least 4 characters.');
      return;
    }
    onSaveUser({
      ...currentUser,
      password: selfNewPassword,
    });
    setSelfPasswordMessage('Password updated successfully!');
    setSelfNewPassword('');
    setTimeout(() => setSelfPasswordMessage(''), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Module 9
            </span>
            <span className="text-xs text-slate-500">Security & Access Control</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
            Login & User Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure Owner credentials, create Manager logins, grant granular operational permissions, and audit access.
          </p>
        </div>

        {isOwner && (
          <button
            onClick={openAddUser}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
          >
            <UserPlus className="w-4 h-4 stroke-[2.5]" />
            Provision New Login
          </button>
        )}
      </div>

      {/* Role Notice Banner */}
      {!isOwner && (
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <UserCheck className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">Manager Session Active ({currentUser.name})</p>
              <p className="mt-0.5 text-blue-800">
                You are currently signed in as a Manager. You can update your own password below. Creating or deleting other manager accounts requires Owner privileges.
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              const ownerUser = users.find((u) => u.role === 'owner');
              if (ownerUser) onSwitchUser(ownerUser);
            }}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold shrink-0 transition-colors"
          >
            Switch to Owner
          </button>
        </div>
      )}

      {/* User Accounts Overview Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Registered System Logins</h2>
            <p className="text-xs text-slate-500">Authorized personnel credentials and assigned role policies</p>
          </div>
          <span className="text-xs font-mono bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md">
            {users.length} Active Accounts
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">User Details</th>
                <th className="py-3 px-4">Username</th>
                <th className="py-3 px-4">Role Portal</th>
                <th className="py-3 px-4">Permissions Granted</th>
                <th className="py-3 px-4">Last Login</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {users.map((u) => {
                const isCurrent = u.id === currentUser.id;
                const isUserOwner = u.role === 'owner';

                return (
                  <tr key={u.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs uppercase shrink-0 ${
                            isUserOwner
                              ? 'bg-amber-500 text-slate-950 font-black'
                              : 'bg-blue-600 text-white'
                          }`}
                        >
                          {u.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                            <span>{u.name}</span>
                            {isCurrent && (
                              <span className="text-[10px] font-mono bg-slate-900 text-white px-1.5 py-0.2 rounded">
                                You
                              </span>
                            )}
                          </div>
                          {u.phone && <div className="text-[11px] text-slate-400">{u.phone}</div>}
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-slate-800">
                      @{u.username}
                    </td>

                    <td className="py-3 px-4">
                      {isUserOwner ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded">
                          <Shield className="w-3 h-3 text-amber-700" /> Owner / Proprietor
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-800 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
                          <UserCheck className="w-3 h-3 text-blue-600" /> Operations Manager
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1 max-w-xs text-[10px]">
                        {isUserOwner ? (
                          <span className="bg-slate-100 text-slate-800 px-1.5 py-0.5 rounded font-mono font-semibold">
                            Full Master Access
                          </span>
                        ) : (
                          <>
                            {u.permissions?.canViewTurnoverReports && (
                              <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">Turnover</span>
                            )}
                            {u.permissions?.canAdjustPrices && (
                              <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">Pricing</span>
                            )}
                            {u.permissions?.canDeleteInvoices ? (
                              <span className="bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded">Bill Deletion</span>
                            ) : null}
                            {u.permissions?.canManageLabourSalaries && (
                              <span className="bg-purple-50 text-purple-700 px-1.5 py-0.5 rounded">Wages</span>
                            )}
                          </>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-slate-500 whitespace-nowrap text-[11px] font-mono">
                      {u.lastLogin || 'Never'}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 text-[10px] font-semibold rounded ${
                          u.status === 'Active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {u.status}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {!isCurrent && (
                          <button
                            onClick={() => onSwitchUser(u)}
                            className="px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded transition-colors"
                          >
                            Sign In As
                          </button>
                        )}

                        {isOwner && (
                          <button
                            onClick={() => openEditUser(u)}
                            className="p-1 text-slate-500 hover:text-amber-600 rounded hover:bg-slate-100 transition-colors"
                            title="Edit User Permissions"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {isOwner && !isUserOwner && !isCurrent && (
                          <button
                            onClick={() => {
                              if (window.confirm(`Delete user ${u.name}?`)) {
                                onDeleteUser(u.id);
                              }
                            }}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition-colors"
                            title="Delete User"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manager Self-Service Password Change */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs max-w-lg">
        <div className="flex items-center gap-2 mb-2">
          <KeyRound className="w-4 h-4 text-amber-600" />
          <h3 className="text-sm font-bold text-slate-900">Change Your Password ({currentUser.name})</h3>
        </div>
        <p className="text-xs text-slate-500 mb-3">
          Update the secure password or PIN for your current account (@{currentUser.username}).
        </p>

        <form onSubmit={handleSelfPasswordChange} className="space-y-3">
          <div className="flex gap-2">
            <input
              type="password"
              required
              value={selfNewPassword}
              onChange={(e) => setSelfNewPassword(e.target.value)}
              placeholder="Enter new password"
              className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 font-mono"
            />
            <button
              type="submit"
              className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors"
            >
              Update Password
            </button>
          </div>

          {selfPasswordMessage && (
            <p className="text-xs font-semibold text-emerald-600">{selfPasswordMessage}</p>
          )}
        </form>
      </div>

      {/* Add / Edit User Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold">
                  {selectedUser ? 'Edit User Credentials & Policy' : 'Provision New System User'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. S. Senthil (Yard Supervisor)"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Username *
                  </label>
                  <input
                    type="text"
                    required
                    value={formUsername}
                    onChange={(e) => setFormUsername(e.target.value)}
                    placeholder="e.g. senthil"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Password / PIN *
                  </label>
                  <input
                    type="text"
                    required
                    value={formPassword}
                    onChange={(e) => setFormPassword(e.target.value)}
                    placeholder="e.g. manager123"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Role Portal
                  </label>
                  <select
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value as Role)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="manager">Manager (Yard & Billing)</option>
                    <option value="owner">Owner (Full Administration)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Status
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Active">Active (Can Login)</option>
                    <option value="Inactive">Inactive (Suspended)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Contact Phone
                </label>
                <input
                  type="text"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  placeholder="+91 99440..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Permission Checkboxes */}
              {formRole !== 'owner' && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                  <p className="font-bold text-slate-800">Operational Permissions for Manager:</p>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canViewTurnoverReports}
                      onChange={(e) =>
                        setFormPermissions({ ...formPermissions, canViewTurnoverReports: e.target.checked })
                      }
                      className="accent-amber-600 rounded"
                    />
                    <span>Can view turnover & monthly financial reports</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canAdjustPrices}
                      onChange={(e) =>
                        setFormPermissions({ ...formPermissions, canAdjustPrices: e.target.checked })
                      }
                      className="accent-amber-600 rounded"
                    />
                    <span>Can adjust selling & cost prices of products</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canManageLabourSalaries}
                      onChange={(e) =>
                        setFormPermissions({ ...formPermissions, canManageLabourSalaries: e.target.checked })
                      }
                      className="accent-amber-600 rounded"
                    />
                    <span>Can settle labour salary vouchers & advances</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.canDeleteInvoices}
                      onChange={(e) =>
                        setFormPermissions({ ...formPermissions, canDeleteInvoices: e.target.checked })
                      }
                      className="accent-amber-600 rounded"
                    />
                    <span className="text-rose-600 font-medium">Can delete finalized bills & invoices</span>
                  </label>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg font-medium text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow-xs"
                >
                  {selectedUser ? 'Save Changes' : 'Create User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
