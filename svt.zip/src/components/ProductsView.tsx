import React, { useState } from 'react';
import { Product, ProductUnit } from '../types';
import { Plus, Search, Edit2, Trash2 } from 'lucide-react';

interface Props {
  products: Product[];
  onSaveProduct: (product: Omit<Product, 'id' | 'lastUpdated'> & { id?: string }) => void;
  onDeleteProduct: (productId: string) => void;
  onAdjustStock: (productId: string, delta: number) => void;
}

const UNITS: ProductUnit[] = ['Bags', 'Tons', 'Pcs', 'Loads', 'Brass', 'Sq.Ft', 'Kg', 'Cft'];

export const ProductsView: React.FC<Props> = ({
  products,
  onSaveProduct,
  onDeleteProduct,
  onAdjustStock,
}) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Form states - category completely removed
  const [formName, setFormName] = useState('');
  const [formUnit, setFormUnit] = useState<ProductUnit>('Bags');
  const [formStock, setFormStock] = useState<number>(0);
  const [formPrice, setFormPrice] = useState<number>(0);
  const [formCostPrice, setFormCostPrice] = useState<number>(0);
  const [formMinStock, setFormMinStock] = useState<number>(10);

  // Adjust stock state
  const [adjustDelta, setAdjustDelta] = useState<number>(0);
  const [adjustMode, setAdjustMode] = useState<'add' | 'deduct'>('add');

  const filteredProducts = products.filter((p) => {
    return p.name.toLowerCase().includes(search.toLowerCase());
  });

  const openAddModal = () => {
    setSelectedProduct(null);
    setFormName('');
    setFormUnit('Bags');
    setFormStock(100);
    setFormPrice(400);
    setFormCostPrice(360);
    setFormMinStock(20);
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setSelectedProduct(p);
    setFormName(p.name);
    setFormUnit(p.unit);
    setFormStock(p.stockQuantity);
    setFormPrice(p.price);
    setFormCostPrice(p.costPrice);
    setFormMinStock(p.minStockLevel);
    setIsModalOpen(true);
  };

  const openStockModal = (p: Product) => {
    setSelectedProduct(p);
    setAdjustDelta(10);
    setAdjustMode('add');
    setIsAdjustModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || formPrice <= 0) return;

    onSaveProduct({
      id: selectedProduct?.id,
      name: formName.trim(),
      unit: formUnit,
      stockQuantity: Number(formStock),
      price: Number(formPrice),
      costPrice: Number(formCostPrice),
      minStockLevel: Number(formMinStock),
    });
    setIsModalOpen(false);
  };

  const handleAdjustSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || adjustDelta <= 0) return;
    const finalDelta = adjustMode === 'add' ? adjustDelta : -adjustDelta;
    onAdjustStock(selectedProduct.id, finalDelta);
    setIsAdjustModalOpen(false);
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* View Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Module 2
            </span>
            <span className="text-xs text-slate-500">Inventory Catalog</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
            Product & Stock Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure product names, measurement units (Bags, Tons, Pcs), selling rates, and stock quantities.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer w-full sm:w-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Add New Product
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by product name..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-slate-50/50"
          />
        </div>

        <span className="text-xs font-mono text-slate-500 whitespace-nowrap">
          {filteredProducts.length} Products
        </span>
      </div>

      {/* Mobile Card List: Fit to screen, no horizontal scrolling */}
      <div className="block md:hidden space-y-2.5">
        {filteredProducts.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-500">
            No products found matching "{search}".
          </div>
        ) : (
          filteredProducts.map((p) => {
            const isLow = p.stockQuantity <= p.minStockLevel;
            const isOut = p.stockQuantity === 0;

            return (
              <div
                key={p.id}
                className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs space-y-2.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{p.name}</h4>
                    <span className="text-[11px] font-mono text-slate-400">Unit: {p.unit}</span>
                  </div>
                  <div>
                    {isOut ? (
                      <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                        Out of Stock
                      </span>
                    ) : isLow ? (
                      <span className="text-[10px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                        Low Stock
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        In Stock
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Available Stock:</span>
                    <span className={`text-base font-mono font-bold ${isOut ? 'text-rose-600' : isLow ? 'text-amber-600' : 'text-slate-900'}`}>
                      {p.stockQuantity} <span className="text-xs font-normal text-slate-500">{p.unit}</span>
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 block">Selling Rate:</span>
                    <span className="text-base font-mono font-bold text-slate-900">
                      ₹{p.price.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                {/* Mobile Quick Action Buttons: Fixed & Compact */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                  <span className="text-[11px] text-slate-400 font-mono">
                    Cost: ₹{p.costPrice.toFixed(0)}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => openStockModal(p)}
                      className="px-2.5 py-1 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded text-xs font-semibold cursor-pointer"
                    >
                      ± Adjust Stock
                    </button>
                    <button
                      onClick={() => openEditModal(p)}
                      className="p-1.5 text-slate-600 hover:text-amber-600 rounded hover:bg-slate-100 cursor-pointer"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete product "${p.name}"?`)) {
                          onDeleteProduct(p.id);
                        }
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Desktop Products Table */}
      <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">#</th>
                <th className="py-3 px-4">Product Name</th>
                <th className="py-3 px-4 text-center">Unit</th>
                <th className="py-3 px-4 text-right">Available Stock</th>
                <th className="py-3 px-4 text-right">Selling Price (₹)</th>
                <th className="py-3 px-4 text-right">Cost Price (₹)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredProducts.map((p, idx) => {
                const isLow = p.stockQuantity <= p.minStockLevel;
                const isOut = p.stockQuantity === 0;

                return (
                  <tr key={p.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-400">{idx + 1}</td>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      <div className="font-semibold text-slate-900 text-sm">{p.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">ID: {p.id}</div>
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-semibold text-slate-700">
                      {p.unit}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      <div className="flex items-center justify-end gap-1.5">
                        <span className={`text-sm font-bold ${isOut ? 'text-rose-600' : isLow ? 'text-amber-600' : 'text-slate-900'}`}>
                          {p.stockQuantity}
                        </span>
                        <span className="text-slate-400 text-[11px]">{p.unit}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                      ₹{p.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-500 tabular-nums">
                      ₹{p.costPrice.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {isOut ? (
                        <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                          Out of Stock
                        </span>
                      ) : isLow ? (
                        <span className="text-[10px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          Low Stock
                        </span>
                      ) : (
                        <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          In Stock
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openStockModal(p)}
                          className="px-2 py-1 text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded text-[11px] font-medium transition-colors cursor-pointer"
                          title="Adjust Stock Quantity (+/-)"
                        >
                          Adjust
                        </button>
                        <button
                          onClick={() => openEditModal(p)}
                          className="p-1 text-slate-600 hover:text-amber-600 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                          title="Edit Product"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete product "${p.name}"?`)) {
                              onDeleteProduct(p.id);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                          title="Delete Product"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal - Fixed header, scrollable body, fixed footer */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-4 sm:px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <h3 className="text-sm font-bold tracking-tight">
                {selectedProduct ? 'Edit Product Details' : 'Add New Material / Product'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold p-1 cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSubmit} id="product-form" className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Solid Concrete Block 6-inch, M-Sand, Blue Metal"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Measurement Unit *
                </label>
                <select
                  value={formUnit}
                  onChange={(e) => setFormUnit(e.target.value as ProductUnit)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                >
                  {UNITS.map((u) => (
                    <option key={u} value={u}>
                      {u}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Stock
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={formStock}
                    onChange={(e) => setFormStock(Number(e.target.value))}
                    className="w-full px-2.5 sm:px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Selling (₹) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(Number(e.target.value))}
                    className="w-full px-2.5 sm:px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Cost (₹)
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={formCostPrice}
                    onChange={(e) => setFormCostPrice(Number(e.target.value))}
                    className="w-full px-2.5 sm:px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Low Stock Alert Threshold
                </label>
                <input
                  type="number"
                  value={formMinStock}
                  onChange={(e) => setFormMinStock(Number(e.target.value))}
                  placeholder="e.g. 20"
                  className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                />
              </div>
            </form>

            {/* Fixed Footer Buttons */}
            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="product-form"
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                {selectedProduct ? 'Save Changes' : 'Create Product'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Adjust Stock Modal */}
      {isAdjustModalOpen && selectedProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full border border-slate-200 overflow-hidden">
            <div className="px-4 sm:px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold">Quick Stock Adjustment</h3>
              <button
                onClick={() => setIsAdjustModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleAdjustSubmit} className="p-4 sm:p-5 space-y-4">
              <div>
                <p className="text-xs text-slate-500">Material:</p>
                <p className="font-bold text-slate-900 text-sm">{selectedProduct.name}</p>
                <p className="text-xs text-slate-600 font-mono mt-0.5">
                  Current: <span className="font-bold text-amber-600">{selectedProduct.stockQuantity} {selectedProduct.unit}</span>
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Adjustment Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustMode('add')}
                    className={`py-2 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                      adjustMode === 'add'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800 font-bold'
                        : 'border-slate-300 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    + Add Inward
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustMode('deduct')}
                    className={`py-2 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                      adjustMode === 'deduct'
                        ? 'bg-rose-50 border-rose-500 text-rose-800 font-bold'
                        : 'border-slate-300 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    - Deduct Damage
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Quantity ({selectedProduct.unit})
                </label>
                <input
                  type="number"
                  step="any"
                  min="0.01"
                  required
                  value={adjustDelta}
                  onChange={(e) => setAdjustDelta(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-mono font-bold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAdjustModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer"
                >
                  Apply Stock Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
