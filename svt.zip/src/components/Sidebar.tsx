import React from 'react';
import { ActiveTab, User } from '../types';
import {
  LayoutDashboard,
  Package,
  Truck,
  Factory,
  Receipt,
  FileSpreadsheet,
  BarChart3,
  Users,
  Server,
  ShieldCheck,
  LogOut,
  X,
  Building2,
  Phone,
} from 'lucide-react';

interface Props {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  currentUser: User;
  onSwitchUser: () => void;
  onLogout: () => void;
  lowStockCount: number;
}

export const Sidebar: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  isOpenMobile,
  onCloseMobile,
  currentUser,
  onSwitchUser,
  onLogout,
  lowStockCount,
}) => {
  const isOwner = currentUser.role === 'owner';

  const menuItems: { id: ActiveTab; label: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    { id: 'dashboard', label: '1. Dashboard', icon: LayoutDashboard },
    { id: 'products', label: '2. Products & Stock', icon: Package, badge: lowStockCount > 0 ? lowStockCount : undefined },
    { id: 'raw-material-inbound', label: '3. Raw Material Inbound', icon: Truck },
    { id: 'production', label: '4. Production', icon: Factory },
    { id: 'billing', label: '5. Billing', icon: Receipt },
    { id: 'estimation', label: '6. Estimation', icon: FileSpreadsheet },
    { id: 'sales-report', label: '7. Sales Report', icon: BarChart3 },
    { id: 'labour-salary', label: '8. Labour & Salary', icon: Users },
    { id: 'login-management', label: '9. Login Management', icon: ShieldCheck },
  ];

  const handleSelect = (tab: ActiveTab) => {
    setActiveTab(tab);
    onCloseMobile();
  };

  const content = (
    <div className="flex flex-col h-full bg-slate-900 text-slate-300 w-64 border-r border-slate-800">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-bold flex items-center justify-center text-sm shadow-xs">
            SVT
          </div>
          <div>
            <h2 className="text-sm font-black text-white tracking-tight leading-tight">
              ஸ்ரீ வெங்கடேஸ்வரா
            </h2>
            <p className="text-[10px] text-amber-400 font-semibold mt-0.5">
              ஹாலோ பிளாக்ஸ் (SVT)
            </p>
          </div>
        </div>

        <button
          onClick={onCloseMobile}
          className="md:hidden p-1 text-slate-400 hover:text-white rounded-md"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Navigation List */}
      <div className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
          Enterprise Modules
        </div>

        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-amber-400' : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  {item.badge} low
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* User Session Bar */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/60">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 overflow-hidden">
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs uppercase shrink-0 ${
                isOwner ? 'bg-amber-500 text-slate-950' : 'bg-blue-600 text-white'
              }`}
            >
              {currentUser.name.charAt(0)}
            </div>
            <div className="truncate">
              <p className="text-xs font-semibold text-white truncate">{currentUser.name}</p>
              <span
                className={`inline-block text-[9px] font-bold font-mono px-1 rounded uppercase ${
                  isOwner ? 'bg-amber-500/20 text-amber-300' : 'bg-blue-500/20 text-blue-300'
                }`}
              >
                {isOwner ? '👑 Owner' : '📋 Manager'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 pt-1 border-t border-slate-800/80">
          <button
            onClick={onSwitchUser}
            className="flex-1 text-[11px] font-medium text-slate-300 hover:text-white py-1 px-2 rounded bg-slate-800 hover:bg-slate-700 transition-colors text-center"
          >
            Switch Role
          </button>
          <button
            onClick={onLogout}
            className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Yard Address & Phone Info */}
      <div className="p-3 bg-slate-950 border-t border-slate-800/80 text-[10px] text-slate-400">
        <p className="font-medium text-slate-300 leading-tight">
          📍 குருவிமலை கிராமம், களக்காட்டூர் அஞ்சல், உத்திரமேரூர் ரோடு, காஞ்சிபுரம் - 631 502.
        </p>
        <p className="font-mono text-amber-400 font-bold mt-1 text-[11px]">
          📞 958578 1947, 904706 1947
        </p>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:block shrink-0 sticky top-0 h-screen">{content}</aside>

      {/* Mobile Modal Drawer */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 md:hidden bg-slate-950/70 backdrop-blur-xs flex">
          <div className="h-full animate-in slide-in-from-left duration-200">{content}</div>
          <div className="flex-1" onClick={onCloseMobile} />
        </div>
      )}
    </>
  );
};
