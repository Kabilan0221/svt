import React, { useState } from 'react';
import { Invoice, Product } from '../types';
import {
  Calendar,
  Download,
  Filter,
  TrendingUp,
  IndianRupee,
  Receipt,
  Truck,
  Layers,
} from 'lucide-react';

interface Props {
  invoices: Invoice[];
  products: Product[];
}

export const SalesReportView: React.FC<Props> = ({ invoices, products }) => {
  const [reportType, setReportType] = useState<'daily' | 'monthly' | 'product_wise'>('daily');
  const [dateRange, setDateRange] = useState<'all' | 'today' | '7days' | 'this_month' | 'custom'>('this_month');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  // Date Filtering logic
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const filteredInvoices = invoices.filter((inv) => {
    if (dateRange === 'all') return true;
    if (dateRange === 'today') return inv.date === todayStr;
    if (dateRange === '7days') return new Date(inv.date) >= sevenDaysAgo;
    if (dateRange === 'this_month') {
      const d = new Date(inv.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    }
    if (dateRange === 'custom') {
      if (customStart && inv.date < customStart) return false;
      if (customEnd && inv.date > customEnd) return false;
      return true;
    }
    return true;
  });

  // Aggregated KPIs
  const totalRevenue = filteredInvoices.reduce((sum, inv) => sum + inv.grandTotal, 0);
  const totalBills = filteredInvoices.length;
  const avgOrderValue = totalBills > 0 ? totalRevenue / totalBills : 0;
  const totalLoadingUnloading = filteredInvoices.reduce(
    (sum, inv) => sum + inv.loadingRate + inv.unloadingRate,
    0
  );

  // Group by Daily
  const dailyGroups: { [date: string]: { count: number; revenue: number; loading: number; invoices: Invoice[] } } = {};
  filteredInvoices.forEach((inv) => {
    if (!dailyGroups[inv.date]) {
      dailyGroups[inv.date] = { count: 0, revenue: 0, loading: 0, invoices: [] };
    }
    dailyGroups[inv.date].count += 1;
    dailyGroups[inv.date].revenue += inv.grandTotal;
    dailyGroups[inv.date].loading += inv.loadingRate + inv.unloadingRate;
    dailyGroups[inv.date].invoices.push(inv);
  });
  const dailyRows = Object.keys(dailyGroups)
    .sort((a, b) => b.localeCompare(a))
    .map((date) => ({ date, ...dailyGroups[date] }));

  // Group by Monthly
  const monthlyGroups: { [monthKey: string]: { count: number; revenue: number; loading: number } } = {};
  filteredInvoices.forEach((inv) => {
    const d = new Date(inv.date);
    const key = `${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`;
    if (!monthlyGroups[key]) {
      monthlyGroups[key] = { count: 0, revenue: 0, loading: 0 };
    }
    monthlyGroups[key].count += 1;
    monthlyGroups[key].revenue += inv.grandTotal;
    monthlyGroups[key].loading += inv.loadingRate + inv.unloadingRate;
  });
  const monthlyRows = Object.keys(monthlyGroups).map((month) => ({ month, ...monthlyGroups[month] }));

  // Group by Product-wise
  const productSalesMap: { [prodName: string]: { unit: string; totalQty: number; totalRevenue: number } } = {};
  filteredInvoices.forEach((inv) => {
    inv.items.forEach((item) => {
      if (!productSalesMap[item.productName]) {
        productSalesMap[item.productName] = { unit: item.unit, totalQty: 0, totalRevenue: 0 };
      }
      productSalesMap[item.productName].totalQty += item.quantity;
      productSalesMap[item.productName].totalRevenue += item.total;
    });
  });
  const productRows = Object.keys(productSalesMap)
    .map((name) => ({ name, ...productSalesMap[name] }))
    .sort((a, b) => b.totalRevenue - a.totalRevenue);

  // Export to CSV
  const handleExportCSV = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (reportType === 'daily') {
      csvContent += 'Date,Invoices Issued,Loading & Unloading Fees (Rs),Total Revenue (Rs)\n';
      dailyRows.forEach((r) => {
        csvContent += `"${r.date}","${r.count}","${r.loading}","${r.revenue}"\n`;
      });
    } else if (reportType === 'monthly') {
      csvContent += 'Month,Invoices Issued,Loading Fees (Rs),Total Revenue (Rs)\n';
      monthlyRows.forEach((r) => {
        csvContent += `"${r.month}","${r.count}","${r.loading}","${r.revenue}"\n`;
      });
    } else {
      csvContent += 'Product Name,Unit,Quantity Sold,Total Revenue (Rs)\n';
      productRows.forEach((r) => {
        csvContent += `"${r.name}","${r.unit}","${r.totalQty}","${r.totalRevenue}"\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sri-svt-traders-${reportType}-sales-report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* View Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Module 6
            </span>
            <span className="text-xs text-slate-500">Business Analytics</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
            Sales Reports & Turnover
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Daily, Monthly, and Product-wise sales performance with date filters and CSV spreadsheet export.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Download className="w-4 h-4" />
          Export Report (.CSV)
        </button>
      </div>

      {/* KPI Overview Summary (2-column on mobile, 4-column on desktop - fits screen) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Period Sales</span>
            <IndianRupee className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            ₹{totalRevenue.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5">Revenue collected</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Bills Issued</span>
            <Receipt className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-lg sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {totalBills}
          </div>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5">Invoices finalized</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Avg Bill Value</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-lg sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            ₹{avgOrderValue.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5">Per lorry trip</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Loading Fees</span>
            <Truck className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-lg sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            ₹{totalLoadingUnloading.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5">Handling charges</p>
        </div>
      </div>

      {/* Control Tabs & Date Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4">
        {/* Report Dimension Selector */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setReportType('daily')}
            className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-xs font-medium transition-colors text-center cursor-pointer ${
              reportType === 'daily'
                ? 'bg-white text-slate-950 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Daily Sales
          </button>
          <button
            onClick={() => setReportType('monthly')}
            className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-xs font-medium transition-colors text-center cursor-pointer ${
              reportType === 'monthly'
                ? 'bg-white text-slate-950 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Monthly Sales
          </button>
          <button
            onClick={() => setReportType('product_wise')}
            className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-xs font-medium transition-colors text-center cursor-pointer ${
              reportType === 'product_wise'
                ? 'bg-white text-slate-950 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Product Breakdown
          </button>
        </div>

        {/* Date Filter Badges */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] text-slate-400 font-medium mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            Period:
          </span>
          {[
            { id: 'today', label: 'Today' },
            { id: '7days', label: '7 Days' },
            { id: 'this_month', label: 'This Month' },
            { id: 'all', label: 'All Time' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setDateRange(item.id as any)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                dateRange === item.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Report Dynamic Content: MOBILE CARDS (Fit to screen, NO HORIZONTAL SCROLLBAR) + DESKTOP TABLE */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* --- 1. DAILY REPORT --- */}
        {reportType === 'daily' && (
          <>
            {/* Mobile Cards (Fix to screen) */}
            <div className="block md:hidden p-3 space-y-2.5">
              {dailyRows.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 italic">
                  No invoices found for the selected date criteria.
                </div>
              ) : (
                dailyRows.map((row) => (
                  <div
                    key={row.date}
                    className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-amber-600" />
                        <span className="font-mono font-bold text-xs text-slate-900">{row.date}</span>
                      </div>
                      <span className="bg-white text-slate-800 border border-slate-200 px-2 py-0.5 rounded font-mono font-bold text-[11px]">
                        {row.count} bills issued
                      </span>
                    </div>

                    <div className="bg-white p-2.5 rounded-lg border border-slate-200/80 flex items-center justify-between">
                      <span className="text-xs text-slate-500">Gross Day Sales:</span>
                      <span className="text-base font-mono font-bold text-slate-950">
                        ₹{row.revenue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-500 pt-1">
                      <div>
                        <span>Loading/Unloading:</span>
                        <strong className="block font-mono text-slate-800">₹{row.loading.toFixed(2)}</strong>
                      </div>
                      <div className="text-right">
                        <span>Avg / Invoice:</span>
                        <strong className="block font-mono text-slate-800">
                          ₹{(row.revenue / row.count).toFixed(2)}
                        </strong>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4 text-center">Invoices Count</th>
                    <th className="py-3 px-4 text-right">Loading & Unloading (₹)</th>
                    <th className="py-3 px-4 text-right">Gross Day Sales (₹)</th>
                    <th className="py-3 px-4 text-right">Average / Invoice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {dailyRows.map((row) => (
                    <tr key={row.date} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{row.date}</td>
                      <td className="py-3 px-4 text-center font-mono">
                        <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded font-semibold">
                          {row.count} bills
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                        ₹{row.loading.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                        ₹{row.revenue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                        ₹{(row.revenue / row.count).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                  {dailyRows.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400 italic">
                        No invoices found for the selected date criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* --- 2. MONTHLY REPORT --- */}
        {reportType === 'monthly' && (
          <>
            {/* Mobile Cards (Fix to screen) */}
            <div className="block md:hidden p-3 space-y-2.5">
              {monthlyRows.map((row) => (
                <div
                  key={row.month}
                  className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-900">{row.month}</span>
                    <span className="bg-white text-slate-800 border border-slate-200 px-2 py-0.5 rounded font-mono font-bold text-[11px]">
                      {row.count} Invoices
                    </span>
                  </div>

                  <div className="bg-white p-2.5 rounded-lg border border-slate-200/80 flex items-center justify-between">
                    <span className="text-xs text-slate-500">Monthly Turnover:</span>
                    <span className="text-base font-mono font-bold text-slate-950">
                      ₹{row.revenue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-500 pt-1 flex justify-between">
                    <span>Loading & Labour Charges:</span>
                    <strong className="font-mono text-slate-800">₹{row.loading.toFixed(2)}</strong>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                    <th className="py-3 px-4">Billing Month</th>
                    <th className="py-3 px-4 text-center">Total Invoices</th>
                    <th className="py-3 px-4 text-right">Total Loading Charges (₹)</th>
                    <th className="py-3 px-4 text-right">Total Monthly Turnover (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {monthlyRows.map((row) => (
                    <tr key={row.month} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">{row.month}</td>
                      <td className="py-3 px-4 text-center font-mono font-semibold">{row.count}</td>
                      <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                        ₹{row.loading.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                        ₹{row.revenue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* --- 3. PRODUCT BREAKDOWN REPORT --- */}
        {reportType === 'product_wise' && (
          <>
            {/* Mobile Cards (Fix to screen) */}
            <div className="block md:hidden p-3 space-y-2.5">
              {productRows.map((row) => {
                const percent = totalRevenue > 0 ? ((row.totalRevenue / totalRevenue) * 100).toFixed(1) : '0';
                return (
                  <div
                    key={row.name}
                    className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-bold text-slate-900">{row.name}</h4>
                      <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                        {percent}% Share
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 bg-white p-2.5 rounded-lg border border-slate-200/80">
                      <div>
                        <span className="text-[10px] text-slate-500 block">Sold Volume:</span>
                        <span className="text-sm font-mono font-bold text-slate-800">
                          {row.totalQty.toLocaleString()} {row.unit}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">Revenue:</span>
                        <span className="text-sm font-mono font-bold text-emerald-700">
                          ₹{row.totalRevenue.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                    <th className="py-3 px-4">#</th>
                    <th className="py-3 px-4">Product / Trade Material</th>
                    <th className="py-3 px-4 text-center">Unit</th>
                    <th className="py-3 px-4 text-right">Total Quantity Sold</th>
                    <th className="py-3 px-4 text-right">Total Revenue Generated (₹)</th>
                    <th className="py-3 px-4 text-right">Revenue Share</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {productRows.map((row, idx) => {
                    const percent = totalRevenue > 0 ? ((row.totalRevenue / totalRevenue) * 100).toFixed(1) : '0';
                    return (
                      <tr key={row.name} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3 px-4 font-mono text-slate-400">{idx + 1}</td>
                        <td className="py-3 px-4 font-semibold text-slate-900">{row.name}</td>
                        <td className="py-3 px-4 text-center font-mono text-slate-600">{row.unit}</td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-800 tabular-nums">
                          {row.totalQty.toLocaleString()} {row.unit}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-amber-600 tabular-nums">
                          ₹{row.totalRevenue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                          {percent}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
