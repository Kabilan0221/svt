import React, { useState, useMemo } from 'react';
import { InboundEntry, Product, ProductUnit } from '../types';
import {
  Truck,
  Plus,
  Search,
  Filter,
  DollarSign,
  Package,
  Calendar,
  Phone,
  Trash2,
  Printer,
  CheckCircle2,
  AlertCircle,
  Clock,
  FileSpreadsheet,
  Building2,
  ChevronRight,
  ShieldCheck,
  X,
  ArrowUpDown,
  Download,
} from 'lucide-react';

interface Props {
  inbounds: InboundEntry[];
  products: Product[];
  onAddInbound: (inb: Omit<InboundEntry, 'id' | 'createdAt'>) => void;
  onDeleteInbound: (id: string) => void;
  onUpdateInboundPayment: (id: string, status: InboundEntry['paymentStatus']) => void;
}

export const RawMaterialInboundView: React.FC<Props> = ({
  inbounds,
  products,
  onAddInbound,
  onDeleteInbound,
  onUpdateInboundPayment,
}) => {
  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Paid' | 'Unpaid' | 'Partial'>('All');
  const [selectedProductId, setSelectedProductId] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest-cost'>('newest');

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedInboundForSlip, setSelectedInboundForSlip] = useState<InboundEntry | null>(null);

  // New Inbound Form State
  const [formDate, setFormDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [formSupplier, setFormSupplier] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formVehicle, setFormVehicle] = useState('');
  const [formProductId, setFormProductId] = useState('');
  const [formCustomName, setFormCustomName] = useState('');
  const [formUnit, setFormUnit] = useState<ProductUnit>('Tons');
  const [formQuantity, setFormQuantity] = useState<number | ''>('');
  const [formCostPerUnit, setFormCostPerUnit] = useState<number | ''>('');
  const [formUnloadingRate, setFormUnloadingRate] = useState<number | ''>('');
  const [formPaymentStatus, setFormPaymentStatus] = useState<InboundEntry['paymentStatus']>('Paid');
  const [formNotes, setFormNotes] = useState('');

  // Raw materials list from products
  const rawMaterialProducts = useMemo(() => {
    return products.filter((p) => {
      const cat = (p.category || '').toLowerCase();
      const name = p.name.toLowerCase();
      return (
        cat.includes('cement') ||
        cat.includes('sand') ||
        cat.includes('aggregate') ||
        cat.includes('raw') ||
        name.includes('cement') ||
        name.includes('sand') ||
        name.includes('gravel') ||
        name.includes('dust') ||
        p.unit === 'Tons' ||
        p.unit === 'Loads' ||
        p.unit === 'Brass' ||
        p.unit === 'Bags'
      );
    });
  }, [products]);

  // Handle open add modal prefilled with product if needed
  const handleOpenAddModal = (prefillProductId?: string) => {
    setFormDate(new Date().toISOString().split('T')[0]);
    setFormSupplier('');
    setFormPhone('');
    setFormVehicle('');
    setFormQuantity('');
    setFormUnloadingRate('');
    setFormPaymentStatus('Paid');
    setFormNotes('');

    if (prefillProductId) {
      const targetProd = products.find((p) => p.id === prefillProductId);
      if (targetProd) {
        setFormProductId(targetProd.id);
        setFormCustomName(targetProd.name);
        setFormUnit(targetProd.unit);
        setFormCostPerUnit(targetProd.costPrice || '');
      }
    } else if (rawMaterialProducts.length > 0) {
      const first = rawMaterialProducts[0];
      setFormProductId(first.id);
      setFormCustomName(first.name);
      setFormUnit(first.unit);
      setFormCostPerUnit(first.costPrice || '');
    } else {
      setFormProductId('');
      setFormCustomName('');
      setFormUnit('Tons');
      setFormCostPerUnit('');
    }

    setIsAddModalOpen(true);
  };

  // KPI Calculations
  const metrics = useMemo(() => {
    const totalEntries = inbounds.length;
    const totalCost = inbounds.reduce((acc, curr) => acc + (curr.totalCost || 0), 0);
    const totalUnloading = inbounds.reduce((acc, curr) => acc + (curr.unloadingRate || 0), 0);
    const unpaidEntries = inbounds.filter((i) => i.paymentStatus === 'Unpaid');
    const partialEntries = inbounds.filter((i) => i.paymentStatus === 'Partial');
    const unpaidAmount = inbounds
      .filter((i) => i.paymentStatus === 'Unpaid')
      .reduce((acc, curr) => acc + curr.totalCost, 0);

    // Specific counts
    let cementBags = 0;
    let sandGravelTons = 0;
    inbounds.forEach((i) => {
      const name = i.productName.toLowerCase();
      if (name.includes('cement') || i.unit === 'Bags') {
        cementBags += i.quantity;
      } else if (i.unit === 'Tons' || name.includes('sand') || name.includes('gravel')) {
        sandGravelTons += i.quantity;
      }
    });

    return {
      totalEntries,
      totalCost,
      totalUnloading,
      unpaidCount: unpaidEntries.length + partialEntries.length,
      unpaidAmount,
      cementBags,
      sandGravelTons,
    };
  }, [inbounds]);

  // Filter & Sort
  const filteredInbounds = useMemo(() => {
    return inbounds
      .filter((inb) => {
        // Status filter
        if (statusFilter !== 'All' && inb.paymentStatus !== statusFilter) {
          return false;
        }
        // Product filter
        if (selectedProductId !== 'All' && inb.productId !== selectedProductId) {
          return false;
        }
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchSlip = inb.inboundNumber.toLowerCase().includes(q);
          const matchSup = inb.supplierName.toLowerCase().includes(q);
          const matchVeh = (inb.vehicleNumber || '').toLowerCase().includes(q);
          const matchProd = inb.productName.toLowerCase().includes(q);
          const matchNotes = (inb.notes || '').toLowerCase().includes(q);
          if (!matchSlip && !matchSup && !matchVeh && !matchProd && !matchNotes) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        }
        if (sortBy === 'oldest') {
          return new Date(a.date).getTime() - new Date(b.date).getTime();
        }
        if (sortBy === 'highest-cost') {
          return b.totalCost - a.totalCost;
        }
        return 0;
      });
  }, [inbounds, statusFilter, selectedProductId, searchQuery, sortBy]);

  // Auto calculate next slip number
  const nextInboundNumber = useMemo(() => {
    let max = 1000;
    inbounds.forEach((i) => {
      const parts = i.inboundNumber.split('-');
      const num = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(num) && num > max) max = num;
    });
    return `SVT-INB-${max + 1}`;
  }, [inbounds]);

  // Computed modal total
  const calculatedModalTotal = useMemo(() => {
    const q = typeof formQuantity === 'number' ? formQuantity : 0;
    const r = typeof formCostPerUnit === 'number' ? formCostPerUnit : 0;
    return q * r;
  }, [formQuantity, formCostPerUnit]);

  // Submit Handler
  const handleSaveInbound = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formCustomName || !formQuantity || !formCostPerUnit || !formSupplier) {
      alert('Please fill all required inbound delivery fields.');
      return;
    }

    const q = Number(formQuantity);
    const rate = Number(formCostPerUnit);
    const unl = formUnloadingRate ? Number(formUnloadingRate) : 0;

    onAddInbound({
      inboundNumber: nextInboundNumber,
      date: formDate,
      supplierName: formSupplier.trim(),
      supplierPhone: formPhone.trim() || undefined,
      vehicleNumber: formVehicle.trim().toUpperCase() || undefined,
      productId: formProductId || `prod-custom-${Date.now()}`,
      productName: formCustomName.trim(),
      unit: formUnit,
      quantity: q,
      costPerUnit: rate,
      totalCost: q * rate,
      unloadingRate: unl,
      paymentStatus: formPaymentStatus,
      notes: formNotes.trim() || undefined,
    });

    setIsAddModalOpen(false);
  };

  // Export CSV
  const handleExportCSV = () => {
    if (inbounds.length === 0) {
      alert('No inbound records to export.');
      return;
    }
    const headers = [
      'Inbound Number',
      'Date',
      'Material Name',
      'Supplier Name',
      'Supplier Phone',
      'Vehicle Number',
      'Quantity',
      'Unit',
      'Cost Per Unit',
      'Total Cost',
      'Unloading Charges',
      'Payment Status',
      'Notes',
    ];
    const rows = inbounds.map((i) => [
      i.inboundNumber,
      i.date,
      `"${i.productName}"`,
      `"${i.supplierName}"`,
      i.supplierPhone || '',
      i.vehicleNumber || '',
      i.quantity,
      i.unit,
      i.costPerUnit,
      i.totalCost,
      i.unloadingRate || 0,
      i.paymentStatus,
      `"${(i.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SVT_Raw_Material_Inbounds_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* --- Top Banner / Header --- */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 border border-amber-300 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                  மூலப்பொருள் கொள்முதல்
                </span>
                <span className="text-xs font-mono font-semibold text-slate-500">
                  Goods Inward Logistics
                </span>
              </div>
              <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight mt-1">
                Raw Material Inbound Management
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Record lorry load arrivals for Cement, M-Sand, P-Sand &amp; Gravel. Track raw material consignments &amp; supplier dues.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 transition-colors cursor-pointer"
              title="Download Inbounds CSV file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={() => handleOpenAddModal()}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg shadow-sm transition-all transform active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>+ Record Inbound Delivery (வரவு பதிவு)</span>
            </button>
          </div>
        </div>
      </div>

      {/* --- KPI Summary Cards --- */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Consignments</p>
            <h3 className="text-lg sm:text-xl font-black text-slate-900 mt-0.5">{metrics.totalEntries} Loads</h3>
            <span className="text-[10px] text-slate-400">Total recorded arrivals</span>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Material Spend</p>
            <h3 className="text-lg sm:text-xl font-black text-slate-900 mt-0.5">₹{metrics.totalCost.toLocaleString()}</h3>
            <span className="text-[10px] text-emerald-600 font-medium">+₹{metrics.totalUnloading.toLocaleString()} unloading</span>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Pending Supplier Dues</p>
            <h3 className="text-lg sm:text-xl font-black text-rose-600 mt-0.5">₹{metrics.unpaidAmount.toLocaleString()}</h3>
            <span className="text-[10px] text-rose-600 font-medium">{metrics.unpaidCount} unpaid/partial slips</span>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Raw Material Volume</p>
            <h3 className="text-base sm:text-lg font-black text-slate-900 mt-0.5">
              {metrics.cementBags} Bags / {metrics.sandGravelTons} Tons
            </h3>
            <span className="text-[10px] text-slate-400">Cement &amp; Sand/Gravel inward</span>
          </div>
        </div>
      </div>

      {/* --- Raw Material Reference Quick-Bar --- */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-slate-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Yard Raw Materials (களஞ்சிய மூலப்பொருட்கள்)
            </h2>
          </div>
          <span className="text-[11px] text-slate-400 hidden sm:inline">
            Click "+ Inward" to record incoming lorry load for that material
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {rawMaterialProducts.map((p) => {
            const isLow = p.stockQuantity <= p.minStockLevel;
            return (
              <div
                key={p.id}
                className={`p-2.5 rounded-lg border flex flex-col justify-between transition-colors ${
                  isLow
                    ? 'bg-rose-50/50 border-rose-300'
                    : 'bg-slate-50 border-slate-200 hover:border-amber-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400 uppercase">{p.category || 'Raw'}</span>
                    {isLow && (
                      <span className="text-[9px] font-bold text-rose-600 bg-rose-100 px-1 rounded">
                        Low
                      </span>
                    )}
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 mt-0.5 line-clamp-1" title={p.name}>
                    {p.name}
                  </h4>
                  <div className="mt-1 flex items-baseline gap-1">
                    <span className="text-base font-black text-slate-900">{p.stockQuantity}</span>
                    <span className="text-[11px] text-slate-500 font-medium">{p.unit}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleOpenAddModal(p.id)}
                  className="mt-2 w-full py-1 text-[11px] font-bold text-slate-700 hover:text-amber-700 bg-white hover:bg-amber-50 rounded border border-slate-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3 h-3 text-amber-600" />
                  <span>+ Inward</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* --- Filter & Search Toolbar --- */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-3.5 sm:p-4 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Status Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
            {(['All', 'Paid', 'Unpaid', 'Partial'] as const).map((st) => {
              const active = statusFilter === st;
              const count =
                st === 'All'
                  ? inbounds.length
                  : inbounds.filter((i) => i.paymentStatus === st).length;
              return (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    active
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st === 'All' && 'All Deliveries'}
                  {st === 'Paid' && '✓ Paid (வழங்கப்பட்டது)'}
                  {st === 'Unpaid' && '⏳ Unpaid (நிலுவை)'}
                  {st === 'Partial' && '⚠️ Partial'}
                  <span className={`ml-1.5 text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    active ? 'bg-slate-800 text-slate-200' : 'bg-white text-slate-600'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Search & Material Filter */}
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            {/* Material select */}
            <select
              value={selectedProductId}
              onChange={(e) => setSelectedProductId(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:border-amber-500"
            >
              <option value="All">All Materials</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs font-medium border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:border-amber-500"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="highest-cost">Highest Value</option>
            </select>

            {/* Search Input */}
            <div className="relative flex-1 sm:w-56">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search slip, supplier, truck..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-hidden focus:border-amber-500 font-medium"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                >
                  ×
                </button>
              )}
            </div>
          </div>
        </div>

        {/* --- Mobile Cards (< md) --- */}
        <div className="block md:hidden p-3 space-y-3">
          {filteredInbounds.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              No inbound material deliveries match your filter.
            </div>
          ) : (
            filteredInbounds.map((inb) => (
              <div
                key={inb.id}
                className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2.5 shadow-2xs"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-xs text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                        {inb.inboundNumber}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono flex items-center gap-0.5">
                        <Calendar className="w-2.5 h-2.5" />
                        {inb.date}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 mt-1">{inb.productName}</h3>
                    <div className="text-xs text-slate-600 mt-0.5">
                      <span className="font-medium text-slate-700">From: </span>
                      {inb.supplierName}
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        inb.paymentStatus === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : inb.paymentStatus === 'Partial'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-rose-100 text-rose-800 border border-rose-200'
                      }`}
                    >
                      {inb.paymentStatus}
                    </span>
                    <div className="mt-1 font-mono font-black text-sm text-slate-900">
                      ₹{inb.totalCost.toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Specs Pill row */}
                <div className="grid grid-cols-2 gap-2 text-xs bg-white p-2.5 rounded-lg border border-slate-200">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Inward Quantity</span>
                    <span className="font-black text-slate-900 text-sm">
                      {inb.quantity.toLocaleString()} {inb.unit}
                    </span>
                    <span className="text-[10px] text-slate-500 block">@ ₹{inb.costPerUnit}/{inb.unit}</span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Vehicle / Lorry</span>
                    {inb.vehicleNumber ? (
                      <span className="font-mono font-bold text-xs text-slate-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 inline-block mt-0.5">
                        🚛 {inb.vehicleNumber}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic text-xs">Direct Supply</span>
                    )}
                  </div>
                </div>

                {inb.unloadingRate ? (
                  <div className="text-[11px] text-slate-600 flex items-center justify-between px-1">
                    <span>Unloading / Labor handling:</span>
                    <span className="font-bold text-slate-900">₹{inb.unloadingRate}</span>
                  </div>
                ) : null}

                {inb.notes && (
                  <div className="text-[11px] text-slate-500 bg-slate-100/70 p-2 rounded border border-slate-200/80">
                    <span className="font-semibold text-slate-700">QC / Note: </span>
                    {inb.notes}
                  </div>
                )}

                {/* Actions Bar */}
                <div className="pt-1 flex items-center justify-between border-t border-slate-200 gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* Quick status change */}
                    <select
                      value={inb.paymentStatus}
                      onChange={(e) => onUpdateInboundPayment(inb.id, e.target.value as any)}
                      className="text-[11px] font-semibold border border-slate-200 rounded px-2 py-1 bg-white cursor-pointer"
                    >
                      <option value="Paid">Mark Paid</option>
                      <option value="Unpaid">Mark Unpaid</option>
                      <option value="Partial">Mark Partial</option>
                    </select>

                    {inb.supplierPhone && (
                      <a
                        href={`tel:${inb.supplierPhone}`}
                        className="p-1 text-slate-500 hover:text-emerald-600 rounded bg-white border border-slate-200"
                        title="Call supplier"
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedInboundForSlip(inb)}
                      className="px-2.5 py-1 text-[11px] font-bold text-slate-700 bg-white hover:bg-slate-100 rounded border border-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Printer className="w-3 h-3 text-slate-600" />
                      <span>Slip</span>
                    </button>

                    <button
                      onClick={() => {
                        if (
                          window.confirm(
                            `Delete inbound record ${inb.inboundNumber}?`
                          )
                        ) {
                          onDeleteInbound(inb.id);
                        }
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                      title="Delete record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* --- Desktop Inbound Table (>= md) --- */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Inbound #</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Raw Material</th>
                <th className="py-3 px-4">Supplier / Quarry</th>
                <th className="py-3 px-4">Vehicle / Truck</th>
                <th className="py-3 px-4 text-right">Inward Qty</th>
                <th className="py-3 px-4 text-right">Rate (₹)</th>
                <th className="py-3 px-4 text-right">Total (₹)</th>
                <th className="py-3 px-4 text-center">Payment</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredInbounds.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-xs text-slate-400">
                    No inbound material deliveries match your filter.
                  </td>
                </tr>
              ) : (
                filteredInbounds.map((inb) => (
                  <tr key={inb.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {inb.inboundNumber}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 whitespace-nowrap font-mono">
                      {inb.date}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      <div>{inb.productName}</div>
                      {inb.notes && (
                        <div className="text-[10px] text-slate-400 font-normal italic truncate max-w-xs">
                          {inb.notes}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      <div className="font-medium text-slate-900">{inb.supplierName}</div>
                      {inb.supplierPhone && (
                        <a
                          href={`tel:${inb.supplierPhone}`}
                          className="text-[11px] text-slate-500 font-mono hover:text-emerald-600 flex items-center gap-1 mt-0.5"
                        >
                          <Phone className="w-2.5 h-2.5" />
                          {inb.supplierPhone}
                        </a>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {inb.vehicleNumber ? (
                        <span className="font-mono text-[11px] font-bold text-slate-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 inline-flex items-center gap-1">
                          <span>🚛</span>
                          <span>{inb.vehicleNumber}</span>
                        </span>
                      ) : (
                        <span className="text-slate-400 italic">Direct Delivery</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="font-mono font-black text-slate-900">
                        {inb.quantity.toLocaleString()} {inb.unit}
                      </div>
                      <div className="text-[10px] text-slate-400">Received</div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-600">
                      ₹{inb.costPerUnit.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="font-mono font-black text-slate-900">
                        ₹{inb.totalCost.toLocaleString()}
                      </div>
                      {inb.unloadingRate ? (
                        <div className="text-[10px] text-slate-400">+₹{inb.unloadingRate} unl</div>
                      ) : null}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1">
                        <select
                          value={inb.paymentStatus}
                          onChange={(e) => onUpdateInboundPayment(inb.id, e.target.value as any)}
                          className={`text-[10px] font-bold uppercase rounded-md px-2 py-0.5 border cursor-pointer ${
                            inb.paymentStatus === 'Paid'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : inb.paymentStatus === 'Partial'
                              ? 'bg-amber-50 text-amber-800 border-amber-300'
                              : 'bg-rose-50 text-rose-800 border-rose-300'
                          }`}
                        >
                          <option value="Paid">✓ Paid</option>
                          <option value="Unpaid">⏳ Unpaid</option>
                          <option value="Partial">⚠️ Partial</option>
                        </select>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedInboundForSlip(inb)}
                          className="px-2 py-1 text-[11px] font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded border border-slate-200 transition-colors inline-flex items-center gap-1 cursor-pointer"
                          title="Print Inbound Goods Inward Note (GIN)"
                        >
                          <Printer className="w-3 h-3 text-slate-500" />
                          <span>GIN Slip</span>
                        </button>
                        <button
                          onClick={() => {
                            if (
                              window.confirm(
                                `Delete inbound record ${inb.inboundNumber}?`
                              )
                            ) {
                              onDeleteInbound(inb.id);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                          title="Delete Inbound Entry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info bar */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            Showing <strong className="text-slate-800">{filteredInbounds.length}</strong> of{' '}
            <strong className="text-slate-800">{inbounds.length}</strong> raw material inbound deliveries
          </span>
          <span className="font-mono font-semibold text-slate-700">
            Filtered Value: ₹
            {filteredInbounds.reduce((acc, curr) => acc + curr.totalCost, 0).toLocaleString()}
          </span>
        </div>
      </div>

      {/* --- ADD NEW INBOUND ENTRY MODAL --- */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            {/* Header */}
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <Truck className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm font-bold">New Raw Material Inbound (மூலப்பொருள் வரவு)</h3>
                  <p className="text-[11px] text-slate-400">
                    Record raw material consignment &amp; generate Goods Inward Note (GIN / வரவு சீட்டு)
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveInbound} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              {/* Slip number and date */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Inbound Slip Number (தானாக)
                  </label>
                  <input
                    type="text"
                    disabled
                    value={nextInboundNumber}
                    className="w-full px-3 py-2 text-xs font-mono font-bold bg-slate-100 border border-slate-300 rounded-lg text-slate-700 cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Arrival Date (தேதி) *
                  </label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>
              </div>

              {/* Material Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Raw Material (மூலப்பொருள்) *
                </label>
                <select
                  value={formProductId}
                  onChange={(e) => {
                    const pId = e.target.value;
                    setFormProductId(pId);
                    const found = products.find((p) => p.id === pId);
                    if (found) {
                      setFormCustomName(found.name);
                      setFormUnit(found.unit);
                      if (found.costPrice) setFormCostPerUnit(found.costPrice);
                    }
                  }}
                  className="w-full px-3 py-2 text-xs font-semibold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                >
                  <option value="">-- Choose Existing Product or Enter Below --</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.unit})
                    </option>
                  ))}
                </select>
              </div>

              {/* Custom Material Name if not found */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Material Name (பொருள் பெயர்) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. UltraTech Cement (50kg), M-Sand, 20mm Blue Metal"
                  value={formCustomName}
                  onChange={(e) => setFormCustomName(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-medium border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                />
              </div>

              {/* Supplier & Vehicle */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Supplier / Quarry / Depot Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. UltraTech Cements Depot, Cauvery Mines"
                    list="supplier-suggestions"
                    value={formSupplier}
                    onChange={(e) => setFormSupplier(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                  <datalist id="supplier-suggestions">
                    <option value="UltraTech Cements Depot (Coimbatore Plant)" />
                    <option value="Dalmia Cement Depot (Kanchipuram)" />
                    <option value="Cauvery River Sand Mines & Quarries" />
                    <option value="Kanchi Blue Metal Quarries & Crushers" />
                    <option value="Cheyyar M-Sand Quarry Supplies" />
                  </datalist>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Vehicle / Lorry Registration No (வண்டி எண்)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. TN 21 BX 4512"
                    value={formVehicle}
                    onChange={(e) => setFormVehicle(e.target.value.toUpperCase())}
                    className="w-full px-3 py-2 text-xs font-mono font-bold uppercase border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>
              </div>

              {/* Supplier phone */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Supplier / Driver Phone Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. +91 98421 99001"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                />
              </div>

              {/* Quantity, Unit, Cost */}
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Received Qty *
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0.1"
                    required
                    placeholder="e.g. 200"
                    value={formQuantity}
                    onChange={(e) => setFormQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Unit *
                  </label>
                  <select
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value as ProductUnit)}
                    className="w-full px-2.5 py-2 text-xs font-semibold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  >
                    <option value="Tons">Tons</option>
                    <option value="Bags">Bags</option>
                    <option value="Loads">Loads</option>
                    <option value="Brass">Brass</option>
                    <option value="Kg">Kg</option>
                    <option value="Pcs">Pcs</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Cost/Unit (₹) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    required
                    placeholder="e.g. 350"
                    value={formCostPerUnit}
                    onChange={(e) => setFormCostPerUnit(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>
              </div>

              {/* Unloading & Payment Status */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Unloading / Handling Charges (₹)
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    placeholder="e.g. 400"
                    value={formUnloadingRate}
                    onChange={(e) => setFormUnloadingRate(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Payment Status *
                  </label>
                  <select
                    value={formPaymentStatus}
                    onChange={(e) => setFormPaymentStatus(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs font-bold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  >
                    <option value="Paid">✓ Paid (முழுதும் வழங்கப்பட்டது)</option>
                    <option value="Unpaid">⏳ Unpaid (நிலுவை)</option>
                    <option value="Partial">⚠️ Partial (பகுதி பணம்)</option>
                  </select>
                </div>
              </div>

              {/* Total Cost Display Box */}
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs text-amber-900 font-semibold">Total Material Cost:</span>
                  <p className="text-[11px] text-amber-700">
                    {formQuantity || 0} {formUnit} × ₹{formCostPerUnit || 0}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-lg font-black font-mono text-amber-950">
                    ₹{calculatedModalTotal.toLocaleString()}
                  </span>
                  {formUnloadingRate ? (
                    <div className="text-[10px] text-amber-800">
                      +₹{Number(formUnloadingRate)} unloading = ₹
                      {(calculatedModalTotal + Number(formUnloadingRate)).toLocaleString()}
                    </div>
                  ) : null}
                </div>
              </div>

              {/* QC / Moisture Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  QC / Moisture / Lorry Notes (குறிப்பு)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Passed moisture QC test. Unloaded at Yard Bay #2."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                />
              </div>

              {/* Raw Material Inward Info */}
              <div className="text-[11px] text-amber-900 bg-amber-50 p-2.5 rounded-lg border border-amber-200 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  <strong>மூலப்பொருள் வரவு பதிவு:</strong> Recorded into raw material inward register. Used in Production to manufacture blocks/bricks.
                </span>
              </div>

              {/* Modal Buttons */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  Save Inbound Delivery (வரவு பதிவு)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- GOODS INWARD NOTE (GIN) / PRINT MODAL --- */}
      {selectedInboundForSlip && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Printer className="w-4 h-4 text-amber-400" />
                <h3 className="text-xs font-bold">Goods Inward Note (GIN / வரவு சீட்டு)</h3>
              </div>
              <button
                onClick={() => setSelectedInboundForSlip(null)}
                className="text-slate-400 hover:text-white text-lg font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Printable Content */}
            <div className="p-6 overflow-y-auto space-y-4 text-slate-900 font-sans" id="inbound-slip-print">
              {/* Slip Header */}
              <div className="text-center border-b border-slate-300 pb-3">
                <h2 className="text-base font-black tracking-wide">ஸ்ரீ வெங்கடேஸ்வரா டிரேடர்ஸ்</h2>
                <p className="text-xs font-bold text-amber-800">SRI VENKATESWARA TRADERS</p>
                <p className="text-[11px] text-slate-600">ஹாலோ பிளாக்ஸ் &amp; கட்டுமானப் பொருட்கள் உற்பத்தியாளர்</p>
                <p className="text-[10px] text-slate-500">
                  பெரியநத்தம், களக்காட்டூர் அஞ்சல், காஞ்சிபுரம் - 631 551 · போன்: 958578 1947, 904706 1947
                </p>
                <div className="inline-block mt-2 px-3 py-0.5 bg-slate-100 border border-slate-300 rounded text-xs font-mono font-bold uppercase">
                  GOODS INWARD NOTE (GIN)
                </div>
              </div>

              {/* Slip Details Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-500 text-[10px] block">SLIP NUMBER</span>
                  <span className="font-mono font-bold text-slate-900">{selectedInboundForSlip.inboundNumber}</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 text-[10px] block">ARRIVAL DATE</span>
                  <span className="font-mono font-bold text-slate-900">{selectedInboundForSlip.date}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">SUPPLIER / QUARRY</span>
                  <span className="font-bold text-slate-900">{selectedInboundForSlip.supplierName}</span>
                  {selectedInboundForSlip.supplierPhone && (
                    <span className="text-[10px] font-mono text-slate-500 block">{selectedInboundForSlip.supplierPhone}</span>
                  )}
                </div>
                <div className="text-right">
                  <span className="text-slate-500 text-[10px] block">LORRY / VEHICLE NO</span>
                  <span className="font-mono font-bold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 inline-block">
                    {selectedInboundForSlip.vehicleNumber || 'Consignment'}
                  </span>
                </div>
              </div>

              {/* Item Details Table */}
              <div className="border border-slate-300 rounded-lg overflow-hidden">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 border-b border-slate-300 font-bold text-slate-700">
                    <tr>
                      <th className="py-2 px-3">Description</th>
                      <th className="py-2 px-3 text-right">Inward Qty</th>
                      <th className="py-2 px-3 text-right">Rate (₹)</th>
                      <th className="py-2 px-3 text-right">Total (₹)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-200">
                      <td className="py-2.5 px-3 font-bold text-slate-900">
                        {selectedInboundForSlip.productName}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold">
                        {selectedInboundForSlip.quantity} {selectedInboundForSlip.unit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono">
                        ₹{selectedInboundForSlip.costPerUnit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-black">
                        ₹{selectedInboundForSlip.totalCost.toLocaleString()}
                      </td>
                    </tr>
                    {selectedInboundForSlip.unloadingRate ? (
                      <tr className="border-b border-slate-200 text-slate-600">
                        <td colSpan={3} className="py-1.5 px-3 text-right font-medium text-[11px]">
                          Unloading / Labor Charges:
                        </td>
                        <td className="py-1.5 px-3 text-right font-mono font-bold text-slate-900">
                          ₹{selectedInboundForSlip.unloadingRate.toLocaleString()}
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                  <tfoot className="bg-slate-50 font-bold">
                    <tr>
                      <td colSpan={3} className="py-2 px-3 text-right">
                        Net Consignment Value:
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-black text-slate-900 text-sm">
                        ₹{(selectedInboundForSlip.totalCost + (selectedInboundForSlip.unloadingRate || 0)).toLocaleString()}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Status and Notes */}
              <div className="flex items-center justify-between text-xs bg-slate-50 p-2.5 rounded border border-slate-200">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Payment Status</span>
                  <span className="font-bold text-slate-900">{selectedInboundForSlip.paymentStatus}</span>
                </div>
                {selectedInboundForSlip.notes && (
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 uppercase block">QC / Yard Note</span>
                    <span className="text-[11px] text-slate-700">{selectedInboundForSlip.notes}</span>
                  </div>
                )}
              </div>

              {/* Signature lines */}
              <div className="pt-8 flex items-center justify-between text-xs text-slate-600">
                <div className="text-center">
                  <div className="border-t border-slate-400 w-28 pt-1">Driver / Carrier</div>
                </div>
                <div className="text-center">
                  <div className="border-t border-slate-400 w-32 pt-1 font-bold text-slate-900">
                    Yard Supervisor / Receiver
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-3 bg-slate-100 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedInboundForSlip(null)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-1.5 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print GIN Slip</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
