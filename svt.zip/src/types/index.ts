export type Role = 'owner' | 'manager' | 'cashier';

export interface UserPermissions {
  canManageUsers: boolean;
  canViewTurnoverReports: boolean;
  canManageLabourSalaries: boolean;
  canDeleteInvoices: boolean;
  canAdjustPrices: boolean;
}

export interface User {
  id: string;
  name: string;
  username: string;
  role: Role;
  phone?: string;
  password?: string;
  status: 'Active' | 'Inactive';
  lastLogin?: string;
  createdDate: string;
  permissions: UserPermissions;
}

export type ProductUnit = 'Bags' | 'Tons' | 'Pcs' | 'Loads' | 'Brass' | 'Sq.Ft' | 'Kg' | 'Cft';

export interface Product {
  id: string;
  name: string;
  category?: string;
  unit: ProductUnit;
  stockQuantity: number;
  price: number; // Selling price per unit
  costPrice: number; // Purchase/Production cost per unit
  minStockLevel: number;
  lastUpdated: string;
}

export interface ProductionLog {
  id: string;
  productName: string;
  productId: string;
  unit: ProductUnit;
  quantity: number;
  productionDate: string; // YYYY-MM-DD
  labourName: string; // Name or crew
  labourId?: string;
  wageType?: 'Piece Rate' | 'Daily' | 'Monthly';
  labourWageRate?: number; // Rate per piece (1 pic) or per day
  totalLabourWage?: number; // Total calculated salary for this batch
  notes?: string;
  createdAt: string;
}

export interface InboundEntry {
  id: string;
  inboundNumber: string; // e.g. SVT-INB-1001
  date: string;
  supplierName: string;
  supplierPhone?: string;
  vehicleNumber?: string; // Lorry / truck registration
  productId: string;
  productName: string;
  unit: ProductUnit;
  quantity: number;
  costPerUnit: number;
  totalCost: number;
  unloadingRate?: number;
  paymentStatus: 'Paid' | 'Unpaid' | 'Partial';
  notes?: string;
  createdAt: string;
}

export interface InvoiceItem {
  id: string;
  productId: string;
  productName: string;
  unit: ProductUnit;
  rate: number;
  quantity: number;
  total: number;
}

export type PaymentMode = 'Cash' | 'UPI' | 'Bank Transfer' | 'Credit / Cheque';
export type PaymentStatus = 'Paid' | 'Partial' | 'Unpaid';

export interface Invoice {
  id: string;
  invoiceNumber: string; // e.g. SVT-INV-1025
  date: string; // YYYY-MM-DD
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  vehicleNumber?: string; // e.g. TN 38 BX 4512
  items: InvoiceItem[];
  subtotal: number;
  loadingRate: number; // Loading charge/rate
  unloadingRate: number; // Unloading charge/rate
  freightCharges: number;
  discount: number;
  taxPercent: number; // 0, 5, 12, 18
  taxAmount: number;
  grandTotal: number;
  paymentMode: PaymentMode;
  paymentStatus: PaymentStatus;
  amountPaid: number;
  balanceDue: number;
  notes?: string;
  createdAt: string;
}

export interface Estimation {
  id: string;
  estimationNumber: string; // e.g. SVT-EST-2010
  date: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  vehicleNumber?: string;
  items: InvoiceItem[];
  subtotal: number;
  loadingRate: number;
  unloadingRate: number;
  freightCharges: number;
  discount: number;
  taxPercent: number;
  taxAmount: number;
  grandTotal: number;
  status: 'Draft' | 'Pending' | 'Sent' | 'Approved' | 'Converted to Bill';
  convertedInvoiceId?: string;
  validUntil: string;
  notes?: string;
  createdAt: string;
}

export interface Labour {
  id: string;
  name: string;
  role: 'Mason' | 'Loader' | 'Machine Operator' | 'Driver' | 'Helper';
  phone: string;
  wageType: 'Piece Rate' | 'Daily' | 'Monthly';
  wageRate: number; // per piece (1 pic), per day, or per month
  joinDate: string;
  status: 'Active' | 'Inactive';
}

export interface LabourAdvance {
  id: string;
  labourId: string;
  labourName: string;
  date: string;
  amount: number;
  reason: string;
  recordedBy: string;
  status: 'Pending Deduction' | 'Deducted';
}

export interface LabourPayment {
  id: string;
  voucherNumber: string;
  labourId: string;
  labourName: string;
  paymentDate: string;
  period: string; // e.g. Oct 2026 or Week 42
  wageType?: 'Piece Rate' | 'Daily' | 'Monthly';
  daysWorked?: number;
  piecesProduced?: number;
  rateApplied?: number;
  grossAmount: number;
  advanceDeducted: number;
  netPaid: number;
  paymentMode: 'Cash' | 'UPI' | 'Bank';
  status?: 'Completed' | 'Issued' | 'Pending';
  notes?: string;
}

export type ActiveTab =
  | 'dashboard'
  | 'products'
  | 'raw-material-inbound'
  | 'production'
  | 'billing'
  | 'estimation'
  | 'sales-report'
  | 'labour-salary'
  | 'login-management'
  | 'infinityfree-deploy';
