import React, { useState } from 'react';
import { Estimation, InvoiceItem, Product } from '../types';
import {
  Plus,
  Search,
  FileSpreadsheet,
  Printer,
  Trash2,
  Calendar,
  CheckCircle2,
  ArrowRight,
  PlusCircle,
  Clock,
} from 'lucide-react';

interface Props {
  estimations: Estimation[];
  products: Product[];
  onAddEstimation: (est: Omit<Estimation, 'id' | 'createdAt'>) => void;
  onConvertToInvoice: (estimationId: string) => void;
  onUpdateStatus: (id: string, status: Estimation['status']) => void;
  onPrintEstimation: (est: Estimation) => void;
  nextEstimationNumber: string;
}

export const EstimationView: React.FC<Props> = ({
  estimations,
  products,
  onAddEstimation,
  onConvertToInvoice,
  onUpdateStatus,
  onPrintEstimation,
  nextEstimationNumber,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Form states
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [estDate, setEstDate] = useState(new Date().toISOString().split('T')[0]);
  const [validUntil, setValidUntil] = useState(
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );

  const [items, setItems] = useState<InvoiceItem[]>([
    {
      id: `eitem-${Date.now()}-1`,
      productId: products[0]?.id || '',
      productName: products[0]?.name || '',
      unit: products[0]?.unit || 'Bags',
      rate: products[0]?.price || 410,
      quantity: 100,
      total: (products[0]?.price || 410) * 100,
    },
  ]);

  const [loadingRate, setLoadingRate] = useState<number>(500);
  const [unloadingRate, setUnloadingRate] = useState<number>(500);
  const [freightCharges, setFreightCharges] = useState<number>(1500);
  const [discount, setDiscount] = useState<number>(500);
  const [taxPercent, setTaxPercent] = useState<number>(5);
  const [notes, setNotes] = useState('');

  const subtotal = items.reduce((sum, it) => sum + it.total, 0);
  const taxableBase = Math.max(0, subtotal + loadingRate + unloadingRate + freightCharges - discount);
  const taxAmount = Number(((taxableBase * taxPercent) / 100).toFixed(2));
  const grandTotal = Number((taxableBase + taxAmount).toFixed(2));

  const handleAddItem = () => {
    const defaultProd = products[0];
    if (!defaultProd) return;
    setItems((prev) => [
      ...prev,
      {
        id: `eitem-${Date.now()}-${prev.length + 1}`,
        productId: defaultProd.id,
        productName: defaultProd.name,
        unit: defaultProd.unit,
        rate: defaultProd.price,
        quantity: 20,
        total: defaultProd.price * 20,
      },
    ]);
  };

  const handleItemProductChange = (index: number, prodId: string) => {
    const selected = products.find((p) => p.id === prodId);
    if (!selected) return;
    setItems((prev) => {
      const copy = [...prev];
      copy[index] = {
        ...copy[index],
        productId: selected.id,
        productName: selected.name,
        unit: selected.unit,
        rate: selected.price,
        total: Number((selected.price * copy[index].quantity).toFixed(2)),
      };
      return copy;
    });
  };

  const handleItemQtyChange = (index: number, qty: number) => {
    setItems((prev) => {
      const copy = [...prev];
      copy[index].quantity = qty;
      copy[index].total = Number((copy[index].rate * qty).toFixed(2));
      return copy;
    });
  };

  const handleItemRateChange = (index: number, rate: number) => {
    setItems((prev) => {
      const copy = [...prev];
      copy[index].rate = rate;
      copy[index].total = Number((rate * copy[index].quantity).toFixed(2));
      return copy;
    });
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const openNewEstimateModal = () => {
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    setVehicleNumber('');
    setEstDate(new Date().toISOString().split('T')[0]);
    setValidUntil(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
    setLoadingRate(450);
    setUnloadingRate(450);
    setFreightCharges(1000);
    setDiscount(0);
    setTaxPercent(0);
    setNotes('Rates valid for 7 days. Subject to market price variations.');

    const defaultProd = products[0];
    if (defaultProd) {
      setItems([
        {
          id: `eitem-${Date.now()}-1`,
          productId: defaultProd.id,
          productName: defaultProd.name,
          unit: defaultProd.unit,
          rate: defaultProd.price,
          quantity: 100,
          total: defaultProd.price * 100,
        },
      ]);
    }
    setIsModalOpen(true);
  };

  const handleCreateEstimate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || items.length === 0) return;

    onAddEstimation({
      estimationNumber: nextEstimationNumber,
      date: estDate,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim() || undefined,
      vehicleNumber: vehicleNumber.trim() || undefined,
      items,
      subtotal,
      loadingRate: Number(loadingRate),
      unloadingRate: Number(unloadingRate),
      freightCharges: Number(freightCharges),
      discount: Number(discount),
      taxPercent: Number(taxPercent),
      taxAmount,
      grandTotal,
      status: 'Draft',
      validUntil,
      notes: notes.trim() || undefined,
    });

    setIsModalOpen(false);
  };

  const filteredEstimations = estimations.filter((est) => {
    const matchesSearch =
      est.estimationNumber.toLowerCase().includes(search.toLowerCase()) ||
      est.customerName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All' || est.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Module 5
            </span>
            <span className="text-xs text-slate-500">Price Quotations</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
            Estimation & Quotations
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Create quote estimates with materials, rates, loading/unloading charges, and convert to an official bill with 1-click.
          </p>
        </div>

        <button
          onClick={openNewEstimateModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Create New Estimate
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search estimate #, customer name..."
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-1.5">
          {['All', 'Draft', 'Pending', 'Approved', 'Converted to Bill'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                statusFilter === status
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Mobile Estimation Cards (Fit to screen, no horizontal scrolling) */}
      <div className="block md:hidden space-y-2.5">
        {filteredEstimations.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-500">
            No quotations found matching your filter.
          </div>
        ) : (
          filteredEstimations.map((est) => (
            <div
              key={est.id}
              className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs space-y-2.5"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-bold text-slate-950 text-sm">{est.estimationNumber}</span>
                    <span className="text-[10px] text-slate-400 font-mono">· {est.date}</span>
                  </div>
                  <h4 className="text-sm font-semibold text-slate-900 mt-0.5">{est.customerName}</h4>
                  {est.customerPhone && (
                    <span className="text-[11px] text-slate-500 block font-mono">{est.customerPhone}</span>
                  )}
                </div>

                <div className="text-right">
                  <span className="text-base font-mono font-bold text-slate-950 block">
                    ₹{est.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                  <span
                    className={`inline-block px-2 py-0.5 text-[10px] font-semibold rounded mt-0.5 ${
                      est.status === 'Converted to Bill'
                        ? 'bg-purple-50 text-purple-700 border border-purple-200'
                        : est.status === 'Approved'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : est.status === 'Pending'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-slate-100 text-slate-700 border border-slate-200'
                    }`}
                  >
                    {est.status}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-100">
                <span>Items: <strong className="text-slate-800">{est.items.length}</strong></span>
                <span>Handling: <strong className="text-slate-800 font-mono">₹{(est.loadingRate + est.unloadingRate).toFixed(0)}</strong></span>
                <span>Valid: <strong className="text-slate-800 font-mono">{est.validUntil}</strong></span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-100">
                {est.status !== 'Converted to Bill' && (
                  <button
                    onClick={() => {
                      if (window.confirm(`Convert Estimation ${est.estimationNumber} directly to an Official Bill? This will decrement product stock.`)) {
                        onConvertToInvoice(est.id);
                      }
                    }}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
                  >
                    Convert to Bill
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={() => onPrintEstimation(est)}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-slate-700 hover:text-slate-950 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Desktop Estimations Table */}
      <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Quote #</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Customer Name</th>
                <th className="py-3 px-4 text-right">Items</th>
                <th className="py-3 px-4 text-right">Loading / Unloading</th>
                <th className="py-3 px-4 text-right">Total Quote (₹)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredEstimations.map((est) => (
                <tr key={est.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                    {est.estimationNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">{est.date}</td>
                  <td className="py-3 px-4 font-medium text-slate-900">
                    <div>{est.customerName}</div>
                    {est.customerPhone && <div className="text-[11px] text-slate-400">{est.customerPhone}</div>}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-600">
                    {est.items.length} items
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                    ₹{(est.loadingRate + est.unloadingRate).toFixed(0)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                    ₹{est.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 text-[10px] font-semibold rounded ${
                        est.status === 'Converted to Bill'
                          ? 'bg-purple-50 text-purple-700 border border-purple-200'
                          : est.status === 'Approved'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : est.status === 'Pending'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {est.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {est.status !== 'Converted to Bill' && (
                        <button
                          onClick={() => {
                            if (window.confirm(`Convert Estimation ${est.estimationNumber} directly to an Official Bill? This will decrement product stock.`)) {
                              onConvertToInvoice(est.id);
                            }
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-slate-950 bg-amber-400 hover:bg-amber-300 rounded text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                          title="Convert to Bill"
                        >
                          Convert to Bill
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={() => onPrintEstimation(est)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-slate-700 hover:text-slate-950 bg-slate-100 hover:bg-slate-200 rounded text-xs font-medium transition-colors cursor-pointer"
                        title="Print Quote"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        Print
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Estimation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[94vh]">
            <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold tracking-tight">
                  Create Price Estimation · <span className="font-mono text-amber-400">{nextEstimationNumber}</span>
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ×
              </button>
            </div>

            <form id="new-estimate-form" onSubmit={handleCreateEstimate} className="p-3 sm:p-5 overflow-y-auto flex-1 space-y-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Radha Real Estates / Contractor"
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Customer Phone
                  </label>
                  <input
                    type="text"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="+91 98425..."
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Valid Until
                  </label>
                  <input
                    type="date"
                    required
                    value={validUntil}
                    onChange={(e) => setValidUntil(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                  />
                </div>
              </div>

              {/* Items List */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    Quoted Products & Materials
                  </h4>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="text-xs font-semibold text-amber-600 hover:text-amber-700 inline-flex items-center gap-1"
                  >
                    <PlusCircle className="w-3.5 h-3.5" /> Add Material
                  </button>
                </div>

                <div className="space-y-2">
                  {items.map((item, idx) => (
                    <div
                      key={item.id}
                      className="p-2.5 bg-slate-50/70 border border-slate-200 rounded-lg grid grid-cols-12 gap-2 items-center text-xs"
                    >
                      <div className="col-span-5">
                        <label className="text-[10px] text-slate-500 block mb-0.5">Product</label>
                        <select
                          value={item.productId}
                          onChange={(e) => handleItemProductChange(idx, e.target.value)}
                          className="w-full px-2 py-1.5 text-xs border border-slate-300 rounded bg-white"
                        >
                          {products.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} ({p.unit}) — ₹{p.price}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-500 block mb-0.5">Unit</label>
                        <input
                          type="text"
                          readOnly
                          value={item.unit}
                          className="w-full px-2 py-1.5 text-xs font-mono bg-slate-100 border border-slate-200 rounded text-center"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-500 block mb-0.5">Quantity</label>
                        <input
                          type="number"
                          step="any"
                          min="0.1"
                          required
                          value={item.quantity}
                          onChange={(e) => handleItemQtyChange(idx, Number(e.target.value))}
                          className="w-full px-2 py-1.5 text-xs font-mono font-bold border border-slate-300 rounded text-right"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-500 block mb-0.5">Rate (₹)</label>
                        <input
                          type="number"
                          step="any"
                          required
                          value={item.rate}
                          onChange={(e) => handleItemRateChange(idx, Number(e.target.value))}
                          className="w-full px-2 py-1.5 text-xs font-mono border border-slate-300 rounded text-right"
                        />
                      </div>

                      <div className="col-span-1 text-center pt-3">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          disabled={items.length <= 1}
                          className="text-slate-400 hover:text-rose-600 disabled:opacity-30 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Loading & Unloading Rates for Estimation */}
              <div className="p-3 bg-amber-50/50 rounded-lg border border-amber-200">
                <h4 className="text-xs font-bold text-amber-950 uppercase tracking-wide mb-2">
                  Estimated Loading, Unloading & Freight
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Loading Rate (₹)
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={loadingRate}
                      onChange={(e) => setLoadingRate(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-300 rounded bg-white text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Unloading Rate (₹)
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={unloadingRate}
                      onChange={(e) => setUnloadingRate(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-300 rounded bg-white text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Transport / Freight (₹)
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={freightCharges}
                      onChange={(e) => setFreightCharges(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-300 rounded bg-white text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Special Discount (₹)
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={discount}
                      onChange={(e) => setDiscount(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 text-xs font-mono border border-slate-300 rounded bg-white text-right text-emerald-700"
                    />
                  </div>
                </div>
              </div>

            </form>

            {/* Total Box & Action Buttons: Fixed to Screen at Modal Bottom */}
            <div className="p-3 sm:p-4 bg-slate-900 border-t border-slate-800 shrink-0 flex flex-col sm:flex-row items-center justify-between gap-3 text-white">
              <div className="flex items-center justify-between sm:justify-start gap-4 text-xs text-slate-300 w-full sm:w-auto">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase">Subtotal</span>
                  <span className="text-white font-mono font-bold">₹{subtotal.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-[10px] text-amber-400 block uppercase font-bold">Estimated Value</span>
                  <span className="text-lg font-bold font-mono text-amber-400">
                    ₹{grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-700 hover:border-slate-600 rounded-lg text-xs font-medium text-slate-300 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  form="new-estimate-form"
                  className="flex-1 sm:flex-none px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
                >
                  Save Estimation Quotation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
