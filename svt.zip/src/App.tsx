import React, { useState, useEffect } from 'react';
import {
  ActiveTab,
  Product,
  ProductionLog,
  Invoice,
  Estimation,
  Labour,
  LabourAdvance,
  LabourPayment,
  User,
  InboundEntry,
} from './types';
import { StorageService, ApiConfig } from './services/storage';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { ProductsView } from './components/ProductsView';
import { ProductionView } from './components/ProductionView';
import { BillingView } from './components/BillingView';
import { EstimationView } from './components/EstimationView';
import { SalesReportView } from './components/SalesReportView';
import { LabourSalaryView } from './components/LabourSalaryView';
import { RawMaterialInboundView } from './components/RawMaterialInboundView';
import { LoginManagementView } from './components/LoginManagementView';
import { InfinityFreeDeployView } from './components/InfinityFreeDeployView';
import { InvoicePrintModal } from './components/InvoicePrintModal';
import { LoginModal } from './components/LoginModal';
import { LoginScreen } from './components/LoginScreen';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(StorageService.isAuthenticated());

  // Core Relational State
  const [users, setUsers] = useState<User[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [productionLogs, setProductionLogs] = useState<ProductionLog[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [estimations, setEstimations] = useState<Estimation[]>([]);
  const [labour, setLabour] = useState<Labour[]>([]);
  const [labourAdvances, setLabourAdvances] = useState<LabourAdvance[]>([]);
  const [labourPayments, setLabourPayments] = useState<LabourPayment[]>([]);
  const [inbounds, setInbounds] = useState<InboundEntry[]>([]);
  const [currentUser, setCurrentUser] = useState<User>(StorageService.getCurrentUser());
  const [apiConfig, setApiConfig] = useState<ApiConfig>(StorageService.getApiConfig());

  // Print & Modal states
  const [selectedInvoiceForPrint, setSelectedInvoiceForPrint] = useState<Invoice | null>(null);
  const [selectedEstimationForPrint, setSelectedEstimationForPrint] = useState<Estimation | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Load from Storage
  const refreshAllData = () => {
    setUsers(StorageService.getUsers());
    setProducts(StorageService.getProducts());
    setProductionLogs(StorageService.getProductionLogs());
    setInvoices(StorageService.getInvoices());
    setEstimations(StorageService.getEstimations());
    setLabour(StorageService.getLabour());
    setLabourAdvances(StorageService.getLabourAdvances());
    setLabourPayments(StorageService.getLabourPayments());
    setInbounds(StorageService.getInbounds());
    setCurrentUser(StorageService.getCurrentUser());
    setApiConfig(StorageService.getApiConfig());
    setIsAuthenticated(StorageService.isAuthenticated());
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  // Auth Handlers
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    refreshAllData();
  };

  const handleLogout = () => {
    StorageService.logout();
    setIsAuthenticated(false);
  };

  const handleSwitchUser = (user: User) => {
    StorageService.setCurrentUser(user);
    setCurrentUser(user);
    refreshAllData();
  };

  // User Management Handlers
  const handleSaveUser = (user: Omit<User, 'id' | 'createdDate'> & { id?: string }) => {
    StorageService.saveUser(user);
    refreshAllData();
  };

  const handleDeleteUser = (userId: string) => {
    StorageService.deleteUser(userId);
    refreshAllData();
  };

  // Handlers for Products
  const handleSaveProduct = (p: Omit<Product, 'id' | 'lastUpdated'> & { id?: string }) => {
    StorageService.saveProduct(p);
    refreshAllData();
  };

  const handleDeleteProduct = (id: string) => {
    StorageService.deleteProduct(id);
    refreshAllData();
  };

  const handleAdjustStock = (id: string, delta: number) => {
    StorageService.adjustStock(id, delta);
    refreshAllData();
  };

  // Handlers for Production
  const handleAddProductionLog = (log: Omit<ProductionLog, 'id' | 'createdAt'>) => {
    StorageService.addProductionLog(log);
    refreshAllData();
  };

  const handleDeleteProductionLog = (id: string) => {
    StorageService.deleteProductionLog(id);
    refreshAllData();
  };

  // Handlers for Billing (Invoices)
  const handleAddInvoice = (inv: Omit<Invoice, 'id' | 'createdAt'>) => {
    const created = StorageService.addInvoice(inv);
    refreshAllData();
    setSelectedInvoiceForPrint(created);
  };

  const handleDeleteInvoice = (id: string) => {
    StorageService.deleteInvoice(id);
    refreshAllData();
  };

  const handleUpdatePayment = (id: string, status: Invoice['paymentStatus'], amountPaid: number) => {
    StorageService.updateInvoicePayment(id, status, amountPaid);
    refreshAllData();
  };

  // Handlers for Estimation
  const handleAddEstimation = (est: Omit<Estimation, 'id' | 'createdAt'>) => {
    const created = StorageService.addEstimation(est);
    refreshAllData();
    setSelectedEstimationForPrint(created);
  };

  const handleConvertToInvoice = (estimationId: string) => {
    const invoice = StorageService.convertEstimationToInvoice(estimationId);
    refreshAllData();
    if (invoice) {
      setSelectedInvoiceForPrint(invoice);
    }
  };

  const handleUpdateEstimationStatus = (id: string, status: Estimation['status']) => {
    StorageService.updateEstimationStatus(id, status);
    refreshAllData();
  };

  // Handlers for Labour
  const handleSaveLabour = (l: Omit<Labour, 'id'> & { id?: string }) => {
    StorageService.saveLabour(l);
    refreshAllData();
  };

  const handleAddAdvance = (adv: Omit<LabourAdvance, 'id'>) => {
    StorageService.addLabourAdvance(adv);
    refreshAllData();
  };

  const handleAddPayment = (pay: Omit<LabourPayment, 'id' | 'voucherNumber'>) => {
    StorageService.addLabourPayment(pay);
    refreshAllData();
  };

  // Handlers for Inbounds
  const handleAddInbound = (inb: Omit<InboundEntry, 'id' | 'createdAt'>) => {
    StorageService.addInbound(inb);
    refreshAllData();
  };

  const handleDeleteInbound = (id: string) => {
    StorageService.deleteInbound(id);
    refreshAllData();
  };

  // Low stock count
  const lowStockCount = products.filter((p) => p.stockQuantity <= p.minStockLevel).length;

  // If not logged in, render dedicated Owner / Manager Login Screen
  if (!isAuthenticated) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row text-slate-900 font-sans selection:bg-amber-200 overflow-x-hidden w-full max-w-full">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOpenMobile={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        currentUser={currentUser}
        onSwitchUser={() => setIsLoginModalOpen(true)}
        onLogout={handleLogout}
        lowStockCount={lowStockCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          currentUser={currentUser}
          onOpenNewBill={() => setActiveTab('billing')}
          onToggleMobileMenu={() => setMobileMenuOpen(true)}
          onLogout={handleLogout}
          apiMode={apiConfig.mode}
        />

        {/* View Content Port */}
        <main className="flex-1 p-3 sm:p-6 max-w-7xl w-full mx-auto pb-6">
          {activeTab === 'dashboard' && (
            <DashboardView
              products={products}
              productionLogs={productionLogs}
              labour={labour}
              inbounds={inbounds}
              labourPayments={labourPayments}
              labourAdvances={labourAdvances}
              onOpenNewProduction={() => setActiveTab('production')}
              onAddInbound={handleAddInbound}
              onDeleteInbound={handleDeleteInbound}
              onAddPayment={handleAddPayment}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'products' && (
            <ProductsView
              products={products}
              onSaveProduct={handleSaveProduct}
              onDeleteProduct={handleDeleteProduct}
              onAdjustStock={handleAdjustStock}
            />
          )}

          {activeTab === 'raw-material-inbound' && (
            <RawMaterialInboundView
              inbounds={inbounds}
              products={products}
              onAddInbound={handleAddInbound}
              onDeleteInbound={handleDeleteInbound}
              onUpdateInboundPayment={(id, status) => {
                StorageService.updateInboundPayment(id, status);
                refreshAllData();
              }}
            />
          )}

          {activeTab === 'production' && (
            <ProductionView
              productionLogs={productionLogs}
              products={products}
              labour={labour}
              onAddProductionLog={handleAddProductionLog}
              onDeleteProductionLog={handleDeleteProductionLog}
            />
          )}

          {activeTab === 'billing' && (
            <BillingView
              invoices={invoices}
              products={products}
              onAddInvoice={handleAddInvoice}
              onDeleteInvoice={handleDeleteInvoice}
              onUpdatePayment={handleUpdatePayment}
              onPrintInvoice={(inv) => setSelectedInvoiceForPrint(inv)}
              nextInvoiceNumber={StorageService.generateInvoiceNumber()}
            />
          )}

          {activeTab === 'estimation' && (
            <EstimationView
              estimations={estimations}
              products={products}
              onAddEstimation={handleAddEstimation}
              onConvertToInvoice={handleConvertToInvoice}
              onUpdateStatus={handleUpdateEstimationStatus}
              onPrintEstimation={(est) => setSelectedEstimationForPrint(est)}
              nextEstimationNumber={StorageService.generateEstimationNumber()}
            />
          )}

          {activeTab === 'sales-report' && (
            <SalesReportView invoices={invoices} products={products} />
          )}

          {activeTab === 'labour-salary' && (
            <LabourSalaryView
              labour={labour}
              advances={labourAdvances}
              payments={labourPayments}
              productionLogs={productionLogs}
              onSaveLabour={handleSaveLabour}
              onAddAdvance={handleAddAdvance}
              onAddPayment={handleAddPayment}
            />
          )}

          {activeTab === 'login-management' && (
            <LoginManagementView
              users={users}
              currentUser={currentUser}
              onSaveUser={handleSaveUser}
              onDeleteUser={handleDeleteUser}
              onSwitchUser={handleSwitchUser}
            />
          )}

          {activeTab === 'infinityfree-deploy' && (
            <InfinityFreeDeployView
              apiConfig={apiConfig}
              onUpdateApiConfig={(newCfg) => {
                StorageService.setApiConfig(newCfg);
                setApiConfig(newCfg);
              }}
            />
          )}
        </main>
      </div>

      {/* Invoice / Estimate Print Modal */}
      {(selectedInvoiceForPrint || selectedEstimationForPrint) && (
        <InvoicePrintModal
          invoice={selectedInvoiceForPrint || undefined}
          estimation={selectedEstimationForPrint || undefined}
          onClose={() => {
            setSelectedInvoiceForPrint(null);
            setSelectedEstimationForPrint(null);
          }}
        />
      )}

      {/* Login & Role Switcher Modal */}
      {isLoginModalOpen && (
        <LoginModal
          users={users}
          currentUser={currentUser}
          onSelectUser={handleSwitchUser}
          onClose={() => setIsLoginModalOpen(false)}
        />
      )}
    </div>
  );
}
