import React, { useState } from 'react';
import { ProductionLog, Product, Labour } from '../types';
import {
  Plus,
  Factory,
  Calendar,
  Search,
  Trash2,
  Check,
  Users,
  UserPlus,
  IndianRupee,
  Coins,
} from 'lucide-react';

interface Props {
  productionLogs: ProductionLog[];
  products: Product[];
  labour: Labour[];
  onAddProductionLog: (log: Omit<ProductionLog, 'id' | 'createdAt'>) => void;
  onDeleteProductionLog: (id: string) => void;
}

export const ProductionView: React.FC<Props> = ({
  productionLogs,
  products,
  labour,
  onAddProductionLog,
  onDeleteProductionLog,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  // Form states
  const [productId, setProductId] = useState(products[0]?.id || '');
  const [quantity, setQuantity] = useState<number>(500);
  const [productionDate, setProductionDate] = useState(new Date().toISOString().split('T')[0]);

  // Labour Salary Option (1 Piece, Daily, Monthly)
  const [wageType, setWageType] = useState<'Piece Rate' | 'Daily' | 'Monthly'>('Piece Rate');
  const [wageRate, setWageRate] = useState<number>(2.5); // Default ₹2.50 per 1 piece

  // Multi-labour selection states (BUTTON BASED ONLY - NO DROPDOWN)
  const [selectedLabourNames, setSelectedLabourNames] = useState<string[]>([
    labour[0]?.name || 'M. Chinnasamy',
  ]);
  const [customLabour, setCustomLabour] = useState('');
  const [customLaboursList, setCustomLaboursList] = useState<string[]>([]);
  const [notes, setNotes] = useState('');

  const selectedProduct = products.find((p) => p.id === productId);

  // Live calculation of batch salary
  const workerCount = Math.max(1, selectedLabourNames.length);
  let calculatedBatchSalary = 0;
  if (wageType === 'Piece Rate') {
    calculatedBatchSalary = Number((quantity * wageRate).toFixed(2));
  } else if (wageType === 'Daily') {
    calculatedBatchSalary = Number((workerCount * wageRate).toFixed(2));
  } else {
    calculatedBatchSalary = 0; // Monthly payroll
  }
  const perWorkerShare = wageType === 'Piece Rate' ? Number((calculatedBatchSalary / workerCount).toFixed(2)) : wageRate;

  const filteredLogs = productionLogs.filter((log) => {
    const matchesSearch =
      log.productName.toLowerCase().includes(search.toLowerCase()) ||
      log.labourName.toLowerCase().includes(search.toLowerCase());
    const matchesDate = !dateFilter || log.productionDate === dateFilter;
    return matchesSearch && matchesDate;
  });

  const totalBatches = productionLogs.length;
  const totalUnitsProduced = productionLogs.reduce((sum, l) => sum + l.quantity, 0);
  const totalLabourWagesPaid = productionLogs.reduce((sum, l) => sum + (l.totalLabourWage || 0), 0);

  // Toggle labour selection via button
  const handleToggleLabour = (name: string) => {
    setSelectedLabourNames((prev) => {
      if (prev.includes(name)) {
        return prev.filter((n) => n !== name);
      } else {
        return [...prev, name];
      }
    });
  };

  const handleSelectAll = () => {
    const allNames = Array.from(new Set([...labour.map((l) => l.name), ...customLaboursList]));
    setSelectedLabourNames(allNames);
  };

  const handleClearLabour = () => {
    setSelectedLabourNames([]);
  };

  const handleAddCustomWorker = () => {
    const trimmed = customLabour.trim();
    if (!trimmed) return;
    if (!customLaboursList.includes(trimmed)) {
      setCustomLaboursList((prev) => [...prev, trimmed]);
    }
    if (!selectedLabourNames.includes(trimmed)) {
      setSelectedLabourNames((prev) => [...prev, trimmed]);
    }
    setCustomLabour('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || quantity <= 0) return;

    if (selectedLabourNames.length === 0) {
      alert('Please click and select at least one labour button.');
      return;
    }

    onAddProductionLog({
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      unit: selectedProduct.unit,
      quantity: Number(quantity),
      productionDate,
      labourName: selectedLabourNames.join(', '),
      wageType,
      labourWageRate: Number(wageRate),
      totalLabourWage: calculatedBatchSalary,
      notes: notes.trim() || undefined,
    });

    setIsModalOpen(false);
    setNotes('');
    setCustomLabour('');
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* View Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Module 3
            </span>
            <span className="text-xs text-slate-500">Manufacturing & Yard Logs</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
            Production Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Log manufactured batches with multi-labour button selection, 1-piece / daily / monthly salary calculation, and auto stock updates.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer w-full sm:w-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Log Production Batch
        </button>
      </div>

      {/* Overview KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Total Batches</span>
            <Factory className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {totalBatches}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Logged manufacturing runs</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Total Manufactured</span>
            <Factory className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {totalUnitsProduced.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Blocks, bricks & yard goods</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Batch Labour Salary</span>
            <IndianRupee className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-amber-600 tabular-nums">
            ₹{totalLabourWagesPaid.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">1-pic & daily wage cost</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-medium">Labour Force</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {labour.length} workers
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Multi-labour button selection</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by product or labour..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-slate-400" />
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
          />
          {dateFilter && (
            <button
              onClick={() => setDateFilter('')}
              className="text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Mobile Card List (Fix to screen without horizontal scrolling) */}
      <div className="block md:hidden space-y-2.5">
        {filteredLogs.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-500">
            No production logs found.
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs space-y-2.5"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono text-slate-400 block">{log.productionDate}</span>
                  <h4 className="text-sm font-bold text-slate-900">{log.productName}</h4>
                </div>
                <div className="text-right">
                  <span className="text-sm font-mono font-bold text-amber-600 block">
                    +{log.quantity.toLocaleString()} {log.unit}
                  </span>
                  <button
                    onClick={() => {
                      if (window.confirm('Delete this production log? Stock quantity will be reverted.')) {
                        onDeleteProductionLog(log.id);
                      }
                    }}
                    className="text-slate-400 hover:text-rose-600 p-1 rounded hover:bg-slate-100 cursor-pointer"
                    title="Delete log"
                  >
                    <Trash2 className="w-3.5 h-3.5 inline" />
                  </button>
                </div>
              </div>

              {/* Labour Salary Detail Badge */}
              <div className="p-2 bg-amber-50/70 border border-amber-200/80 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-amber-950">
                  <Coins className="w-3.5 h-3.5 text-amber-600" />
                  <span className="font-semibold text-[11px]">
                    {log.wageType === 'Piece Rate' ? '1 Piece Rate' : log.wageType === 'Daily' ? 'Daily Wage' : 'Monthly Payroll'}
                  </span>
                  {log.labourWageRate ? (
                    <span className="text-[10px] text-amber-800 font-mono">
                      (₹{log.labourWageRate}{log.wageType === 'Piece Rate' ? '/pic' : '/day'})
                    </span>
                  ) : null}
                </div>
                <span className="font-mono font-bold text-slate-950">
                  {log.totalLabourWage ? `₹${log.totalLabourWage.toLocaleString('en-IN')}` : 'Included in Salary'}
                </span>
              </div>

              {/* Labours buttons/chips */}
              <div>
                <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  Assigned Labour Crew:
                </span>
                <div className="flex flex-wrap gap-1">
                  {log.labourName.split(',').map((name, i) => (
                    <span
                      key={i}
                      className="bg-slate-100 text-slate-800 border border-slate-200 px-2 py-0.5 rounded text-[11px] font-semibold"
                    >
                      {name.trim()}
                    </span>
                  ))}
                </div>
              </div>

              {log.notes && (
                <div className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded border border-slate-100">
                  {log.notes}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">#</th>
                <th className="py-3 px-4">Production Date</th>
                <th className="py-3 px-4">Product Name</th>
                <th className="py-3 px-4 text-center">Unit</th>
                <th className="py-3 px-4 text-right">Quantity Produced</th>
                <th className="py-3 px-4">Labour / Crew Assigned</th>
                <th className="py-3 px-4 text-right">Labour Salary</th>
                <th className="py-3 px-4">Batch Remarks</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredLogs.map((log, idx) => (
                <tr key={log.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono text-slate-400">{idx + 1}</td>
                  <td className="py-3 px-4 font-medium text-slate-900 whitespace-nowrap">
                    {log.productionDate}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-900">
                    {log.productName}
                  </td>
                  <td className="py-3 px-4 text-center font-mono font-medium text-slate-600">
                    {log.unit}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-amber-600 tabular-nums">
                    +{log.quantity.toLocaleString()} {log.unit}
                  </td>
                  <td className="py-3 px-4 text-slate-800">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {log.labourName.split(',').map((name, i) => (
                        <span
                          key={i}
                          className="bg-amber-50 text-amber-900 px-2 py-0.5 rounded text-[11px] font-semibold border border-amber-200"
                        >
                          {name.trim()}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right tabular-nums">
                    {log.totalLabourWage ? (
                      <div>
                        <span className="font-mono font-bold text-slate-900">
                          ₹{log.totalLabourWage.toLocaleString('en-IN')}
                        </span>
                        <span className="block text-[10px] text-slate-500 font-mono">
                          {log.wageType === 'Piece Rate' ? `₹${log.labourWageRate}/pic` : 'Daily'}
                        </span>
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-400">Monthly</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-500 text-[11px] max-w-xs truncate">
                    {log.notes || '—'}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => {
                        if (window.confirm('Delete this production log? Stock quantity will be reverted.')) {
                          onDeleteProductionLog(log.id);
                        }
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                      title="Revert & Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Production Batch Modal: Multi-Labour with ONLY BUTTONS + Fixed Salary (1 Pic, Daily, Monthly) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            {/* Modal Header: Fixed to screen */}
            <div className="px-4 sm:px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Factory className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold tracking-tight">Log Production Batch</h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold p-1 cursor-pointer"
                aria-label="Close modal"
              >
                ×
              </button>
            </div>

            {/* Modal Body: Scrollable */}
            <form onSubmit={handleSubmit} id="production-form" className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Product / Manufactured Item *
                </label>
                <select
                  required
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.unit}) — Current Stock: {p.stockQuantity}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Quantity Produced *
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="1"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                  />
                  {selectedProduct && (
                    <span className="text-[10px] text-slate-500 mt-0.5 block">
                      Unit: {selectedProduct.unit}
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Production Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={productionDate}
                    onChange={(e) => setProductionDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Multi-Labour Selection Area: BUTTON BASED ONLY - NO DROPDOWN */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-amber-600" />
                    <label className="text-xs font-bold text-slate-900">
                      Labour Workers (Select with Buttons) *
                    </label>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleSelectAll}
                      className="text-[11px] font-bold text-amber-700 hover:text-amber-800 bg-amber-50 hover:bg-amber-100 px-2 py-0.5 rounded cursor-pointer"
                    >
                      Select All
                    </button>
                    <span className="text-slate-300">·</span>
                    <button
                      type="button"
                      onClick={handleClearLabour}
                      className="text-[11px] text-slate-500 hover:text-slate-700 px-1 py-0.5 cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                {/* Selected Status Counter */}
                <div className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-slate-200">
                  <span className="text-[11px] font-medium text-slate-600">
                    Selected Labour Count:
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                    {selectedLabourNames.length} Labour{selectedLabourNames.length === 1 ? '' : 's'} Selected
                  </span>
                </div>

                {/* Multi-Labour Selection BUTTONS */}
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Click Worker Button to Toggle (Multi-Labour Select):
                  </p>
                  <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1">
                    {labour.map((l) => {
                      const isSelected = selectedLabourNames.includes(l.name);
                      return (
                        <button
                          type="button"
                          key={l.id}
                          onClick={() => handleToggleLabour(l.name)}
                          className={`p-2.5 rounded-xl text-left border flex items-center justify-between gap-2 transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-500 border-amber-600 text-slate-950 font-bold shadow-xs ring-2 ring-amber-400/40'
                              : 'bg-white border-slate-300 text-slate-700 hover:border-slate-400 hover:bg-slate-100/60'
                          }`}
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-bold truncate leading-tight">
                              {l.name}
                            </div>
                            <div className={`text-[10px] ${isSelected ? 'text-slate-900/80 font-medium' : 'text-slate-500'}`}>
                              {l.role}
                            </div>
                          </div>
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                            isSelected ? 'bg-slate-950 text-white' : 'bg-slate-100 text-slate-400 border border-slate-200'
                          }`}>
                            {isSelected ? (
                              <Check className="w-3 h-3 stroke-[3]" />
                            ) : (
                              <Plus className="w-3 h-3" />
                            )}
                          </div>
                        </button>
                      );
                    })}

                    {/* Custom added labours if any */}
                    {customLaboursList.map((customName) => {
                      const isSelected = selectedLabourNames.includes(customName);
                      return (
                        <button
                          type="button"
                          key={customName}
                          onClick={() => handleToggleLabour(customName)}
                          className={`p-2.5 rounded-xl text-left border flex items-center justify-between gap-2 transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-500 border-amber-600 text-slate-950 font-bold shadow-xs ring-2 ring-amber-400/40'
                              : 'bg-white border-slate-300 text-slate-700 hover:border-slate-400'
                          }`}
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-bold truncate leading-tight">
                              {customName}
                            </div>
                            <div className="text-[10px] text-slate-500">
                              Helper
                            </div>
                          </div>
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                            isSelected ? 'bg-slate-950 text-white' : 'bg-slate-100 text-slate-400'
                          }`}>
                            {isSelected ? <Check className="w-3 h-3 stroke-[3]" /> : <Plus className="w-3 h-3" />}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Add Extra Worker (Button + Input, absolutely NO dropdown) */}
                <div className="pt-2 border-t border-slate-200 flex gap-2">
                  <input
                    type="text"
                    value={customLabour}
                    onChange={(e) => setCustomLabour(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCustomWorker();
                      }
                    }}
                    placeholder="Add other worker name..."
                    className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomWorker}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer shrink-0"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>+ Add</span>
                  </button>
                </div>
              </div>

              {/* Labour Salary Fix Option: 1 Pic / Daily / Monthly (Requested by User) */}
              <div className="p-3.5 bg-amber-50/60 border border-amber-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Coins className="w-4 h-4 text-amber-600" />
                    <span className="text-xs font-bold text-amber-950">
                      Labour Salary Option for this Batch:
                    </span>
                  </div>
                  <span className="text-[10px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                    Fix Salary Rate
                  </span>
                </div>

                {/* 3 Salary Mode Buttons */}
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-white rounded-lg border border-amber-200">
                  <button
                    type="button"
                    onClick={() => {
                      setWageType('Piece Rate');
                      setWageRate(2.5);
                    }}
                    className={`py-1.5 px-2 rounded text-xs font-semibold text-center transition-all cursor-pointer ${
                      wageType === 'Piece Rate'
                        ? 'bg-amber-500 text-slate-950 shadow-xs font-bold'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    1 Piece (₹/pic)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setWageType('Daily');
                      setWageRate(650);
                    }}
                    className={`py-1.5 px-2 rounded text-xs font-semibold text-center transition-all cursor-pointer ${
                      wageType === 'Daily'
                        ? 'bg-amber-500 text-slate-950 shadow-xs font-bold'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Daily Wage
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setWageType('Monthly');
                      setWageRate(0);
                    }}
                    className={`py-1.5 px-2 rounded text-xs font-semibold text-center transition-all cursor-pointer ${
                      wageType === 'Monthly'
                        ? 'bg-amber-500 text-slate-950 shadow-xs font-bold'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Monthly Fixed
                  </button>
                </div>

                {/* Rate Input & Quick Presets */}
                {wageType !== 'Monthly' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-3">
                      <label className="text-xs font-semibold text-slate-700">
                        {wageType === 'Piece Rate' ? 'Salary Rate per 1 Piece (₹/pic):' : 'Daily Wage Rate (₹/day):'}
                      </label>
                      <div className="w-32">
                        <input
                          type="number"
                          step="any"
                          min="0.1"
                          required
                          value={wageRate}
                          onChange={(e) => setWageRate(Number(e.target.value))}
                          className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-right border border-slate-300 rounded-lg bg-white"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Live Salary Calculation Card */}
                <div className="p-2.5 bg-white rounded-lg border border-amber-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[11px] text-slate-500 block">
                      {wageType === 'Piece Rate'
                        ? `${quantity} pcs × ₹${wageRate} per piece:`
                        : wageType === 'Daily'
                        ? `${workerCount} workers × ₹${wageRate} daily:`
                        : 'Monthly fixed salary crew:'}
                    </span>
                    <span className="text-sm font-mono font-bold text-slate-900">
                      ₹{calculatedBatchSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  {wageType === 'Piece Rate' && (
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Per worker share:</span>
                      <span className="text-xs font-mono font-semibold text-amber-700">
                        ₹{perWorkerShare.toFixed(2)} / worker
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Batch Remarks / Mix Ratio
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. 1:4 mix ratio, morning shift, 400 blocks"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900">
                Notice: Saving will automatically add <strong>{quantity} {selectedProduct?.unit}</strong> to your product stock.
              </div>
            </form>

            {/* Modal Footer: Fixed to screen at bottom */}
            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="production-form"
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Record Production
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
