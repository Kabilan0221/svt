import React, { useState } from 'react';
import { Invoice, Product, ProductionLog, Labour, InboundEntry, LabourPayment, LabourAdvance } from '../types';
import {
  IndianRupee,
  Calendar,
  AlertTriangle,
  Factory,
  ArrowUpRight,
  PlusCircle,
  FileText,
  UserCheck,
  Truck,
  Plus,
  Trash2,
  Wallet,
  Receipt,
  CheckCircle2,
  Clock,
  AlertCircle,
  Users,
  Search,
} from 'lucide-react';

interface Props {
  invoices?: Invoice[];
  products: Product[];
  productionLogs: ProductionLog[];
  labour: Labour[];
  inbounds: InboundEntry[];
  labourPayments?: LabourPayment[];
  labourAdvances?: LabourAdvance[];
  onOpenNewBill?: () => void;
  onOpenNewEstimate?: () => void;
  onOpenNewProduction: () => void;
  onViewInvoice?: (inv: Invoice) => void;
  onAddInbound: (inb: Omit<InboundEntry, 'id' | 'createdAt'>) => void;
  onDeleteInbound: (id: string) => void;
  onAddPayment?: (pay: Omit<LabourPayment, 'id' | 'voucherNumber'>) => void;
  onNavigateTab: (tab: any) => void;
}

export const DashboardView: React.FC<Props> = ({
  products,
  productionLogs,
  labour,
  inbounds,
  labourPayments = [],
  labourAdvances = [],
  onOpenNewProduction,
  onAddInbound,
  onDeleteInbound,
  onAddPayment,
  onNavigateTab,
}) => {
  // Modal states
  const [isInboundModalOpen, setIsInboundModalOpen] = useState(false);
  const [isSalaryModalOpen, setIsSalaryModalOpen] = useState(false);
  const [salaryFilter, setSalaryFilter] = useState<'All' | 'Pending' | 'Issued' | 'Completed'>('All');
  const [salarySearch, setSalarySearch] = useState('');
  const [notificationMessage, setNotificationMessage] = useState<string | null>(null);

  // Inbound Form state
  const [supplierName, setSupplierName] = useState('');
  const [supplierPhone, setSupplierPhone] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [inboundDate, setInboundDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id || '');
  const [quantity, setQuantity] = useState<number>(100);
  const [costPerUnit, setCostPerUnit] = useState<number>(products[0]?.costPrice || 350);
  const [unloadingRate, setUnloadingRate] = useState<number>(400);
  const [paymentStatus, setPaymentStatus] = useState<InboundEntry['paymentStatus']>('Paid');
  const [notes, setNotes] = useState('');

  // Salary Settlement Form state
  const [selectedLabourId, setSelectedLabourId] = useState(labour[0]?.id || '');
  const [payPeriod, setPayPeriod] = useState(`Week of ${new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}`);
  const [payPieces, setPayPieces] = useState<number>(2000);
  const [payDays, setPayDays] = useState<number>(6);
  const [customPayRate, setCustomPayRate] = useState<number>(labour[0]?.wageRate || 2.5);
  const [advanceDeduction, setAdvanceDeduction] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'UPI' | 'Bank'>('Cash');
  const [salaryStatusToMark, setSalaryStatusToMark] = useState<'Completed' | 'Issued'>('Completed');
  const [paymentNotes, setPaymentNotes] = useState('');

  // Date strings
  const todayStr = new Date().toISOString().split('T')[0];

  // Stock alerts
  const lowStockProducts = products.filter((p) => p.stockQuantity <= p.minStockLevel);

  // Today's Production
  const todayProduction = productionLogs.filter((p) => p.productionDate === todayStr);
  const todayProductionQty = todayProduction.reduce((sum, p) => sum + p.quantity, 0);

  // Active labour count
  const activeLabourCount = labour.filter((l) => l.status === 'Active').length;

  // Inbound stats
  const totalInboundCost = inbounds.reduce((sum, inb) => sum + inb.totalCost, 0);
  const totalInboundCount = inbounds.length;

  // ==========================================
  // SALARY CALCULATIONS & WORKER LEDGER
  // ==========================================
  const targetLabour = labour.find((l) => l.id === selectedLabourId) || labour[0];

  // Calculate ledger for each worker
  const workerSalaryList = labour.map((w) => {
    // 1. Calculate earned wage from production batches
    const workerLogs = productionLogs.filter(
      (l) => l.labourId === w.id || (l.labourName && l.labourName.toLowerCase().includes(w.name.toLowerCase()))
    );
    const wageFromLogs = workerLogs.reduce((sum, l) => sum + (l.totalLabourWage || 0), 0);

    // Calculated Salary: If production logs exist, use wageFromLogs. Else compute base work.
    const calculatedSalary = wageFromLogs > 0 ? wageFromLogs : (
      w.wageType === 'Daily' ? w.wageRate * 6 :
      w.wageType === 'Monthly' ? w.wageRate :
      w.wageRate * 1200
    );

    // 2. Sum of salaries issued / given to this worker
    const workerPayments = labourPayments.filter((p) => p.labourId === w.id);
    const issuedSalary = workerPayments.reduce((sum, p) => sum + (p.grossAmount || p.netPaid), 0);
    const netPaidOut = workerPayments.reduce((sum, p) => sum + p.netPaid, 0);

    // 3. Worker active advances
    const activeAdvances = labourAdvances.filter(
      (a) => a.labourId === w.id && a.status === 'Pending Deduction'
    );
    const pendingAdvance = activeAdvances.reduce((sum, a) => sum + a.amount, 0);

    // 4. Pending salary to be issued
    const pendingSalary = Math.max(0, calculatedSalary - issuedSalary);

    // 5. Status: 'Completed' | 'Issued' | 'Pending'
    let status: 'Completed' | 'Issued' | 'Pending' = 'Pending';
    if (pendingSalary === 0 && issuedSalary > 0) {
      status = 'Completed';
    } else if (issuedSalary > 0 && pendingSalary > 0) {
      status = 'Issued';
    } else if (issuedSalary > 0) {
      status = 'Completed';
    } else {
      status = 'Pending';
    }

    return {
      ...w,
      calculatedSalary,
      issuedSalary,
      netPaidOut,
      pendingSalary,
      pendingAdvance,
      status,
      paymentsCount: workerPayments.length,
      lastVoucher: workerPayments[0]?.voucherNumber,
      productionBatchesCount: workerLogs.length,
    };
  });

  // Filtered workers list
  const filteredWorkers = workerSalaryList.filter((w) => {
    const matchesFilter =
      salaryFilter === 'All'
        ? true
        : salaryFilter === 'Completed'
        ? w.status === 'Completed'
        : salaryFilter === 'Issued'
        ? w.status === 'Issued' || w.issuedSalary > 0
        : w.status === 'Pending' || w.pendingSalary > 0;

    const matchesSearch =
      w.name.toLowerCase().includes(salarySearch.toLowerCase()) ||
      w.role.toLowerCase().includes(salarySearch.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  // Aggregate Totals across all workers
  const totalCalculatedSalary = workerSalaryList.reduce((sum, w) => sum + w.calculatedSalary, 0);
  const totalSalaryIssued = workerSalaryList.reduce((sum, w) => sum + w.issuedSalary, 0);
  const totalPendingSalary = workerSalaryList.reduce((sum, w) => sum + w.pendingSalary, 0);
  const totalAdvancesPending = labourAdvances
    .filter((a) => a.status === 'Pending Deduction')
    .reduce((sum, a) => sum + a.amount, 0);

  // Handle open salary settlement modal for specific worker
  const handleOpenSalaryModal = (w: typeof workerSalaryList[0]) => {
    setSelectedLabourId(w.id);
    setCustomPayRate(w.wageRate);
    if (w.wageType === 'Piece Rate') {
      const neededPieces = w.wageRate > 0 ? Math.round(w.pendingSalary / w.wageRate) : 2000;
      setPayPieces(neededPieces > 0 ? neededPieces : 1500);
    } else if (w.wageType === 'Daily') {
      const neededDays = w.wageRate > 0 ? Math.round(w.pendingSalary / w.wageRate) : 6;
      setPayDays(neededDays > 0 ? neededDays : 6);
    }
    setAdvanceDeduction(w.pendingAdvance > 0 ? Math.min(w.pendingAdvance, w.pendingSalary) : 0);
    setSalaryStatusToMark(w.pendingSalary > 0 ? 'Completed' : 'Issued');
    setIsSalaryModalOpen(true);
  };

  // Quick 1-Click Salary Issue (Marks Completed when full pending salary is given)
  const handleQuickIssue = (w: typeof workerSalaryList[0]) => {
    if (!onAddPayment) return;
    if (w.pendingSalary <= 0) {
      setNotificationMessage(`ℹ️ ${w.name} உடைய சம்பளம் ஏற்கெனவே முடிவுற்றது (Already Completed).`);
      setTimeout(() => setNotificationMessage(null), 4000);
      return;
    }

    const deduction = w.pendingAdvance > 0 ? Math.min(w.pendingAdvance, w.pendingSalary) : 0;
    const net = Math.max(0, w.pendingSalary - deduction);

    onAddPayment({
      labourId: w.id,
      labourName: w.name,
      paymentDate: new Date().toISOString().split('T')[0],
      period: `Week of ${new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}`,
      wageType: w.wageType,
      daysWorked: w.wageType === 'Daily' ? 6 : undefined,
      piecesProduced: w.wageType === 'Piece Rate' ? Math.round(w.pendingSalary / (w.wageRate || 1)) : undefined,
      rateApplied: Number(w.wageRate),
      grossAmount: w.pendingSalary,
      advanceDeducted: deduction,
      netPaid: net,
      paymentMode: 'Cash',
      status: 'Completed', // When full pending calculated salary is issued, status is Completed!
      notes: `Quick salary issued & marked Completed (முழுதும் வழங்கப்பட்டது). Gross ₹${w.pendingSalary.toLocaleString()} - Adv ₹${deduction} = Net ₹${net.toLocaleString()}`,
    });

    setNotificationMessage(
      `✓ சம்பளம் வழங்கப்பட்டது! ₹${net.toLocaleString('en-IN')} issued to ${w.name} — Status: Completed (முடிவுற்றது)!`
    );
    setTimeout(() => setNotificationMessage(null), 5000);
  };

  // Live calculation inside modal
  let modalGross = 0;
  if (targetLabour?.wageType === 'Piece Rate') {
    modalGross = Number((payPieces * customPayRate).toFixed(2));
  } else if (targetLabour?.wageType === 'Daily') {
    modalGross = Number((payDays * customPayRate).toFixed(2));
  } else {
    modalGross = Number(customPayRate);
  }
  const modalNetPaid = Math.max(0, modalGross - advanceDeduction);

  const handleDisburseSalary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetLabour || modalGross <= 0) return;

    if (onAddPayment) {
      onAddPayment({
        labourId: targetLabour.id,
        labourName: targetLabour.name,
        paymentDate: new Date().toISOString().split('T')[0],
        period: payPeriod,
        wageType: targetLabour.wageType,
        daysWorked: targetLabour.wageType === 'Daily' ? Number(payDays) : undefined,
        piecesProduced: targetLabour.wageType === 'Piece Rate' ? Number(payPieces) : undefined,
        rateApplied: Number(customPayRate),
        grossAmount: modalGross,
        advanceDeducted: Number(advanceDeduction),
        netPaid: modalNetPaid,
        paymentMode,
        status: salaryStatusToMark,
        notes: paymentNotes.trim() || undefined,
      });

      setNotificationMessage(
        `✓ சம்பளம் வழங்கப்பட்டது! ₹${modalNetPaid.toLocaleString('en-IN')} paid to ${targetLabour.name} — Status: ${salaryStatusToMark}!`
      );
      setTimeout(() => setNotificationMessage(null), 5000);
    }

    setIsSalaryModalOpen(false);
    setPaymentNotes('');
  };

  const handleCreateInbound = (e: React.FormEvent) => {
    e.preventDefault();
    const currentProd = products.find((p) => p.id === selectedProductId);
    if (!currentProd || quantity <= 0) return;

    const totalCost = Number((quantity * costPerUnit).toFixed(2));
    onAddInbound({
      inboundNumber: `SVT-INB-${Date.now().toString().slice(-4)}`,
      date: inboundDate,
      supplierName: supplierName.trim() || 'Direct Quarry / Plant',
      supplierPhone: supplierPhone.trim() || undefined,
      vehicleNumber: vehicleNumber.trim() || undefined,
      productId: currentProd.id,
      productName: currentProd.name,
      unit: currentProd.unit,
      quantity: Number(quantity),
      costPerUnit: Number(costPerUnit),
      totalCost,
      unloadingRate: Number(unloadingRate),
      paymentStatus,
      notes: notes.trim() || undefined,
    });

    setIsInboundModalOpen(false);
    setSupplierName('');
    setSupplierPhone('');
    setVehicleNumber('');
    setNotes('');
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Top Banner / Welcome with Business Card Address */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
              ஸ்ரீ வெங்கடேஸ்வரா (SRI SVT TRADERS)
            </span>
            <span className="text-xs text-slate-700 font-semibold">
              உரிமை: பெரியநத்தம் வெ.பெருமாள் நாயகர்
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-black text-slate-950 tracking-tight mt-1.5">
            ஹாலோ பிளாக்ஸ் (4”, 6”, 8”) &amp; ஃபிளை ஆஷ் செங்கற்கள்
          </h1>
          <div className="text-xs text-slate-600 mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="inline-flex items-center gap-1 font-medium text-slate-700">
              📍 குருவிமலை கிராமம், களக்காட்டூர் அஞ்சல், உத்திரமேரூர் ரோடு, காஞ்சிபுரம் - 631 502
            </span>
            <span className="inline-flex items-center gap-1 font-bold text-slate-900 font-mono">
              📱 958578 1947, 904706 1947
            </span>
          </div>
        </div>

        {/* Quick Action Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              if (labour[0]) handleOpenSalaryModal(workerSalaryList[0]);
              else setIsSalaryModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            <Receipt className="w-4 h-4" />
            Issue Salary (சம்பளம்)
          </button>
          <button
            onClick={onOpenNewProduction}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-medium shadow-xs transition-colors cursor-pointer"
          >
            <Factory className="w-4 h-4" />
            Log Production
          </button>
          <button
            onClick={() => setIsInboundModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            <Truck className="w-4 h-4" />
            + Record Inbound
          </button>
        </div>
      </div>

      {/* Primary KPI Grid: Labour Salary & Production Tracking (No Bill History) */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 sm:gap-4">
        {/* KPI 1: Calculated Salary */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-slate-700">Calculated Salary</span>
            <IndianRupee className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 tabular-nums">
            ₹{totalCalculatedSalary.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-amber-800 mt-0.5 font-medium">
            கணக்கிடப்பட்ட சம்பளம் (Earned)
          </p>
        </div>

        {/* KPI 2: Salary Issued / Paid */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-emerald-800">Salary Issued (Paid)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-emerald-700 tabular-nums">
            ₹{totalSalaryIssued.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-emerald-700 mt-0.5 font-medium">
            வழங்கப்பட்ட சம்பளம் (Completed)
          </p>
        </div>

        {/* KPI 3: Pending Salary */}
        <div className="bg-white rounded-xl border border-rose-200 p-3 sm:p-4 shadow-xs bg-gradient-to-br from-white to-rose-50/30">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-rose-800">Pending Salary</span>
            <Clock className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-rose-600 tabular-nums">
            ₹{totalPendingSalary.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-rose-700 mt-0.5 font-medium">
            நிலுவை சம்பளம் (To Pay)
          </p>
        </div>

        {/* KPI 4: Pending Advances */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-slate-700">Advance Loans</span>
            <Wallet className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 tabular-nums">
            ₹{totalAdvancesPending.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5">முன்பணம் (Deductible)</p>
        </div>

        {/* KPI 5: Active Workers */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-slate-700">Active Workforce</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 tabular-nums">
            {activeLabourCount} தொழிலாளர்கள்
          </div>
          <p className="text-[10px] sm:text-[11px] text-blue-700 mt-0.5 font-medium">
            Piece rate &amp; daily wages
          </p>
        </div>
      </div>

      {/* ========================================================= */}
      {/* LABOUR SALARY STATUS & SETTLEMENT CENTER (Requested)      */}
      {/* ========================================================= */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                தொழிலாளர் சம்பளம்
              </span>
              <h2 className="text-base font-bold text-slate-900">
                Labour Salary Calculation &amp; Settlement (வழங்கப்பட்ட &amp; நிலுவை சம்பளம்)
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Live calculated salary from production runs, issued salary vouchers, and pending salary balances.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              onClick={() => onNavigateTab('labour-salary')}
              className="text-xs text-amber-600 hover:text-amber-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
            >
              Full Payroll Ledger <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Notification Toast for Salary Actions */}
        {notificationMessage && (
          <div className="mx-4 sm:mx-5 mt-4 p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between text-xs text-emerald-900 shadow-xs animate-in fade-in duration-200">
            <div className="flex items-center gap-2 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{notificationMessage}</span>
            </div>
            <button
              onClick={() => setNotificationMessage(null)}
              className="text-emerald-700 hover:text-emerald-950 font-bold px-2 py-0.5 rounded cursor-pointer"
            >
              ×
            </button>
          </div>
        )}

        {/* Filter Toolbar & Search */}
        <div className="p-3 sm:p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          {/* Status Filter Tabs */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-semibold overflow-x-auto">
            {(['All', 'Pending', 'Issued', 'Completed'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setSalaryFilter(filter)}
                className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  salaryFilter === filter
                    ? filter === 'Completed'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : filter === 'Issued'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : filter === 'Pending'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {filter === 'All' && `All (${workerSalaryList.length})`}
                {filter === 'Pending' && `Pending / நிலுவை (${workerSalaryList.filter((w) => w.pendingSalary > 0).length})`}
                {filter === 'Issued' && `Issued / வழங்கப்பட்டது (${workerSalaryList.filter((w) => w.issuedSalary > 0).length})`}
                {filter === 'Completed' && `Completed / முடிவுற்றது (${workerSalaryList.filter((w) => w.status === 'Completed').length})`}
              </button>
            ))}
          </div>

          {/* Search worker */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={salarySearch}
              onChange={(e) => setSalarySearch(e.target.value)}
              placeholder="Search worker name or role..."
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
            />
          </div>
        </div>

        {/* Mobile Worker Salary Cards */}
        <div className="block lg:hidden p-3 space-y-2.5">
          {filteredWorkers.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              No workers match the selected salary filter.
            </div>
          ) : (
            filteredWorkers.map((w) => (
              <div
                key={w.id}
                className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-slate-950">{w.name}</h4>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="bg-slate-200/80 text-slate-800 text-[10px] font-semibold px-2 py-0.5 rounded">
                        {w.role}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {w.wageType} · {w.wageType === 'Piece Rate' ? `₹${w.wageRate.toFixed(2)}/pic` : w.wageType === 'Daily' ? `₹${w.wageRate}/day` : `₹${w.wageRate}/mo`}
                      </span>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <span
                    className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full border ${
                      w.status === 'Completed'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                        : w.status === 'Issued'
                        ? 'bg-blue-50 text-blue-800 border-blue-300'
                        : 'bg-amber-50 text-amber-800 border-amber-300'
                    }`}
                  >
                    {w.status === 'Completed' && '✓ Completed'}
                    {w.status === 'Issued' && '● Issued'}
                    {w.status === 'Pending' && '⏳ Pending'}
                  </span>
                </div>

                {/* Salary Metrics Grid */}
                <div className="grid grid-cols-3 gap-2 bg-white p-2.5 rounded-lg border border-slate-200 text-center">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Calculated</span>
                    <span className="text-xs font-mono font-bold text-slate-900 block mt-0.5">
                      ₹{w.calculatedSalary.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[9px] text-slate-400 block truncate">
                      {w.wageType === 'Piece Rate' ? `${Math.round(w.calculatedSalary / (w.wageRate || 1))} pcs` : w.wageType === 'Daily' ? '6 days' : '1 mo'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-700 font-semibold block">Issued (Paid)</span>
                    <span className="text-xs font-mono font-bold text-emerald-700 block mt-0.5">
                      ₹{w.issuedSalary.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[9px] text-emerald-600 block">
                      {w.paymentsCount} voucher{w.paymentsCount !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-rose-700 font-semibold block">Pending</span>
                    <span className="text-xs font-mono font-bold text-rose-700 block mt-0.5">
                      ₹{w.pendingSalary.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[9px] text-rose-600 block">
                      {w.pendingSalary > 0 ? 'Due to pay' : 'All clear'}
                    </span>
                  </div>
                </div>

                {/* Advances and Action Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200/60 text-xs">
                  <div className="text-[11px] text-slate-500">
                    {w.pendingAdvance > 0 ? (
                      <span className="text-amber-700 font-semibold">
                        Advance Loan: ₹{w.pendingAdvance.toLocaleString()}
                      </span>
                    ) : (
                      <span className="text-slate-400">No active advance</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 ml-auto">
                    {w.pendingSalary > 0 ? (
                      <button
                        onClick={() => handleQuickIssue(w)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
                        title="Quick Issue full calculated pending salary and mark Completed"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Issue (₹{w.pendingSalary.toLocaleString()})</span>
                      </button>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                        ✓ Completed
                      </span>
                    )}

                    <button
                      onClick={() => handleOpenSalaryModal(w)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                      title="Custom pieces, days or advance deduction"
                    >
                      <Receipt className="w-3.5 h-3.5" />
                      <span>Adjust</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Desktop Worker Salary Table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Worker / Labour</th>
                <th className="py-3 px-4">Role &amp; Contact</th>
                <th className="py-3 px-4">Wage Basis</th>
                <th className="py-3 px-4 text-right">Calculated Salary (₹)</th>
                <th className="py-3 px-4 text-right">Issued Salary (₹)</th>
                <th className="py-3 px-4 text-right">Pending Salary (₹)</th>
                <th className="py-3 px-4 text-right">Advance Loan</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Action (சம்பளம் கொடு)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredWorkers.map((w) => (
                <tr key={w.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                    <div>{w.name}</div>
                    {w.lastVoucher && (
                      <div className="text-[10px] text-slate-400 font-mono">Last Vch: {w.lastVoucher}</div>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span className="bg-slate-100 text-slate-800 text-[10px] font-semibold px-2 py-0.5 rounded">
                      {w.role}
                    </span>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">{w.phone}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-700">
                    <div className="font-semibold">{w.wageType}</div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      {w.wageType === 'Piece Rate' ? `₹${w.wageRate.toFixed(2)} / pic` : w.wageType === 'Daily' ? `₹${w.wageRate} / day` : `₹${w.wageRate} / mo`}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                    <div>₹{w.calculatedSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                    <div className="text-[10px] text-slate-400 font-normal">
                      {w.wageType === 'Piece Rate' ? `${Math.round(w.calculatedSalary / (w.wageRate || 1))} pcs calc` : w.wageType === 'Daily' ? '6 days' : '1 month'}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                    <div>₹{w.issuedSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                    <div className="text-[10px] text-emerald-600 font-normal">{w.paymentsCount} paid</div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-600 tabular-nums">
                    <div>₹{w.pendingSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                    <div className="text-[10px] text-rose-500 font-normal">
                      {w.pendingSalary > 0 ? 'Pending' : 'Settled'}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                    {w.pendingAdvance > 0 ? (
                      <span className="text-amber-800 font-semibold">₹{w.pendingAdvance.toLocaleString()}</span>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 text-[10px] font-bold uppercase rounded-full border ${
                        w.status === 'Completed'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : w.status === 'Issued'
                          ? 'bg-blue-50 text-blue-800 border-blue-300'
                          : 'bg-amber-50 text-amber-800 border-amber-300'
                      }`}
                    >
                      {w.status === 'Completed' && '✓ Completed'}
                      {w.status === 'Issued' && '● Issued'}
                      {w.status === 'Pending' && '⏳ Pending'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      {w.pendingSalary > 0 ? (
                        <button
                          onClick={() => handleQuickIssue(w)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
                          title="Quick Issue full calculated pending salary and mark Completed"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Issue (₹{w.pendingSalary.toLocaleString()})</span>
                        </button>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                          ✓ Completed
                        </span>
                      )}

                      <button
                        onClick={() => handleOpenSalaryModal(w)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                        title="Custom settlement details"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>Adjust</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Operational Modules: Production Status & Inbound Stock */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-6">
        {/* Production Today Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Factory className="w-4 h-4 text-amber-600" />
              <h2 className="text-sm font-bold text-slate-900">Today's Production Batch Status</h2>
            </div>
            <button
              onClick={() => onNavigateTab('production')}
              className="text-xs text-amber-600 hover:text-amber-700 font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              All Batches <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            <div className="p-3 bg-amber-50/60 rounded-lg border border-amber-200 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-amber-900">Manufactured Today</p>
                <p className="text-2xl font-bold font-mono text-slate-950 mt-0.5">
                  {todayProductionQty.toLocaleString()} <span className="text-xs font-normal text-slate-600">units</span>
                </p>
              </div>
              <span className="text-xs font-mono font-semibold bg-amber-200 text-amber-950 px-2 py-1 rounded">
                {todayProduction.length} batches
              </span>
            </div>

            <div className="text-xs text-slate-500 space-y-1.5">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>Recent Run:</span>
                <span className="font-semibold text-slate-800">
                  {productionLogs[0]?.productName || 'Solid Concrete Blocks'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>Labour Assigned:</span>
                <span className="font-semibold text-slate-800 truncate max-w-[180px]">
                  {productionLogs[0]?.labourName || 'Assigned Crew'}
                </span>
              </div>
            </div>

            <button
              onClick={onOpenNewProduction}
              className="w-full py-2 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors text-center cursor-pointer"
            >
              + Log New Production Batch
            </button>
          </div>
        </div>

        {/* Low Stock Alert Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className={`w-4 h-4 ${lowStockProducts.length > 0 ? 'text-rose-500' : 'text-slate-400'}`} />
              <h2 className="text-sm font-bold text-slate-900">Material Inventory Alerts</h2>
            </div>
            <button
              onClick={() => onNavigateTab('products')}
              className="text-xs text-amber-600 hover:text-amber-700 font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              View Inventory <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs p-2 bg-slate-50 rounded-lg">
              <span className="text-slate-600">Total Materials in Catalog:</span>
              <span className="font-bold font-mono text-slate-900">{products.length} products</span>
            </div>

            {lowStockProducts.length > 0 ? (
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {lowStockProducts.map((p) => (
                  <div
                    key={p.id}
                    className="p-2 bg-rose-50 border border-rose-200 rounded-lg flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-rose-950 block">{p.name}</span>
                      <span className="text-[10px] text-rose-700 font-mono">Min limit: {p.minStockLevel} {p.unit}</span>
                    </div>
                    <span className="text-xs font-bold font-mono text-rose-700 bg-rose-100 px-2 py-0.5 rounded">
                      {p.stockQuantity} {p.unit}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200 text-center text-xs text-emerald-800">
                All block sizes, cement and aggregates are well-stocked.
              </div>
            )}

            <button
              onClick={() => setIsInboundModalOpen(true)}
              className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors text-center cursor-pointer"
            >
              + Record Raw Material (வரவு)
            </button>
          </div>
        </div>
      </div>

      {/* Inbound Material & Raw Consignments Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
                Raw Materials
              </span>
              <h2 className="text-base font-bold text-slate-900">Inbound Material Deliveries</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Raw materials arriving at yard (Cement, Sand, Gravel) with vehicle numbers &amp; auto stock addition
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => onNavigateTab('raw-material-inbound')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold border border-slate-300 transition-colors cursor-pointer"
            >
              <span>View Full Inbound Section →</span>
            </button>
            <button
              onClick={() => setIsInboundModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              Record Inbound Material
            </button>
          </div>
        </div>

        {/* Mobile Inbound Cards */}
        <div className="block md:hidden p-3 space-y-2.5">
          {inbounds.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              No inbound material records yet. Click "+ Record Inbound Material" above.
            </div>
          ) : (
            inbounds.map((inb) => (
              <div
                key={inb.id}
                className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-xs text-slate-900">{inb.inboundNumber}</span>
                      <span className="text-[10px] text-slate-400 font-mono">· {inb.date}</span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5">{inb.productName}</h4>
                    <span className="text-[11px] text-slate-500 block">From: {inb.supplierName}</span>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-mono font-bold text-emerald-700 block">
                      +{inb.quantity.toLocaleString()} {inb.unit}
                    </span>
                    <span className="text-xs font-mono text-slate-600 block">
                      ₹{inb.totalCost.toLocaleString('en-IN')}
                    </span>
                    <span
                      className={`inline-block px-1.5 py-0.5 text-[9px] font-semibold rounded mt-0.5 ${
                        inb.paymentStatus === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {inb.paymentStatus}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px] text-slate-500">
                  <span>Vehicle: <strong className="text-slate-800 font-mono">{inb.vehicleNumber || 'Plant Delivery'}</strong></span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono">₹{inb.costPerUnit}/{inb.unit}</span>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete inbound record ${inb.inboundNumber}? Stock quantity will be reverted.`)) {
                          onDeleteInbound(inb.id);
                        }
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                      title="Delete record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Desktop Inbound Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Inbound #</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Material / Product</th>
                <th className="py-3 px-4">Supplier / Quarry</th>
                <th className="py-3 px-4">Vehicle / Truck No</th>
                <th className="py-3 px-4 text-right">Inward Qty</th>
                <th className="py-3 px-4 text-right">Cost Rate (₹)</th>
                <th className="py-3 px-4 text-right">Total Cost (₹)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {inbounds.map((inb) => (
                <tr key={inb.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                    {inb.inboundNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">{inb.date}</td>
                  <td className="py-3 px-4 font-semibold text-slate-900">
                    {inb.productName}
                  </td>
                  <td className="py-3 px-4 text-slate-700">
                    <div>{inb.supplierName}</div>
                    {inb.supplierPhone && <div className="text-[11px] text-slate-400 font-mono">{inb.supplierPhone}</div>}
                  </td>
                  <td className="py-3 px-4">
                    {inb.vehicleNumber ? (
                      <span className="font-mono text-[11px] font-semibold text-slate-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                        {inb.vehicleNumber}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic">Consignment</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                    +{inb.quantity.toLocaleString()} {inb.unit}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                    ₹{inb.costPerUnit.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                    ₹{inb.totalCost.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 text-[10px] font-semibold rounded ${
                        inb.paymentStatus === 'Paid'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}
                    >
                      {inb.paymentStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete inbound entry ${inb.inboundNumber}? Added stock will be deducted back.`)) {
                          onDeleteInbound(inb.id);
                        }
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                      title="Delete Inbound"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- SALARY SETTLEMENT & ISSUE MODAL (Direct on Dashboard) --- */}
      {isSalaryModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-sm font-bold">Issue Labour Salary (சம்பளம் வழங்குக)</h3>
                  <p className="text-[11px] text-slate-400">
                    Disburse wage payment voucher and update status to Issued / Completed
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsSalaryModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleDisburseSalary} id="dashboard-salary-form" className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Worker / Labour *
                </label>
                <select
                  value={selectedLabourId}
                  onChange={(e) => {
                    const lId = e.target.value;
                    setSelectedLabourId(lId);
                    const selected = workerSalaryList.find((w) => w.id === lId);
                    if (selected) {
                      setCustomPayRate(selected.wageRate);
                      setAdvanceDeduction(selected.pendingAdvance > 0 ? Math.min(selected.pendingAdvance, selected.pendingSalary) : 0);
                    }
                  }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white font-medium"
                >
                  {workerSalaryList.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.role}) — {w.wageType} — Pending: ₹{w.pendingSalary.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              {/* Worker Wage Calculations */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600">Wage Type:</span>
                  <span className="font-bold text-slate-900">{targetLabour?.wageType}</span>
                </div>

                {targetLabour?.wageType === 'Piece Rate' && (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div>
                      <label className="block text-[11px] text-slate-600 mb-1">Pieces Produced</label>
                      <input
                        type="number"
                        min="1"
                        value={payPieces}
                        onChange={(e) => setPayPieces(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-600 mb-1">Rate per 1 Piece (₹/pic)</label>
                      <input
                        type="number"
                        step="any"
                        min="0.1"
                        value={customPayRate}
                        onChange={(e) => setCustomPayRate(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>
                )}

                {targetLabour?.wageType === 'Daily' && (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div>
                      <label className="block text-[11px] text-slate-600 mb-1">Days Worked</label>
                      <input
                        type="number"
                        min="1"
                        value={payDays}
                        onChange={(e) => setPayDays(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-600 mb-1">Daily Wage Rate (₹/day)</label>
                      <input
                        type="number"
                        step="any"
                        min="1"
                        value={customPayRate}
                        onChange={(e) => setCustomPayRate(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>
                )}

                {targetLabour?.wageType === 'Monthly' && (
                  <div className="pt-1">
                    <label className="block text-[11px] text-slate-600 mb-1">Monthly Salary (₹)</label>
                    <input
                      type="number"
                      step="any"
                      min="1"
                      value={customPayRate}
                      onChange={(e) => setCustomPayRate(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                )}
              </div>

              {/* Advance Deduction & Mode */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Advance to Deduct (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={advanceDeduction}
                    onChange={(e) => setAdvanceDeduction(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Payment Mode
                  </label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Cash">Cash</option>
                    <option value="UPI">UPI</option>
                    <option value="Bank">Bank Transfer</option>
                  </select>
                </div>
              </div>

              {/* Status to Mark */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Salary Status to Apply
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSalaryStatusToMark('Completed')}
                    className={`p-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      salaryStatusToMark === 'Completed'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    ✓ Completed (முழுதும் வழங்கப்பட்டது)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSalaryStatusToMark('Issued')}
                    className={`p-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      salaryStatusToMark === 'Issued'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    ● Issued (வழங்கப்பட்டது)
                  </button>
                </div>
              </div>

              {/* Summary Calculation */}
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 space-y-1 text-xs">
                <div className="flex justify-between text-emerald-900">
                  <span>Gross Calculated Wage:</span>
                  <span className="font-mono font-bold">₹{modalGross.toFixed(2)}</span>
                </div>
                {advanceDeduction > 0 && (
                  <div className="flex justify-between text-amber-800">
                    <span>Advance Deduction:</span>
                    <span className="font-mono font-semibold">-₹{advanceDeduction.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-bold text-emerald-950 pt-1 border-t border-emerald-300">
                  <span>Net Salary Payable:</span>
                  <span className="font-mono text-base">₹{modalNetPaid.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Settlement Notes / Period
                </label>
                <input
                  type="text"
                  value={payPeriod}
                  onChange={(e) => setPayPeriod(e.target.value)}
                  placeholder="e.g. Weekly Wage Oct 11 - 17"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                />
              </div>
            </form>

            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsSalaryModalOpen(false)}
                className="px-3.5 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="dashboard-salary-form"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Disburse &amp; Mark {salaryStatusToMark}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- RECORD INBOUND MODAL --- */}
      {isInboundModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-4 sm:px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold tracking-tight">Record Inbound Material Stock</h3>
              </div>
              <button
                onClick={() => setIsInboundModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreateInbound} id="inbound-form" className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Product / Raw Material *
                </label>
                <select
                  value={selectedProductId}
                  onChange={(e) => {
                    const pId = e.target.value;
                    setSelectedProductId(pId);
                    const prod = products.find((p) => p.id === pId);
                    if (prod) setCostPerUnit(prod.costPrice);
                  }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.unit}) — Current Stock: {p.stockQuantity}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Arriving Quantity *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Purchase Rate (₹/unit) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    required
                    value={costPerUnit}
                    onChange={(e) => setCostPerUnit(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Vehicle / Truck No
                  </label>
                  <input
                    type="text"
                    value={vehicleNumber}
                    onChange={(e) => setVehicleNumber(e.target.value)}
                    placeholder="e.g. TN 21 BX 8912"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white uppercase font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Inward Date
                  </label>
                  <input
                    type="date"
                    required
                    value={inboundDate}
                    onChange={(e) => setInboundDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Supplier / Quarry Name
                  </label>
                  <input
                    type="text"
                    value={supplierName}
                    onChange={(e) => setSupplierName(e.target.value)}
                    placeholder="e.g. Chettinad Cements / Quarry"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Payment Status
                  </label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Paid">Paid</option>
                    <option value="Unpaid">Unpaid / Credit</option>
                    <option value="Partial">Partial</option>
                  </select>
                </div>
              </div>

              {/* Total summary */}
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 flex justify-between items-center text-xs">
                <span className="font-semibold text-emerald-900">Total Inbound Material Cost:</span>
                <span className="text-sm font-mono font-bold text-emerald-900">
                  ₹{(quantity * costPerUnit).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </form>

            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsInboundModalOpen(false)}
                className="px-3.5 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="inbound-form"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Add Inbound Stock
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
