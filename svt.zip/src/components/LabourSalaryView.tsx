import React, { useState } from 'react';
import { Labour, LabourAdvance, LabourPayment, ProductionLog } from '../types';
import {
  Users,
  Plus,
  IndianRupee,
  Calendar,
  Wallet,
  Receipt,
  CheckCircle2,
  AlertCircle,
  FileText,
  UserPlus,
  Clock,
  Search,
  ArrowUpRight,
} from 'lucide-react';

interface Props {
  labour: Labour[];
  advances: LabourAdvance[];
  payments: LabourPayment[];
  productionLogs?: ProductionLog[];
  onSaveLabour: (labour: Omit<Labour, 'id'> & { id?: string }) => void;
  onAddAdvance: (adv: Omit<LabourAdvance, 'id'>) => void;
  onAddPayment: (pay: Omit<LabourPayment, 'id' | 'voucherNumber'>) => void;
}

export const LabourSalaryView: React.FC<Props> = ({
  labour,
  advances,
  payments,
  productionLogs = [],
  onSaveLabour,
  onAddAdvance,
  onAddPayment,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'status' | 'roster' | 'advances' | 'payments'>('status');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Issued' | 'Completed'>('All');
  const [searchWorker, setSearchWorker] = useState('');
  const [notificationMessage, setNotificationMessage] = useState<string | null>(null);

  // Modals
  const [isAddLabourModal, setIsAddLabourModal] = useState(false);
  const [isAddAdvanceModal, setIsAddAdvanceModal] = useState(false);
  const [isSettlementModal, setIsSettlementModal] = useState(false);

  // Form states: New Labour
  const [labourName, setLabourName] = useState('');
  const [labourRole, setLabourRole] = useState<Labour['role']>('Loader');
  const [labourPhone, setLabourPhone] = useState('');
  const [labourWageType, setLabourWageType] = useState<Labour['wageType']>('Piece Rate');
  const [labourWageRate, setLabourWageRate] = useState<number>(2.5);

  // Form states: New Advance
  const [advanceLabourId, setAdvanceLabourId] = useState(labour[0]?.id || '');
  const [advanceAmount, setAdvanceAmount] = useState<number>(1000);
  const [advanceDate, setAdvanceDate] = useState(new Date().toISOString().split('T')[0]);
  const [advanceReason, setAdvanceReason] = useState('Family medical expense');

  // Form states: Salary Settlement
  const [settlementLabourId, setSettlementLabourId] = useState(labour[0]?.id || '');
  const [settlementWageType, setSettlementWageType] = useState<'Piece Rate' | 'Daily' | 'Monthly'>('Piece Rate');
  const [settlementPiecesProduced, setSettlementPiecesProduced] = useState<number>(2000);
  const [settlementPieceRate, setSettlementPieceRate] = useState<number>(2.5);
  const [settlementDays, setSettlementDays] = useState<number>(7);
  const [settlementDailyRate, setSettlementDailyRate] = useState<number>(650);
  const [settlementMonthlyRate, setSettlementMonthlyRate] = useState<number>(20000);
  const [settlementAdvanceDeduction, setSettlementAdvanceDeduction] = useState<number>(0);
  const [settlementPeriod, setSettlementPeriod] = useState('Weekly Wage Oct 11 - 17');
  const [settlementMode, setSettlementMode] = useState<'Cash' | 'UPI' | 'Bank'>('Cash');
  const [settlementStatus, setSettlementStatus] = useState<'Completed' | 'Issued'>('Completed');
  const [settlementNotes, setSettlementNotes] = useState('');

  // ==========================================
  // SALARY CALCULATIONS & WORKER LEDGER
  // ==========================================
  const targetLabour = labour.find((l) => l.id === settlementLabourId) || labour[0];
  const pendingAdvancesForTarget = advances
    .filter((a) => a.labourId === targetLabour?.id && a.status === 'Pending Deduction')
    .reduce((sum, a) => sum + a.amount, 0);

  // Calculate gross wage based on active settlement wage type
  let grossWage = 0;
  if (settlementWageType === 'Piece Rate') {
    grossWage = Number((settlementPiecesProduced * settlementPieceRate).toFixed(2));
  } else if (settlementWageType === 'Daily') {
    grossWage = Number((settlementDays * settlementDailyRate).toFixed(2));
  } else {
    grossWage = Number(settlementMonthlyRate.toFixed(2));
  }
  const netPayable = Math.max(0, grossWage - settlementAdvanceDeduction);

  // Worker Salary Ledger
  const workerLedger = labour.map((w) => {
    // 1. Calculate earned wage from production logs
    const workerLogs = productionLogs.filter(
      (l) => l.labourId === w.id || (l.labourName && l.labourName.toLowerCase().includes(w.name.toLowerCase()))
    );
    const wageFromLogs = workerLogs.reduce((sum, l) => sum + (l.totalLabourWage || 0), 0);

    const calculatedSalary = wageFromLogs > 0 ? wageFromLogs : (
      w.wageType === 'Daily' ? w.wageRate * 6 :
      w.wageType === 'Monthly' ? w.wageRate :
      w.wageRate * 1200
    );

    // 2. Sum of salaries issued / given to this worker
    const workerPayments = payments.filter((p) => p.labourId === w.id);
    const issuedSalary = workerPayments.reduce((sum, p) => sum + (p.grossAmount || p.netPaid), 0);
    const netPaidOut = workerPayments.reduce((sum, p) => sum + p.netPaid, 0);

    // 3. Worker active advances
    const activeAdvances = advances.filter(
      (a) => a.labourId === w.id && a.status === 'Pending Deduction'
    );
    const pendingAdvance = activeAdvances.reduce((sum, a) => sum + a.amount, 0);

    // 4. Pending salary to be issued
    const pendingSalary = Math.max(0, calculatedSalary - issuedSalary);

    // 5. Status: 'Completed' | 'Issued' | 'Pending'
    let status: 'Completed' | 'Issued' | 'Pending' = 'Pending';
    if (pendingSalary === 0 && issuedSalary > 0) {
      status = 'Completed';
    } else if (issuedSalary > 0 && pendingSalary > 0) {
      status = 'Issued';
    } else if (issuedSalary > 0) {
      status = 'Completed';
    } else {
      status = 'Pending';
    }

    return {
      ...w,
      calculatedSalary,
      issuedSalary,
      netPaidOut,
      pendingSalary,
      pendingAdvance,
      status,
      paymentsCount: workerPayments.length,
      lastVoucher: workerPayments[0]?.voucherNumber,
      productionBatchesCount: workerLogs.length,
    };
  });

  const filteredLedger = workerLedger.filter((w) => {
    const matchesFilter =
      statusFilter === 'All'
        ? true
        : statusFilter === 'Completed'
        ? w.status === 'Completed'
        : statusFilter === 'Issued'
        ? w.status === 'Issued' || w.issuedSalary > 0
        : w.status === 'Pending' || w.pendingSalary > 0;

    const matchesSearch =
      w.name.toLowerCase().includes(searchWorker.toLowerCase()) ||
      w.role.toLowerCase().includes(searchWorker.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  // Totals
  const totalCalculatedSalary = workerLedger.reduce((sum, w) => sum + w.calculatedSalary, 0);
  const totalSalaryIssued = workerLedger.reduce((sum, w) => sum + w.issuedSalary, 0);
  const totalPendingSalary = workerLedger.reduce((sum, w) => sum + w.pendingSalary, 0);
  const totalAdvancesPending = advances
    .filter((a) => a.status === 'Pending Deduction')
    .reduce((sum, a) => sum + a.amount, 0);
  const totalPaidThisMonth = payments.reduce((sum, p) => sum + p.netPaid, 0);

  const handleCreateLabour = (e: React.FormEvent) => {
    e.preventDefault();
    if (!labourName.trim() || labourWageRate <= 0) return;

    onSaveLabour({
      name: labourName.trim(),
      role: labourRole,
      phone: labourPhone.trim(),
      wageType: labourWageType,
      wageRate: Number(labourWageRate),
      joinDate: new Date().toISOString().split('T')[0],
      status: 'Active',
    });

    setIsAddLabourModal(false);
    setLabourName('');
  };

  const handleCreateAdvance = (e: React.FormEvent) => {
    e.preventDefault();
    const lab = labour.find((l) => l.id === advanceLabourId);
    if (!lab || advanceAmount <= 0) return;

    onAddAdvance({
      labourId: lab.id,
      labourName: lab.name,
      amount: Number(advanceAmount),
      date: advanceDate,
      reason: advanceReason.trim() || 'Advance Cash',
      recordedBy: 'Owner / Manager',
      status: 'Pending Deduction',
    });

    setIsAddAdvanceModal(false);
  };

  const handleCreatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetLabour) return;

    onAddPayment({
      labourId: targetLabour.id,
      labourName: targetLabour.name,
      paymentDate: new Date().toISOString().split('T')[0],
      period: settlementPeriod,
      wageType: settlementWageType,
      daysWorked: settlementWageType === 'Daily' ? Number(settlementDays) : undefined,
      piecesProduced: settlementWageType === 'Piece Rate' ? Number(settlementPiecesProduced) : undefined,
      rateApplied: settlementWageType === 'Piece Rate' ? settlementPieceRate : settlementWageType === 'Daily' ? settlementDailyRate : settlementMonthlyRate,
      grossAmount: grossWage,
      advanceDeducted: Number(settlementAdvanceDeduction),
      netPaid: netPayable,
      paymentMode: settlementMode,
      status: settlementStatus,
      notes: settlementNotes.trim() || undefined,
    });

    setNotificationMessage(
      `✓ சம்பளம் வழங்கப்பட்டது! ₹${netPayable.toLocaleString('en-IN')} paid to ${targetLabour.name} — Status: ${settlementStatus}!`
    );
    setTimeout(() => setNotificationMessage(null), 5000);

    setIsSettlementModal(false);
  };

  // Quick 1-Click Salary Issue (Marks Completed when full pending salary is given)
  const handleQuickIssue = (w: typeof workerLedger[0]) => {
    if (w.pendingSalary <= 0) {
      setNotificationMessage(`ℹ️ ${w.name} உடைய சம்பளம் ஏற்கெனவே முடிவுற்றது (Already Completed).`);
      setTimeout(() => setNotificationMessage(null), 4000);
      return;
    }

    const deduction = w.pendingAdvance > 0 ? Math.min(w.pendingAdvance, w.pendingSalary) : 0;
    const net = Math.max(0, w.pendingSalary - deduction);

    onAddPayment({
      labourId: w.id,
      labourName: w.name,
      paymentDate: new Date().toISOString().split('T')[0],
      period: `Week of ${new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}`,
      wageType: w.wageType,
      daysWorked: w.wageType === 'Daily' ? 6 : undefined,
      piecesProduced: w.wageType === 'Piece Rate' ? Math.round(w.pendingSalary / (w.wageRate || 1)) : undefined,
      rateApplied: Number(w.wageRate),
      grossAmount: w.pendingSalary,
      advanceDeducted: deduction,
      netPaid: net,
      paymentMode: 'Cash',
      status: 'Completed', // Full pending salary paid -> status is Completed!
      notes: `Quick salary issued & marked Completed (முழுதும் வழங்கப்பட்டது). Gross ₹${w.pendingSalary.toLocaleString()} - Adv ₹${deduction} = Net ₹${net.toLocaleString()}`,
    });

    setNotificationMessage(
      `✓ சம்பளம் வழங்கப்பட்டது! ₹${net.toLocaleString('en-IN')} issued to ${w.name} — Status: Completed (முடிவுற்றது)!`
    );
    setTimeout(() => setNotificationMessage(null), 5000);
  };

  const openSettlementFor = (l: { id: string; name: string; wageType: Labour['wageType']; wageRate: number; [key: string]: any }, customPending?: number) => {
    setSettlementLabourId(l.id);
    setSettlementWageType(l.wageType);
    if (l.wageType === 'Piece Rate') {
      setSettlementPieceRate(l.wageRate);
      const targetPieces = customPending && l.wageRate > 0 ? Math.round(customPending / l.wageRate) : 2000;
      setSettlementPiecesProduced(targetPieces > 0 ? targetPieces : 1500);
    } else if (l.wageType === 'Daily') {
      setSettlementDailyRate(l.wageRate);
      const targetDays = customPending && l.wageRate > 0 ? Math.round(customPending / l.wageRate) : 6;
      setSettlementDays(targetDays > 0 ? targetDays : 6);
    } else {
      setSettlementMonthlyRate(l.wageRate);
    }
    const pend = advances
      .filter((a) => a.labourId === l.id && a.status === 'Pending Deduction')
      .reduce((sum, a) => sum + a.amount, 0);
    setSettlementAdvanceDeduction(pend > 0 ? Math.min(pend, customPending || 2000) : 0);
    setSettlementStatus(customPending && customPending > 0 ? 'Completed' : 'Issued');
    setIsSettlementModal(true);
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* View Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              தொழிலாளர் ஊதியம்
            </span>
            <span className="text-xs text-slate-500">Workforce &amp; Payroll Management</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-1">
            Labour &amp; Salary Management (தொழிலாளர் சம்பளம்)
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Fix piece rates (1 pic), daily or monthly wages; calculate earned salary, track issued/completed payments and pending dues.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsAddAdvanceModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            <Wallet className="w-4 h-4 text-amber-700" />
            Record Advance
          </button>
          <button
            onClick={() => {
              if (labour[0]) openSettlementFor(labour[0]);
              else setIsSettlementModal(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Receipt className="w-4 h-4" />
            Issue Salary (சம்பளம்)
          </button>
          <button
            onClick={() => setIsAddLabourModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            + Add Worker
          </button>
        </div>
      </div>

      {/* Overview Cards: Calculated, Issued, Pending & Advances */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 sm:gap-4">
        {/* Card 1: Calculated Salary */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-slate-700">Calculated Salary</span>
            <IndianRupee className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 tabular-nums">
            ₹{totalCalculatedSalary.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-amber-800 mt-0.5 font-medium">கணக்கிடப்பட்ட சம்பளம்</p>
        </div>

        {/* Card 2: Issued Salary */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-emerald-800">Salary Issued (Paid)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-emerald-700 tabular-nums">
            ₹{totalSalaryIssued.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-emerald-700 mt-0.5 font-medium">வழங்கப்பட்ட சம்பளம்</p>
        </div>

        {/* Card 3: Pending Salary */}
        <div className="bg-white rounded-xl border border-rose-200 p-3 sm:p-4 shadow-xs bg-gradient-to-br from-white to-rose-50/30">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-rose-800">Pending Salary</span>
            <Clock className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-rose-600 tabular-nums">
            ₹{totalPendingSalary.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-rose-700 mt-0.5 font-medium">நிலுவை சம்பளம்</p>
        </div>

        {/* Card 4: Active Advances */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-slate-700">Pending Advance</span>
            <Wallet className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 tabular-nums">
            ₹{totalAdvancesPending.toLocaleString('en-IN', { minimumFractionDigits: 0 })}
          </div>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5">முன்பணம் (Loans)</p>
        </div>

        {/* Card 5: Active Workers */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] sm:text-xs font-semibold text-slate-700">Active Workers</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 tabular-nums">
            {labour.filter((l) => l.status === 'Active').length}
          </div>
          <p className="text-[10px] sm:text-[11px] text-blue-700 mt-0.5 font-medium">Piece &amp; daily labour</p>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-200 bg-white px-2 rounded-t-xl overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('status')}
          className={`px-3 sm:px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
            activeSubTab === 'status'
              ? 'border-emerald-600 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          1. Salary Status &amp; Settlement (கணக்கீடு &amp; வழங்கல்)
        </button>
        <button
          onClick={() => setActiveSubTab('roster')}
          className={`px-3 sm:px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
            activeSubTab === 'roster'
              ? 'border-amber-500 text-slate-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          2. Labour Roster &amp; Rates ({labour.length})
        </button>
        <button
          onClick={() => setActiveSubTab('advances')}
          className={`px-3 sm:px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
            activeSubTab === 'advances'
              ? 'border-amber-500 text-slate-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          3. Advance Loans ({advances.length})
        </button>
        <button
          onClick={() => setActiveSubTab('payments')}
          className={`px-3 sm:px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
            activeSubTab === 'payments'
              ? 'border-amber-500 text-slate-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          4. Salary Vouchers ({payments.length})
        </button>
      </div>

      {/* --- TAB 1: SALARY STATUS & SETTLEMENT --- */}
      {activeSubTab === 'status' && (
        <div className="bg-white rounded-b-xl border border-t-0 border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
          {/* Notification Toast */}
          {notificationMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between text-xs text-emerald-900 shadow-xs animate-in fade-in duration-200">
              <div className="flex items-center gap-2 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{notificationMessage}</span>
              </div>
              <button
                onClick={() => setNotificationMessage(null)}
                className="text-emerald-700 hover:text-emerald-950 font-bold px-2 py-0.5 rounded cursor-pointer"
              >
                ×
              </button>
            </div>
          )}

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Status Pills */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-semibold overflow-x-auto">
              {(['All', 'Pending', 'Issued', 'Completed'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setStatusFilter(filter)}
                  className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    statusFilter === filter
                      ? filter === 'Completed'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : filter === 'Issued'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : filter === 'Pending'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {filter === 'All' && `All Workers (${workerLedger.length})`}
                  {filter === 'Pending' && `Pending / நிலுவை (${workerLedger.filter((w) => w.pendingSalary > 0).length})`}
                  {filter === 'Issued' && `Issued / வழங்கப்பட்டது (${workerLedger.filter((w) => w.issuedSalary > 0).length})`}
                  {filter === 'Completed' && `Completed / முடிவுற்றது (${workerLedger.filter((w) => w.status === 'Completed').length})`}
                </button>
              ))}
            </div>

            {/* Search */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchWorker}
                onChange={(e) => setSearchWorker(e.target.value)}
                placeholder="Search worker or role..."
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 bg-white"
              />
            </div>
          </div>

          {/* Mobile Cards */}
          <div className="block lg:hidden space-y-2.5">
            {filteredLedger.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                No workers found for this filter.
              </div>
            ) : (
              filteredLedger.map((w) => (
                <div
                  key={w.id}
                  className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-bold text-slate-950">{w.name}</h4>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="bg-slate-200/80 text-slate-800 text-[10px] font-semibold px-2 py-0.5 rounded">
                          {w.role}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {w.wageType} · {w.wageType === 'Piece Rate' ? `₹${w.wageRate.toFixed(2)}/pic` : w.wageType === 'Daily' ? `₹${w.wageRate}/day` : `₹${w.wageRate}/mo`}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full border ${
                        w.status === 'Completed'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : w.status === 'Issued'
                          ? 'bg-blue-50 text-blue-800 border-blue-300'
                          : 'bg-amber-50 text-amber-800 border-amber-300'
                      }`}
                    >
                      {w.status === 'Completed' && '✓ Completed'}
                      {w.status === 'Issued' && '● Issued'}
                      {w.status === 'Pending' && '⏳ Pending'}
                    </span>
                  </div>

                  {/* Grid */}
                  <div className="grid grid-cols-3 gap-2 bg-white p-2.5 rounded-lg border border-slate-200 text-center">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Calculated</span>
                      <span className="text-xs font-mono font-bold text-slate-900 block mt-0.5">
                        ₹{w.calculatedSalary.toLocaleString('en-IN')}
                      </span>
                      <span className="text-[9px] text-slate-400 block truncate">
                        {w.wageType === 'Piece Rate' ? `${Math.round(w.calculatedSalary / (w.wageRate || 1))} pcs` : w.wageType === 'Daily' ? '6 days' : '1 mo'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-emerald-700 font-semibold block">Issued (Paid)</span>
                      <span className="text-xs font-mono font-bold text-emerald-700 block mt-0.5">
                        ₹{w.issuedSalary.toLocaleString('en-IN')}
                      </span>
                      <span className="text-[9px] text-emerald-600 block">
                        {w.paymentsCount} voucher{w.paymentsCount !== 1 ? 's' : ''}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-rose-700 font-semibold block">Pending</span>
                      <span className="text-xs font-mono font-bold text-rose-700 block mt-0.5">
                        ₹{w.pendingSalary.toLocaleString('en-IN')}
                      </span>
                      <span className="text-[9px] text-rose-600 block">
                        {w.pendingSalary > 0 ? 'Due to pay' : 'All clear'}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200/60 text-xs">
                    <span className="text-[11px] text-slate-500">
                      {w.pendingAdvance > 0 ? `Advance Loan: ₹${w.pendingAdvance.toLocaleString()}` : 'No advance loan'}
                    </span>
                    <div className="flex items-center gap-1.5 ml-auto">
                      {w.pendingSalary > 0 ? (
                        <button
                          onClick={() => handleQuickIssue(w)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
                          title="Quick Issue full calculated pending salary and mark Completed"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Issue (₹{w.pendingSalary.toLocaleString()})</span>
                        </button>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                          ✓ Completed
                        </span>
                      )}

                      <button
                        onClick={() => openSettlementFor(w, w.pendingSalary)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                        title="Custom settlement details"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>Adjust</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Desktop Table */}
          <div className="hidden lg:block overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Worker / Labour</th>
                  <th className="py-3 px-4">Role &amp; Contact</th>
                  <th className="py-3 px-4">Wage Basis</th>
                  <th className="py-3 px-4 text-right">Calculated Salary (₹)</th>
                  <th className="py-3 px-4 text-right">Issued Salary (₹)</th>
                  <th className="py-3 px-4 text-right">Pending Salary (₹)</th>
                  <th className="py-3 px-4 text-right">Advance Loan</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Action (சம்பளம் கொடு)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredLedger.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                      <div>{w.name}</div>
                      {w.lastVoucher && (
                        <div className="text-[10px] text-slate-400 font-mono">Last Vch: {w.lastVoucher}</div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="bg-slate-100 text-slate-800 text-[10px] font-semibold px-2 py-0.5 rounded">
                        {w.role}
                      </span>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">{w.phone}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      <div className="font-semibold">{w.wageType}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {w.wageType === 'Piece Rate' ? `₹${w.wageRate.toFixed(2)} / pic` : w.wageType === 'Daily' ? `₹${w.wageRate} / day` : `₹${w.wageRate} / mo`}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                      <div>₹{w.calculatedSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-slate-400 font-normal">
                        {w.wageType === 'Piece Rate' ? `${Math.round(w.calculatedSalary / (w.wageRate || 1))} pcs calc` : w.wageType === 'Daily' ? '6 days' : '1 month'}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                      <div>₹{w.issuedSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-emerald-600 font-normal">{w.paymentsCount} paid</div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-rose-600 tabular-nums">
                      <div>₹{w.pendingSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-rose-500 font-normal">
                        {w.pendingSalary > 0 ? 'Pending' : 'Settled'}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-600 tabular-nums">
                      {w.pendingAdvance > 0 ? (
                        <span className="text-amber-800 font-semibold">₹{w.pendingAdvance.toLocaleString()}</span>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 text-[10px] font-bold uppercase rounded-full border ${
                          w.status === 'Completed'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : w.status === 'Issued'
                            ? 'bg-blue-50 text-blue-800 border-blue-300'
                            : 'bg-amber-50 text-amber-800 border-amber-300'
                        }`}
                      >
                        {w.status === 'Completed' && '✓ Completed'}
                        {w.status === 'Issued' && '● Issued'}
                        {w.status === 'Pending' && '⏳ Pending'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {w.pendingSalary > 0 ? (
                          <button
                            onClick={() => handleQuickIssue(w)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
                            title="Quick Issue full calculated pending salary and mark Completed"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Issue (₹{w.pendingSalary.toLocaleString()})</span>
                          </button>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                            ✓ Completed
                          </span>
                        )}

                        <button
                          onClick={() => openSettlementFor(w, w.pendingSalary)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                          title="Custom settlement details"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                          <span>Adjust</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- TAB 2: LABOUR ROSTER --- */}
      {activeSubTab === 'roster' && (
        <div className="space-y-3">
          {/* Mobile Cards */}
          <div className="block md:hidden space-y-2.5">
            {labour.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-500">
                No workers registered yet. Click "+ Add Worker" above.
              </div>
            ) : (
              labour.map((l) => {
                const pendingAdv = advances
                  .filter((a) => a.labourId === l.id && a.status === 'Pending Deduction')
                  .reduce((sum, a) => sum + a.amount, 0);

                return (
                  <div
                    key={l.id}
                    className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">{l.name}</h4>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-[10px] font-semibold">
                            {l.role}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">{l.phone || 'No phone'}</span>
                        </div>
                      </div>

                      <span
                        className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                          l.status === 'Active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {l.status}
                      </span>
                    </div>

                    {/* Salary Fix Details */}
                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block">Fixed Wage Rate:</span>
                        <span className="font-mono font-bold text-slate-900">
                          ₹{l.wageRate.toFixed(2)}
                          <span className="text-[10px] text-slate-500 font-normal ml-1">
                            {l.wageType === 'Piece Rate' ? '/ 1 pic' : l.wageType === 'Daily' ? '/ day' : '/ month'}
                          </span>
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">Pending Advance:</span>
                        {pendingAdv > 0 ? (
                          <span className="font-mono font-bold text-amber-600">₹{pendingAdv.toFixed(2)}</span>
                        ) : (
                          <span className="text-slate-400 font-mono">₹0.00</span>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                      <button
                        onClick={() => openSettlementFor(l)}
                        className="flex-1 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold text-center cursor-pointer"
                      >
                        Issue Salary
                      </button>
                      <button
                        onClick={() => {
                          setAdvanceLabourId(l.id);
                          setIsAddAdvanceModal(true);
                        }}
                        className="py-1.5 px-3 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        + Advance
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Desktop Table */}
          <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Worker Name</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Contact Phone</th>
                  <th className="py-3 px-4">Wage System</th>
                  <th className="py-3 px-4 text-right">Fixed Rate</th>
                  <th className="py-3 px-4 text-right">Pending Advance</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {labour.map((l) => {
                  const pendingAdv = advances
                    .filter((a) => a.labourId === l.id && a.status === 'Pending Deduction')
                    .reduce((sum, a) => sum + a.amount, 0);

                  return (
                    <tr key={l.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4 font-bold text-slate-900">{l.name}</td>
                      <td className="py-3 px-4">
                        <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-[11px] font-semibold">
                          {l.role}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">{l.phone || '—'}</td>
                      <td className="py-3 px-4 text-slate-700 font-medium">{l.wageType}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        ₹{l.wageRate.toFixed(2)}
                        <span className="text-[10px] text-slate-400 font-normal ml-1">
                          {l.wageType === 'Piece Rate' ? '/ 1 pic' : l.wageType === 'Daily' ? '/ day' : '/ month'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono">
                        {pendingAdv > 0 ? (
                          <span className="text-amber-800 font-bold">₹{pendingAdv.toFixed(2)}</span>
                        ) : (
                          <span className="text-slate-400">₹0.00</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded ${
                            l.status === 'Active'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {l.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setAdvanceLabourId(l.id);
                              setIsAddAdvanceModal(true);
                            }}
                            className="px-2.5 py-1 text-xs border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded font-semibold cursor-pointer"
                          >
                            + Advance
                          </button>
                          <button
                            onClick={() => openSettlementFor(l)}
                            className="px-3 py-1 text-xs bg-emerald-600 hover:bg-emerald-500 text-white rounded font-bold cursor-pointer"
                          >
                            Issue Salary
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- TAB 3: ADVANCE LOANS --- */}
      {activeSubTab === 'advances' && (
        <div className="space-y-3">
          <div className="block md:hidden space-y-2.5">
            {advances.map((adv) => (
              <div key={adv.id} className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{adv.labourName}</h4>
                    <span className="text-[11px] text-slate-400 font-mono">{adv.date}</span>
                  </div>
                  <span className="font-mono text-base font-bold text-amber-600">
                    ₹{adv.amount.toFixed(2)}
                  </span>
                </div>
                <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded">{adv.reason}</p>
                <div className="flex justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-100">
                  <span>By: {adv.recordedBy}</span>
                  <span className={adv.status === 'Pending Deduction' ? 'text-amber-600 font-bold' : 'text-slate-400'}>
                    {adv.status}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Worker Name</th>
                  <th className="py-3 px-4 text-right">Advance Amount (₹)</th>
                  <th className="py-3 px-4">Reason / Notes</th>
                  <th className="py-3 px-4">Approved By</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {advances.map((adv) => (
                  <tr key={adv.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-600">{adv.date}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{adv.labourName}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-amber-600">
                      ₹{adv.amount.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-slate-600">{adv.reason}</td>
                    <td className="py-3 px-4 text-slate-500">{adv.recordedBy}</td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded ${
                          adv.status === 'Pending Deduction'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {adv.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- TAB 4: SALARY VOUCHERS --- */}
      {activeSubTab === 'payments' && (
        <div className="space-y-3">
          <div className="block md:hidden space-y-2.5">
            {payments.map((p) => (
              <div key={p.id} className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-mono text-xs font-bold text-amber-600">{p.voucherNumber}</span>
                    <h4 className="text-sm font-bold text-slate-900">{p.labourName}</h4>
                    <span className="text-[10px] text-slate-400">{p.period}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-base font-bold text-emerald-700 block">
                      ₹{p.netPaid.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-slate-400 block">{p.paymentMode}</span>
                  </div>
                </div>
                {p.status && (
                  <span className="inline-block px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-50 text-emerald-800 border border-emerald-300">
                    {p.status}
                  </span>
                )}
                {p.notes && <p className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded">{p.notes}</p>}
              </div>
            ))}
          </div>

          <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Voucher #</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Worker Name</th>
                  <th className="py-3 px-4">Work / Period</th>
                  <th className="py-3 px-4 text-right">Gross (₹)</th>
                  <th className="py-3 px-4 text-right">Advance Deducted (₹)</th>
                  <th className="py-3 px-4 text-right">Net Paid (₹)</th>
                  <th className="py-3 px-4 text-center">Mode</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {payments.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-amber-600">{p.voucherNumber}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">{p.paymentDate}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{p.labourName}</td>
                    <td className="py-3 px-4 text-slate-600">{p.period}</td>
                    <td className="py-3 px-4 text-right font-mono text-slate-700">₹{p.grossAmount.toFixed(2)}</td>
                    <td className="py-3 px-4 text-right font-mono text-rose-600">
                      {p.advanceDeducted > 0 ? `-₹${p.advanceDeducted.toFixed(2)}` : '—'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                      ₹{p.netPaid.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-center font-medium text-slate-600">{p.paymentMode}</td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-block px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-50 text-emerald-800 border border-emerald-300">
                        {p.status || 'Completed'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- ADD LABOUR MODAL --- */}
      {isAddLabourModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold">Register New Labour / Worker</h3>
              </div>
              <button
                onClick={() => setIsAddLabourModal(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreateLabour} id="add-labour-form" className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Worker Name *
                </label>
                <input
                  type="text"
                  required
                  value={labourName}
                  onChange={(e) => setLabourName(e.target.value)}
                  placeholder="e.g. M. Chinnasamy"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Role / Trade *
                  </label>
                  <select
                    value={labourRole}
                    onChange={(e) => setLabourRole(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Loader">Loader (ஏற்றுபவர்)</option>
                    <option value="Machine Operator">Machine Operator</option>
                    <option value="Mason">Mason (கொத்தனார்)</option>
                    <option value="Driver">Driver (ஓட்டுநர்)</option>
                    <option value="Helper">Helper (உதவியாளர்)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={labourPhone}
                    onChange={(e) => setLabourPhone(e.target.value)}
                    placeholder="+91 98421..."
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Wage System Setting */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <label className="block text-xs font-bold text-slate-900">
                  Fixed Wage System:
                </label>

                <div className="grid grid-cols-3 gap-1.5 p-1 bg-white rounded-lg border border-slate-200">
                  {(['Piece Rate', 'Daily', 'Monthly'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => {
                        setLabourWageType(type);
                        if (type === 'Piece Rate') setLabourWageRate(2.5);
                        else if (type === 'Daily') setLabourWageRate(650);
                        else setLabourWageRate(20000);
                      }}
                      className={`py-1.5 px-2 rounded text-xs font-semibold text-center transition-all cursor-pointer ${
                        labourWageType === type
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                          : 'text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {type === 'Piece Rate' ? '1 Piece' : type === 'Daily' ? 'Daily' : 'Monthly'}
                    </button>
                  ))}
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {labourWageType === 'Piece Rate' && 'Rate per 1 Piece (₹/pic) *'}
                    {labourWageType === 'Daily' && 'Daily Wage Rate (₹/day) *'}
                    {labourWageType === 'Monthly' && 'Monthly Salary (₹/month) *'}
                  </label>

                  <input
                    type="number"
                    step="any"
                    required
                    value={labourWageRate}
                    onChange={(e) => setLabourWageRate(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg bg-white"
                  />
                </div>
              </div>
            </form>

            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsAddLabourModal(false)}
                className="px-3.5 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="add-labour-form"
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Save Worker
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- RECORD ADVANCE MODAL --- */}
      {isAddAdvanceModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold">Record Cash Advance</h3>
              </div>
              <button
                onClick={() => setIsAddAdvanceModal(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreateAdvance} id="advance-form" className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Worker / Labour *
                </label>
                <select
                  value={advanceLabourId}
                  onChange={(e) => setAdvanceLabourId(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  {labour.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.role})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Advance Amount (₹) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="100"
                    required
                    value={advanceAmount}
                    onChange={(e) => setAdvanceAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Disbursement Date
                  </label>
                  <input
                    type="date"
                    required
                    value={advanceDate}
                    onChange={(e) => setAdvanceDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Reason / Purpose
                </label>
                <input
                  type="text"
                  value={advanceReason}
                  onChange={(e) => setAdvanceReason(e.target.value)}
                  placeholder="e.g. Festival advance, Medical, Rent"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                />
              </div>
            </form>

            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsAddAdvanceModal(false)}
                className="px-3.5 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="advance-form"
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Disburse Advance
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- SALARY SETTLEMENT MODAL --- */}
      {isSettlementModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-sm font-bold">Issue Salary / Wages (சம்பளம் வழங்குக)</h3>
                  <p className="text-[11px] text-slate-400">
                    Disburse wage payment voucher and update status to Issued / Completed
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsSettlementModal(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreatePayment} id="settlement-form" className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Worker / Labour *
                </label>
                <select
                  value={settlementLabourId}
                  onChange={(e) => {
                    const lId = e.target.value;
                    setSettlementLabourId(lId);
                    const sel = labour.find((l) => l.id === lId);
                    if (sel) {
                      setSettlementWageType(sel.wageType);
                      if (sel.wageType === 'Piece Rate') setSettlementPieceRate(sel.wageRate);
                      else if (sel.wageType === 'Daily') setSettlementDailyRate(sel.wageRate);
                      else setSettlementMonthlyRate(sel.wageRate);
                    }
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  {labour.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name} — ({l.wageType === 'Piece Rate' ? `₹${l.wageRate}/pic` : l.wageType === 'Daily' ? `₹${l.wageRate}/day` : `₹${l.wageRate}/mo`})
                    </option>
                  ))}
                </select>
              </div>

              {/* Wage Calculation Mode */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <label className="block text-xs font-bold text-slate-900">
                  Calculation Mode:
                </label>

                <div className="grid grid-cols-3 gap-1.5 p-1 bg-white rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setSettlementWageType('Piece Rate')}
                    className={`py-1.5 px-2 rounded text-xs font-semibold text-center transition-all cursor-pointer ${
                      settlementWageType === 'Piece Rate'
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    1 Piece Rate
                  </button>
                  <button
                    type="button"
                    onClick={() => setSettlementWageType('Daily')}
                    className={`py-1.5 px-2 rounded text-xs font-semibold text-center transition-all cursor-pointer ${
                      settlementWageType === 'Daily'
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Daily Wage
                  </button>
                  <button
                    type="button"
                    onClick={() => setSettlementWageType('Monthly')}
                    className={`py-1.5 px-2 rounded text-xs font-semibold text-center transition-all cursor-pointer ${
                      settlementWageType === 'Monthly'
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Monthly Fixed
                  </button>
                </div>

                {settlementWageType === 'Piece Rate' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Pieces Produced (Pcs):
                      </label>
                      <input
                        type="number"
                        min="1"
                        required
                        value={settlementPiecesProduced}
                        onChange={(e) => setSettlementPiecesProduced(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Rate per 1 Piece (₹/pic):
                      </label>
                      <input
                        type="number"
                        step="any"
                        min="0.1"
                        required
                        value={settlementPieceRate}
                        onChange={(e) => setSettlementPieceRate(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>
                )}

                {settlementWageType === 'Daily' && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Days / Shifts Worked:
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="31"
                        required
                        value={settlementDays}
                        onChange={(e) => setSettlementDays(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Daily Wage Rate (₹/day):
                      </label>
                      <input
                        type="number"
                        step="any"
                        required
                        value={settlementDailyRate}
                        onChange={(e) => setSettlementDailyRate(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 font-mono font-bold border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>
                )}

                {settlementWageType === 'Monthly' && (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Monthly Salary Amount (₹):
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={settlementMonthlyRate}
                      onChange={(e) => setSettlementMonthlyRate(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 font-mono font-bold border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                )}
              </div>

              {/* Advance Deduction & Mode */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Advance to Deduct (₹)
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={settlementAdvanceDeduction}
                    onChange={(e) => setSettlementAdvanceDeduction(Number(e.target.value))}
                    className="w-full px-3 py-1.5 font-mono border border-slate-300 rounded-lg text-rose-600 font-bold"
                  />
                  {pendingAdvancesForTarget > 0 && (
                    <span className="text-[10px] text-amber-700 block mt-0.5">
                      Max pending advance: ₹{pendingAdvancesForTarget}
                    </span>
                  )}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Payment Mode
                  </label>
                  <select
                    value={settlementMode}
                    onChange={(e) => setSettlementMode(e.target.value as any)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Cash">Cash Voucher</option>
                    <option value="UPI">UPI / GPay / PhonePe</option>
                    <option value="Bank">Bank NEFT/IMPS</option>
                  </select>
                </div>
              </div>

              {/* Status to Mark */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Salary Status to Apply
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSettlementStatus('Completed')}
                    className={`p-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      settlementStatus === 'Completed'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    ✓ Completed (முழுதும் வழங்கப்பட்டது)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSettlementStatus('Issued')}
                    className={`p-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                      settlementStatus === 'Issued'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    ● Issued (வழங்கப்பட்டது)
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Wage Period / Description
                </label>
                <input
                  type="text"
                  value={settlementPeriod}
                  onChange={(e) => setSettlementPeriod(e.target.value)}
                  placeholder="e.g. Oct 11 - 17 Weekly Batch"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg"
                />
              </div>

              {/* Settlement Calculation Box */}
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span>Gross Wage Calculation:</span>
                  <span className="font-mono font-bold text-slate-900">₹{grossWage.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-rose-600">
                  <span>Advance Loan Deduction:</span>
                  <span className="font-mono font-bold">-₹{Number(settlementAdvanceDeduction).toFixed(2)}</span>
                </div>
                <div className="flex justify-between pt-1.5 border-t border-amber-300 font-bold text-slate-950 text-sm">
                  <span>Net Payable Amount:</span>
                  <span className="text-emerald-700 font-mono text-base">₹{netPayable.toFixed(2)}</span>
                </div>
              </div>
            </form>

            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsSettlementModal(false)}
                className="px-3.5 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="settlement-form"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Disburse &amp; Mark {settlementStatus}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
