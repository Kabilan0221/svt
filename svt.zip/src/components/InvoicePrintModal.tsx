import React, { useState } from 'react';
import { Invoice, Estimation } from '../types';
import { Printer, X, FileText, CheckCircle2 } from 'lucide-react';

interface Props {
  invoice?: Invoice;
  estimation?: Estimation;
  onClose: () => void;
}

export const InvoicePrintModal: React.FC<Props> = ({ invoice, estimation, onClose }) => {
  const [printFormat, setPrintFormat] = useState<'a4' | 'thermal'>('a4');
  const data = invoice || estimation;
  if (!data) return null;

  const isEstimation = !!estimation;
  const docTitle = isEstimation ? 'ESTIMATION / QUOTATION' : 'TAX INVOICE / CASH BILL';
  const docNumber = isEstimation ? (data as Estimation).estimationNumber : (data as Invoice).invoiceNumber;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 no-print-backdrop">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Action Header - Hidden when printing */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between no-print border-b border-slate-800">
          <div className="flex items-center gap-3">
            <FileText className="w-5 h-5 text-amber-400" />
            <div>
              <span className="font-semibold text-sm tracking-wide">
                {isEstimation ? 'Print Estimation' : 'Print Invoice'} · {docNumber}
              </span>
              <p className="text-xs text-slate-400">ஸ்ரீ வெங்கடேஸ்வரா Official Bill</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-800 p-0.5 rounded-lg text-xs font-medium mr-2">
              <button
                onClick={() => setPrintFormat('a4')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  printFormat === 'a4' ? 'bg-amber-500 text-slate-950 font-semibold' : 'text-slate-300 hover:text-white'
                }`}
              >
                Standard A4
              </button>
              <button
                onClick={() => setPrintFormat('thermal')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  printFormat === 'thermal' ? 'bg-amber-500 text-slate-950 font-semibold' : 'text-slate-300 hover:text-white'
                }`}
              >
                Thermal (80mm)
              </button>
            </div>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              Print
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Document Area */}
        <div className="overflow-y-auto p-4 sm:p-8 bg-slate-100 flex justify-center">
          <div
            id="printable-document"
            className={`bg-white shadow-sm border border-slate-300 text-slate-900 print-container ${
              printFormat === 'a4' ? 'w-full max-w-[700px] p-8' : 'w-[360px] p-4 text-xs font-mono'
            }`}
          >
            {/* Business Header */}
            <div className="text-center pb-4 border-b-2 border-slate-900">
              <p className="text-[11px] font-bold text-slate-800 tracking-wide">என் தாய் தந்தை துணை</p>
              
              <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-800 font-semibold mt-1 px-1 gap-1">
                <span>உரிமை: பெரியநத்தம் வெ.பெருமாள் நாயகர்</span>
                <span className="font-mono">📱 958578 1947, 904706 1947</span>
              </div>

              <h1 className="text-2xl font-black tracking-tight text-slate-950 uppercase mt-1">
                ஸ்ரீ வெங்கடேஸ்வரா
              </h1>
              <h2 className="text-base font-bold text-slate-900 tracking-wide mt-0.5">
                ஹாலோ பிளாக்ஸ் &amp; ஃபிளை ஆஷ் செங்கற்கள்
              </h2>
              <p className="text-xs font-semibold text-amber-900 uppercase tracking-wider mt-0.5">
                Sri Venkateswara (SVT) Hollow Blocks &amp; Fly Ash Bricks
              </p>
              <p className="text-[11px] text-slate-700 font-medium mt-1">
                எங்களிடம் 4”, 6”, 8” ஆகிய அளவுகளில் ஹாலோ மற்றும் ஃபிளை ஆஷ் செங்கற்கள் தரமானதாக கிடைக்கும்.
              </p>
              <div className="mt-1.5 p-1.5 bg-slate-50 border border-slate-200 rounded text-[11px] font-semibold text-slate-900">
                📍 குருவிமலை கிராமம், களக்காட்டூர் அஞ்சல், உத்திரமேரூர் ரோடு, காஞ்சிபுரம் - 631 502.
              </div>
              <div className="mt-2 inline-block px-3 py-0.5 bg-slate-900 text-amber-400 text-xs font-bold tracking-wider rounded uppercase">
                {docTitle}
              </div>
            </div>

            {/* Bill Meta Data */}
            <div className="grid grid-cols-2 gap-4 py-3 border-b border-slate-200 text-xs">
              <div>
                <p className="text-slate-500">Billed To (Customer):</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{data.customerName}</p>
                {data.customerPhone && <p className="text-slate-600">Ph: {data.customerPhone}</p>}
                {data.customerAddress && <p className="text-slate-600 mt-0.5 text-[11px]">{data.customerAddress}</p>}
              </div>

              <div className="text-right">
                <p>
                  <span className="text-slate-500">Doc No:</span>{' '}
                  <span className="font-bold font-mono text-slate-900">{docNumber}</span>
                </p>
                <p className="mt-0.5">
                  <span className="text-slate-500">Date:</span>{' '}
                  <span className="font-semibold text-slate-800">{data.date}</span>
                </p>
                {data.vehicleNumber && (
                  <p className="mt-0.5">
                    <span className="text-slate-500">Vehicle / Lorry No:</span>{' '}
                    <span className="font-bold font-mono text-slate-900 bg-amber-50 px-1 border border-amber-200 rounded">
                      {data.vehicleNumber}
                    </span>
                  </p>
                )}
                {!isEstimation && (
                  <p className="mt-0.5">
                    <span className="text-slate-500">Payment:</span>{' '}
                    <span className="font-semibold text-slate-900">{(data as Invoice).paymentMode}</span>
                  </p>
                )}
              </div>
            </div>

            {/* Line Items Table */}
            <table className="w-full text-left my-3 border-collapse text-xs">
              <thead>
                <tr className="border-b-2 border-slate-900 bg-slate-50 text-slate-800 font-bold">
                  <th className="py-2 px-1 text-center w-8">#</th>
                  <th className="py-2 px-2">Description</th>
                  <th className="py-2 px-2 text-center w-16">Unit</th>
                  <th className="py-2 px-2 text-right w-16">Qty</th>
                  <th className="py-2 px-2 text-right w-20">Rate (₹)</th>
                  <th className="py-2 px-2 text-right w-24">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {data.items.map((item, idx) => (
                  <tr key={item.id} className="text-slate-800">
                    <td className="py-2 px-1 text-center font-mono text-slate-500">{idx + 1}</td>
                    <td className="py-2 px-2 font-medium">{item.productName}</td>
                    <td className="py-2 px-2 text-center text-slate-600">{item.unit}</td>
                    <td className="py-2 px-2 text-right font-mono font-semibold">{item.quantity}</td>
                    <td className="py-2 px-2 text-right font-mono">{item.rate.toFixed(2)}</td>
                    <td className="py-2 px-2 text-right font-mono font-bold">{item.total.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Calculations Breakdown */}
            <div className="pt-2 border-t-2 border-slate-900 grid grid-cols-2 gap-4 text-xs">
              <div className="space-y-1 text-slate-600">
                <p className="font-semibold text-slate-800">Terms & Conditions:</p>
                <p className="text-[10px] leading-tight text-slate-500">
                  1. Goods once sold will not be taken back or exchanged.
                  <br />
                  2. All disputes subject to local jurisdiction only.
                  <br />
                  3. Loading & unloading as agreed between merchant & customer.
                </p>
                {!isEstimation && (data as Invoice).notes && (
                  <p className="text-[11px] text-slate-700 bg-slate-50 p-1.5 rounded border border-slate-200">
                    <span className="font-semibold">Note:</span> {(data as Invoice).notes}
                  </p>
                )}
              </div>

              <div className="space-y-1.5 text-right font-mono text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal:</span>
                  <span>₹{data.subtotal.toFixed(2)}</span>
                </div>

                {/* Notebook specifications: Loading & Unloading Rates */}
                {data.loadingRate > 0 && (
                  <div className="flex justify-between text-slate-700">
                    <span>Loading Charges:</span>
                    <span>₹{data.loadingRate.toFixed(2)}</span>
                  </div>
                )}

                {data.unloadingRate > 0 && (
                  <div className="flex justify-between text-slate-700">
                    <span>Unloading Charges:</span>
                    <span>₹{data.unloadingRate.toFixed(2)}</span>
                  </div>
                )}

                {data.freightCharges > 0 && (
                  <div className="flex justify-between text-slate-700">
                    <span>Transport / Freight:</span>
                    <span>₹{data.freightCharges.toFixed(2)}</span>
                  </div>
                )}

                {data.discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount:</span>
                    <span>-₹{data.discount.toFixed(2)}</span>
                  </div>
                )}

                {data.taxAmount > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>GST ({data.taxPercent}%):</span>
                    <span>₹{data.taxAmount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between pt-2 border-t border-slate-900 text-sm font-bold text-slate-950">
                  <span className="font-sans">Grand Total:</span>
                  <span>₹{data.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                </div>

                {!isEstimation && (
                  <div className="pt-1 text-xs">
                    <div className="flex justify-between text-slate-700">
                      <span>Amount Paid:</span>
                      <span>₹{(data as Invoice).amountPaid.toFixed(2)}</span>
                    </div>
                    {(data as Invoice).balanceDue > 0 ? (
                      <div className="flex justify-between text-rose-600 font-bold">
                        <span>Balance Due:</span>
                        <span>₹{(data as Invoice).balanceDue.toFixed(2)}</span>
                      </div>
                    ) : (
                      <div className="flex justify-end items-center gap-1 text-emerald-600 font-bold text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Fully Paid
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Signature Area */}
            <div className="mt-8 pt-4 border-t border-dashed border-slate-300 flex justify-between items-end text-xs text-slate-600">
              <div className="text-center">
                <div className="h-10"></div>
                <p className="border-t border-slate-400 pt-1 px-4">Customer Signature</p>
              </div>
              <div className="text-center">
                <p className="text-[11px] font-semibold text-slate-800">For ஸ்ரீ வெங்கடேஸ்வரா (SRI SVT TRADERS)</p>
                <div className="h-8"></div>
                <p className="border-t border-slate-400 pt-1 px-4">Authorized Signatory</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
