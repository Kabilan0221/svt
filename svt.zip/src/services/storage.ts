import {
  Product,
  ProductionLog,
  Invoice,
  Estimation,
  Labour,
  LabourAdvance,
  LabourPayment,
  User,
  InboundEntry,
} from '../types';
import {
  initialProducts,
  initialLabour,
  initialLabourAdvances,
  initialLabourPayments,
  initialProductionLogs,
  initialInvoices,
  initialEstimations,
  initialUsers,
  initialInbounds,
} from '../data/initialData';

const KEYS = {
  PRODUCTS: 'svt_products_v1',
  LABOUR: 'svt_labour_v1',
  LABOUR_ADVANCES: 'svt_labour_advances_v1',
  LABOUR_PAYMENTS: 'svt_labour_payments_v1',
  PRODUCTION_LOGS: 'svt_production_logs_v1',
  INVOICES: 'svt_invoices_v1',
  ESTIMATIONS: 'svt_estimations_v1',
  INBOUNDS: 'svt_inbounds_v1',
  USERS: 'svt_users_v2',
  CURRENT_USER: 'svt_current_user_v2',
  AUTH_STATE: 'svt_is_authenticated_v2',
  API_CONFIG: 'svt_api_config_v1',
};

export interface ApiConfig {
  mode: 'local' | 'infinityfree';
  infinityFreeApiUrl: string;
}

export class StorageService {
  private static getItem<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private static setItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('LocalStorage write failed:', e);
    }
  }

  // --- Users, Login & Permissions ---
  static getUsers(): User[] {
    return this.getItem<User[]>(KEYS.USERS, initialUsers);
  }

  static saveUser(user: Omit<User, 'id' | 'createdDate'> & { id?: string }): User {
    const users = this.getUsers();
    if (user.id) {
      const idx = users.findIndex((u) => u.id === user.id);
      if (idx !== -1) {
        users[idx] = { ...users[idx], ...user };
        this.setItem(KEYS.USERS, users);
        // If current user updated, sync
        const current = this.getCurrentUser();
        if (current && current.id === user.id) {
          this.setCurrentUser(users[idx]);
        }
        return users[idx];
      }
    }

    const newUser: User = {
      ...user,
      id: `usr-${Date.now()}`,
      createdDate: new Date().toISOString().split('T')[0],
    };
    users.push(newUser);
    this.setItem(KEYS.USERS, users);
    return newUser;
  }

  static deleteUser(userId: string): void {
    const users = this.getUsers().filter((u) => u.id !== userId);
    this.setItem(KEYS.USERS, users);
  }

  static getCurrentUser(): User {
    return this.getItem<User>(KEYS.CURRENT_USER, initialUsers[0]);
  }

  static setCurrentUser(user: User): void {
    this.setItem(KEYS.CURRENT_USER, user);
  }

  static isAuthenticated(): boolean {
    return this.getItem<boolean>(KEYS.AUTH_STATE, true);
  }

  static setAuthenticated(state: boolean): void {
    this.setItem(KEYS.AUTH_STATE, state);
  }

  static login(username: string, password: string, requiredRole?: 'owner' | 'manager'): { success: boolean; user?: User; error?: string } {
    const users = this.getUsers();
    const cleanUser = username.trim().toLowerCase();
    const matched = users.find((u) => u.username.toLowerCase() === cleanUser);

    if (!matched) {
      return { success: false, error: 'Username not recognized.' };
    }

    if (matched.status === 'Inactive') {
      return { success: false, error: 'This user account is currently deactivated. Contact the Owner.' };
    }

    if (matched.password && matched.password !== password) {
      return { success: false, error: 'Incorrect password or PIN.' };
    }

    if (requiredRole && matched.role !== requiredRole && !(requiredRole === 'manager' && matched.role === 'owner')) {
      return { success: false, error: `This account does not have ${requiredRole} credentials.` };
    }

    // Update last login
    matched.lastLogin = new Date().toLocaleString();
    this.saveUser(matched);
    this.setCurrentUser(matched);
    this.setAuthenticated(true);

    return { success: true, user: matched };
  }

  static logout(): void {
    this.setAuthenticated(false);
  }

  // --- API Config ---
  static getApiConfig(): ApiConfig {
    return this.getItem<ApiConfig>(KEYS.API_CONFIG, {
      mode: 'local',
      infinityFreeApiUrl: 'https://srisvttraders.infinityfreeapp.com/api',
    });
  }

  static setApiConfig(config: ApiConfig): void {
    this.setItem(KEYS.API_CONFIG, config);
  }

  // --- Products ---
  static getProducts(): Product[] {
    return this.getItem<Product[]>(KEYS.PRODUCTS, initialProducts);
  }

  static saveProduct(product: Omit<Product, 'id' | 'lastUpdated'> & { id?: string }): Product {
    const products = this.getProducts();
    const now = new Date().toISOString().split('T')[0];

    if (product.id) {
      const idx = products.findIndex((p) => p.id === product.id);
      if (idx !== -1) {
        products[idx] = { ...products[idx], ...product, lastUpdated: now };
        this.setItem(KEYS.PRODUCTS, products);
        return products[idx];
      }
    }

    const newProduct: Product = {
      ...product,
      id: `prod-${Date.now()}`,
      lastUpdated: now,
    };
    products.push(newProduct);
    this.setItem(KEYS.PRODUCTS, products);
    return newProduct;
  }

  static deleteProduct(productId: string): void {
    const products = this.getProducts().filter((p) => p.id !== productId);
    this.setItem(KEYS.PRODUCTS, products);
  }

  static adjustStock(productId: string, quantityDelta: number): void {
    const products = this.getProducts();
    const idx = products.findIndex((p) => p.id === productId);
    if (idx !== -1) {
      products[idx].stockQuantity = Math.max(0, Number((products[idx].stockQuantity + quantityDelta).toFixed(2)));
      products[idx].lastUpdated = new Date().toISOString().split('T')[0];
      this.setItem(KEYS.PRODUCTS, products);
    }
  }

  // --- Production Management ---
  static getProductionLogs(): ProductionLog[] {
    return this.getItem<ProductionLog[]>(KEYS.PRODUCTION_LOGS, initialProductionLogs);
  }

  static addProductionLog(log: Omit<ProductionLog, 'id' | 'createdAt'>): ProductionLog {
    const logs = this.getProductionLogs();
    const newLog: ProductionLog = {
      ...log,
      id: `prodlog-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    logs.unshift(newLog);
    this.setItem(KEYS.PRODUCTION_LOGS, logs);

    // Auto update product stock
    this.adjustStock(log.productId, log.quantity);

    return newLog;
  }

  static deleteProductionLog(logId: string): void {
    const logs = this.getProductionLogs();
    const log = logs.find((l) => l.id === logId);
    if (log) {
      // Revert the stock
      this.adjustStock(log.productId, -log.quantity);
      const filtered = logs.filter((l) => l.id !== logId);
      this.setItem(KEYS.PRODUCTION_LOGS, filtered);
    }
  }

  // --- Invoices / Billing ---
  static getInvoices(): Invoice[] {
    return this.getItem<Invoice[]>(KEYS.INVOICES, initialInvoices);
  }

  static generateInvoiceNumber(): string {
    const invoices = this.getInvoices();
    let maxNum = 1024;
    invoices.forEach((inv) => {
      const parts = inv.invoiceNumber.split('-');
      const num = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(num) && num > maxNum) {
        maxNum = num;
      }
    });
    return `SVT-INV-${maxNum + 1}`;
  }

  static addInvoice(invoice: Omit<Invoice, 'id' | 'createdAt'>): Invoice {
    const invoices = this.getInvoices();
    const newInvoice: Invoice = {
      ...invoice,
      id: `inv-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    invoices.unshift(newInvoice);
    this.setItem(KEYS.INVOICES, invoices);

    // Automatically deduct items from product stock
    invoice.items.forEach((item) => {
      this.adjustStock(item.productId, -item.quantity);
    });

    return newInvoice;
  }

  static updateInvoicePayment(invoiceId: string, paymentStatus: Invoice['paymentStatus'], amountPaid: number): void {
    const invoices = this.getInvoices();
    const idx = invoices.findIndex((i) => i.id === invoiceId);
    if (idx !== -1) {
      const inv = invoices[idx];
      inv.paymentStatus = paymentStatus;
      inv.amountPaid = amountPaid;
      inv.balanceDue = Math.max(0, inv.grandTotal - amountPaid);
      this.setItem(KEYS.INVOICES, invoices);
    }
  }

  static deleteInvoice(invoiceId: string): void {
    const invoices = this.getInvoices();
    const inv = invoices.find((i) => i.id === invoiceId);
    if (inv) {
      // Restore stock
      inv.items.forEach((item) => {
        this.adjustStock(item.productId, item.quantity);
      });
      const filtered = invoices.filter((i) => i.id !== invoiceId);
      this.setItem(KEYS.INVOICES, filtered);
    }
  }

  // --- Estimations ---
  static getEstimations(): Estimation[] {
    return this.getItem<Estimation[]>(KEYS.ESTIMATIONS, initialEstimations);
  }

  static generateEstimationNumber(): string {
    const estimates = this.getEstimations();
    let maxNum = 2002;
    estimates.forEach((est) => {
      const parts = est.estimationNumber.split('-');
      const num = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(num) && num > maxNum) {
        maxNum = num;
      }
    });
    return `SVT-EST-${maxNum + 1}`;
  }

  static addEstimation(estimation: Omit<Estimation, 'id' | 'createdAt'>): Estimation {
    const estimates = this.getEstimations();
    const newEst: Estimation = {
      ...estimation,
      id: `est-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    estimates.unshift(newEst);
    this.setItem(KEYS.ESTIMATIONS, estimates);
    return newEst;
  }

  static updateEstimationStatus(id: string, status: Estimation['status']): void {
    const estimates = this.getEstimations();
    const idx = estimates.findIndex((e) => e.id === id);
    if (idx !== -1) {
      estimates[idx].status = status;
      this.setItem(KEYS.ESTIMATIONS, estimates);
    }
  }

  static convertEstimationToInvoice(estimationId: string): Invoice | null {
    const estimates = this.getEstimations();
    const est = estimates.find((e) => e.id === estimationId);
    if (!est) return null;

    const invNum = this.generateInvoiceNumber();
    const newInvoice = this.addInvoice({
      invoiceNumber: invNum,
      date: new Date().toISOString().split('T')[0],
      customerName: est.customerName,
      customerPhone: est.customerPhone,
      customerAddress: est.customerAddress,
      vehicleNumber: est.vehicleNumber,
      items: est.items,
      subtotal: est.subtotal,
      loadingRate: est.loadingRate,
      unloadingRate: est.unloadingRate,
      freightCharges: est.freightCharges,
      discount: est.discount,
      taxPercent: est.taxPercent,
      taxAmount: est.taxAmount,
      grandTotal: est.grandTotal,
      paymentMode: 'Cash',
      paymentStatus: 'Paid',
      amountPaid: est.grandTotal,
      balanceDue: 0,
      notes: `Converted from Estimation ${est.estimationNumber}`,
    });

    // Mark estimation as converted
    this.updateEstimationStatus(estimationId, 'Converted to Bill');
    return newInvoice;
  }

  // --- Inbound Material Purchase & Stock Inward ---
  static getInbounds(): InboundEntry[] {
    return this.getItem<InboundEntry[]>(KEYS.INBOUNDS, initialInbounds);
  }

  static generateInboundNumber(): string {
    const list = this.getInbounds();
    let maxNum = 1004;
    list.forEach((item) => {
      const parts = item.inboundNumber.split('-');
      const num = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(num) && num > maxNum) {
        maxNum = num;
      }
    });
    return `SVT-INB-${maxNum + 1}`;
  }

  static addInbound(inbound: Omit<InboundEntry, 'id' | 'createdAt'>): InboundEntry {
    const list = this.getInbounds();
    const newInbound: InboundEntry = {
      ...inbound,
      id: `inb-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    list.unshift(newInbound);
    this.setItem(KEYS.INBOUNDS, list);

    // Note: Raw materials are purchased and recorded in the inward ledger.
    // Stock is only created when manufactured products are produced in Production.
    // Inbound does not directly add to finished product stock.

    return newInbound;
  }

  static updateInboundPayment(id: string, paymentStatus: InboundEntry['paymentStatus']): void {
    const list = this.getInbounds();
    const idx = list.findIndex((i) => i.id === id);
    if (idx !== -1) {
      list[idx].paymentStatus = paymentStatus;
      this.setItem(KEYS.INBOUNDS, list);
    }
  }

  static deleteInbound(id: string): void {
    const list = this.getInbounds();
    const filtered = list.filter((i) => i.id !== id);
    this.setItem(KEYS.INBOUNDS, filtered);
  }

  // --- Labour & Salary ---
  static getLabour(): Labour[] {
    return this.getItem<Labour[]>(KEYS.LABOUR, initialLabour);
  }

  static saveLabour(labour: Omit<Labour, 'id'> & { id?: string }): Labour {
    const list = this.getLabour();
    if (labour.id) {
      const idx = list.findIndex((l) => l.id === labour.id);
      if (idx !== -1) {
        list[idx] = { ...list[idx], ...labour };
        this.setItem(KEYS.LABOUR, list);
        return list[idx];
      }
    }
    const newLabour: Labour = {
      ...labour,
      id: `lab-${Date.now()}`,
    };
    list.push(newLabour);
    this.setItem(KEYS.LABOUR, list);
    return newLabour;
  }

  static getLabourAdvances(): LabourAdvance[] {
    return this.getItem<LabourAdvance[]>(KEYS.LABOUR_ADVANCES, initialLabourAdvances);
  }

  static addLabourAdvance(adv: Omit<LabourAdvance, 'id'>): LabourAdvance {
    const list = this.getLabourAdvances();
    const newAdv: LabourAdvance = {
      ...adv,
      id: `adv-${Date.now()}`,
    };
    list.unshift(newAdv);
    this.setItem(KEYS.LABOUR_ADVANCES, list);
    return newAdv;
  }

  static getLabourPayments(): LabourPayment[] {
    return this.getItem<LabourPayment[]>(KEYS.LABOUR_PAYMENTS, initialLabourPayments);
  }

  static addLabourPayment(payment: Omit<LabourPayment, 'id' | 'voucherNumber'>): LabourPayment {
    const payments = this.getLabourPayments();
    let maxNum = 502;
    payments.forEach((p) => {
      const parts = p.voucherNumber.split('-');
      const num = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(num) && num > maxNum) maxNum = num;
    });

    const newPayment: LabourPayment = {
      ...payment,
      id: `pay-${Date.now()}`,
      voucherNumber: `SVT-VCH-${maxNum + 1}`,
    };
    payments.unshift(newPayment);
    this.setItem(KEYS.LABOUR_PAYMENTS, payments);

    // If advance was deducted, update the pending advance status for this labour
    if (payment.advanceDeducted > 0) {
      const advances = this.getLabourAdvances();
      let remainingToDeduct = payment.advanceDeducted;
      for (const adv of advances) {
        if (adv.labourId === payment.labourId && adv.status === 'Pending Deduction') {
          if (adv.amount <= remainingToDeduct) {
            adv.status = 'Deducted';
            remainingToDeduct -= adv.amount;
          } else {
            // Partial deduction
            adv.amount -= remainingToDeduct;
            remainingToDeduct = 0;
            break;
          }
        }
        if (remainingToDeduct <= 0) break;
      }
      this.setItem(KEYS.LABOUR_ADVANCES, advances);
    }

    return newPayment;
  }

  // --- Full Backup & Reset ---
  static exportAllData(): string {
    const data = {
      products: this.getProducts(),
      productionLogs: this.getProductionLogs(),
      invoices: this.getInvoices(),
      estimations: this.getEstimations(),
      labour: this.getLabour(),
      labourAdvances: this.getLabourAdvances(),
      labourPayments: this.getLabourPayments(),
      inbounds: this.getInbounds(),
      exportedAt: new Date().toISOString(),
      appName: 'Sri SVT Traders ERP',
    };
    return JSON.stringify(data, null, 2);
  }

  static importData(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.products) this.setItem(KEYS.PRODUCTS, data.products);
      if (data.productionLogs) this.setItem(KEYS.PRODUCTION_LOGS, data.productionLogs);
      if (data.invoices) this.setItem(KEYS.INVOICES, data.invoices);
      if (data.estimations) this.setItem(KEYS.ESTIMATIONS, data.estimations);
      if (data.labour) this.setItem(KEYS.LABOUR, data.labour);
      if (data.labourAdvances) this.setItem(KEYS.LABOUR_ADVANCES, data.labourAdvances);
      if (data.labourPayments) this.setItem(KEYS.LABOUR_PAYMENTS, data.labourPayments);
      if (data.inbounds) this.setItem(KEYS.INBOUNDS, data.inbounds);
      return true;
    } catch {
      return false;
    }
  }

  static resetToDefault(): void {
    localStorage.removeItem(KEYS.PRODUCTS);
    localStorage.removeItem(KEYS.PRODUCTION_LOGS);
    localStorage.removeItem(KEYS.INVOICES);
    localStorage.removeItem(KEYS.ESTIMATIONS);
    localStorage.removeItem(KEYS.LABOUR);
    localStorage.removeItem(KEYS.LABOUR_ADVANCES);
    localStorage.removeItem(KEYS.LABOUR_PAYMENTS);
    localStorage.removeItem(KEYS.INBOUNDS);
  }
}
