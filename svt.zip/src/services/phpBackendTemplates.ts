export interface ExportFile {
  path: string;
  filename: string;
  category: 'config' | 'api' | 'database' | 'server' | 'android';
  description: string;
  content: string;
}

export const PHP_BACKEND_FILES: ExportFile[] = [
  {
    path: 'config/db.php',
    filename: 'db.php',
    category: 'config',
    description: 'PDO Database connection for InfinityFree MySQL with CORS headers and JSON response helpers.',
    content: `<?php
/**
 * Sri SVT Traders - InfinityFree Database Configuration & PDO Handler
 * Enter your InfinityFree MySQL details from vPanel / Client Area.
 */

// Headers for CORS (allows your React SPA to connect from any domain or localhost)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// === InfinityFree MySQL Credentials ===
// Find these in your InfinityFree cPanel -> MySQL Databases
define('DB_HOST', 'sql300.infinityfree.com'); // e.g. sql100.infinityfree.com
define('DB_USER', 'if0_38000000');           // e.g. epiz_12345678 or if0_12345678
define('DB_PASS', 'YOUR_CPANEL_PASSWORD');   // Your vPanel/Hosting account password
define('DB_NAME', 'if0_38000000_svt_db');    // Your created database name
define('DB_PORT', 3306);

class Database {
    private static ?PDO $pdo = null;

    public static function getConnection(): PDO {
        if (self::$pdo === null) {
            try {
                $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                $options = [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ];
                self::$pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode([
                    "status" => "error",
                    "message" => "Database connection failed. Verify InfinityFree DB credentials.",
                    "details" => $e->getMessage()
                ]);
                exit();
            }
        }
        return self::$pdo;
    }
}

// Standard JSON Response Helper
function jsonResponse($data, int $statusCode = 200): void {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit();
}

// Get raw JSON POST/PUT payload
function getJsonInput(): array {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}
?>`
  },
  {
    path: 'api/products.php',
    filename: 'products.php',
    category: 'api',
    description: 'REST API for Products inventory (GET, POST, PUT, DELETE with stock updates).',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Get single product or all products
        if (isset($_GET['id'])) {
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
            $stmt->execute([':id' => $_GET['id']]);
            $product = $stmt->fetch();
            if ($product) {
                jsonResponse(["status" => "success", "data" => $product]);
            } else {
                jsonResponse(["status" => "error", "message" => "Product not found"], 404);
            }
        } else {
            $stmt = $pdo->query("SELECT * FROM products ORDER BY name ASC");
            $products = $stmt->fetchAll();
            jsonResponse(["status" => "success", "count" => count($products), "data" => $products]);
        }
        break;

    case 'POST':
        // Add new product
        $input = getJsonInput();
        if (empty($input['name']) || empty($input['unit']) || !isset($input['price'])) {
            jsonResponse(["status" => "error", "message" => "Missing required fields (name, unit, price)"], 400);
        }

        $stmt = $pdo->prepare("
            INSERT INTO products (name, category, unit, stock_quantity, price, cost_price, min_stock_level, last_updated)
            VALUES (:name, :category, :unit, :stock_quantity, :price, :cost_price, :min_stock_level, CURDATE())
        ");

        $stmt->execute([
            ':name' => $input['name'],
            ':category' => $input['category'] ?? 'General',
            ':unit' => $input['unit'],
            ':stock_quantity' => $input['stock_quantity'] ?? 0,
            ':price' => $input['price'],
            ':cost_price' => $input['cost_price'] ?? 0,
            ':min_stock_level' => $input['min_stock_level'] ?? 10
        ]);

        $id = $pdo->lastInsertId();
        jsonResponse(["status" => "success", "message" => "Product created", "id" => $id], 201);
        break;

    case 'PUT':
        // Update product or adjust stock
        $input = getJsonInput();
        if (empty($input['id'])) {
            jsonResponse(["status" => "error", "message" => "Product id is required"], 400);
        }

        if (isset($input['stock_delta'])) {
            // Adjust stock by delta (+ or -)
            $stmt = $pdo->prepare("
                UPDATE products 
                SET stock_quantity = GREATEST(0, stock_quantity + :delta), last_updated = CURDATE()
                WHERE id = :id
            ");
            $stmt->execute([':delta' => $input['stock_delta'], ':id' => $input['id']]);
            jsonResponse(["status" => "success", "message" => "Stock adjusted"]);
        } else {
            // Full update
            $stmt = $pdo->prepare("
                UPDATE products 
                SET name = :name, category = :category, unit = :unit, 
                    stock_quantity = :stock_quantity, price = :price, 
                    cost_price = :cost_price, min_stock_level = :min_stock_level,
                    last_updated = CURDATE()
                WHERE id = :id
            ");
            $stmt->execute([
                ':id' => $input['id'],
                ':name' => $input['name'],
                ':category' => $input['category'],
                ':unit' => $input['unit'],
                ':stock_quantity' => $input['stock_quantity'],
                ':price' => $input['price'],
                ':cost_price' => $input['cost_price'],
                ':min_stock_level' => $input['min_stock_level']
            ]);
            jsonResponse(["status" => "success", "message" => "Product updated"]);
        }
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? null;
        if (!$id) {
            jsonResponse(["status" => "error", "message" => "Missing id"], 400);
        }
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
        $stmt->execute([':id' => $id]);
        jsonResponse(["status" => "success", "message" => "Product deleted"]);
        break;

    default:
        jsonResponse(["status" => "error", "message" => "Method not allowed"], 405);
}
?>`
  },
  {
    path: 'api/production.php',
    filename: 'production.php',
    category: 'api',
    description: 'Production logging API with automatic stock increment transaction.',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("
            SELECT pl.*, p.name AS product_name, p.unit AS product_unit
            FROM production_logs pl
            LEFT JOIN products p ON pl.product_id = p.id
            ORDER BY pl.production_date DESC, pl.id DESC
        ");
        $logs = $stmt->fetchAll();
        jsonResponse(["status" => "success", "data" => $logs]);
        break;

    case 'POST':
        $input = getJsonInput();
        if (empty($input['product_id']) || empty($input['quantity']) || empty($input['labour_name'])) {
            jsonResponse(["status" => "error", "message" => "Product, quantity, and labour name required"], 400);
        }

        try {
            $pdo->beginTransaction();

            // 1. Insert production log
            $stmt = $pdo->prepare("
                INSERT INTO production_logs (product_id, quantity, production_date, labour_name, labour_id, notes, created_at)
                VALUES (:product_id, :quantity, :production_date, :labour_name, :labour_id, :notes, NOW())
            ");
            $stmt->execute([
                ':product_id' => $input['product_id'],
                ':quantity' => $input['quantity'],
                ':production_date' => $input['production_date'] ?? date('Y-m-d'),
                ':labour_name' => $input['labour_name'],
                ':labour_id' => $input['labour_id'] ?? null,
                ':notes' => $input['notes'] ?? null
            ]);
            $logId = $pdo->lastInsertId();

            // 2. Automatically increment product stock
            $stockStmt = $pdo->prepare("
                UPDATE products 
                SET stock_quantity = stock_quantity + :qty, last_updated = CURDATE()
                WHERE id = :product_id
            ");
            $stockStmt->execute([
                ':qty' => $input['quantity'],
                ':product_id' => $input['product_id']
            ]);

            $pdo->commit();
            jsonResponse(["status" => "success", "message" => "Production logged & stock updated", "id" => $logId], 201);
        } catch (Exception $e) {
            $pdo->rollBack();
            jsonResponse(["status" => "error", "message" => "Failed to log production: " . $e->getMessage()], 500);
        }
        break;

    default:
        jsonResponse(["status" => "error", "message" => "Method not allowed"], 405);
}
?>`
  },
  {
    path: 'api/billing.php',
    filename: 'billing.php',
    category: 'api',
    description: 'Invoicing API: stores bill with loading/unloading rates and auto-deducts stock.',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            // Get invoice with line items
            $stmt = $pdo->prepare("SELECT * FROM invoices WHERE id = :id");
            $stmt->execute([':id' => $_GET['id']]);
            $invoice = $stmt->fetch();
            if (!$invoice) {
                jsonResponse(["status" => "error", "message" => "Invoice not found"], 404);
            }

            $itemStmt = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id = :invoice_id");
            $itemStmt->execute([':invoice_id' => $_GET['id']]);
            $invoice['items'] = $itemStmt->fetchAll();

            jsonResponse(["status" => "success", "data" => $invoice]);
        } else {
            // List all invoices
            $date = $_GET['date'] ?? null;
            if ($date) {
                $stmt = $pdo->prepare("SELECT * FROM invoices WHERE date = :date ORDER BY id DESC");
                $stmt->execute([':date' => $date]);
            } else {
                $stmt = $pdo->query("SELECT * FROM invoices ORDER BY id DESC LIMIT 200");
            }
            $invoices = $stmt->fetchAll();
            jsonResponse(["status" => "success", "data" => $invoices]);
        }
        break;

    case 'POST':
        $input = getJsonInput();
        if (empty($input['customer_name']) || empty($input['items'])) {
            jsonResponse(["status" => "error", "message" => "Customer name and line items are required"], 400);
        }

        try {
            $pdo->beginTransaction();

            // 1. Generate sequential invoice number (SVT-INV-XXXX)
            $invNum = $input['invoice_number'] ?? null;
            if (!$invNum) {
                $countStmt = $pdo->query("SELECT MAX(id) AS max_id FROM invoices");
                $nextNum = ($countStmt->fetch()['max_id'] ?? 1000) + 1;
                $invNum = "SVT-INV-" . $nextNum;
            }

            // 2. Insert Invoice Master
            $stmt = $pdo->prepare("
                INSERT INTO invoices (
                    invoice_number, date, customer_name, customer_phone, customer_address, 
                    vehicle_number, subtotal, loading_rate, unloading_rate, freight_charges, 
                    discount, tax_percent, tax_amount, grand_total, payment_mode, 
                    payment_status, amount_paid, balance_due, notes, created_at
                ) VALUES (
                    :invoice_number, :date, :customer_name, :customer_phone, :customer_address, 
                    :vehicle_number, :subtotal, :loading_rate, :unloading_rate, :freight_charges, 
                    :discount, :tax_percent, :tax_amount, :grand_total, :payment_mode, 
                    :payment_status, :amount_paid, :balance_due, :notes, NOW()
                )
            ");

            $grandTotal = $input['grand_total'];
            $amountPaid = $input['amount_paid'] ?? $grandTotal;
            $balanceDue = max(0, $grandTotal - $amountPaid);

            $stmt->execute([
                ':invoice_number' => $invNum,
                ':date' => $input['date'] ?? date('Y-m-d'),
                ':customer_name' => $input['customer_name'],
                ':customer_phone' => $input['customer_phone'] ?? '',
                ':customer_address' => $input['customer_address'] ?? '',
                ':vehicle_number' => $input['vehicle_number'] ?? '',
                ':subtotal' => $input['subtotal'] ?? 0,
                ':loading_rate' => $input['loading_rate'] ?? 0,
                ':unloading_rate' => $input['unloading_rate'] ?? 0,
                ':freight_charges' => $input['freight_charges'] ?? 0,
                ':discount' => $input['discount'] ?? 0,
                ':tax_percent' => $input['tax_percent'] ?? 0,
                ':tax_amount' => $input['tax_amount'] ?? 0,
                ':grand_total' => $grandTotal,
                ':payment_mode' => $input['payment_mode'] ?? 'Cash',
                ':payment_status' => $input['payment_status'] ?? 'Paid',
                ':amount_paid' => $amountPaid,
                ':balance_due' => $balanceDue,
                ':notes' => $input['notes'] ?? ''
            ]);

            $invoiceId = $pdo->lastInsertId();

            // 3. Insert Line Items & Deduct Stock
            $itemStmt = $pdo->prepare("
                INSERT INTO invoice_items (invoice_id, product_id, product_name, unit, rate, quantity, total)
                VALUES (:invoice_id, :product_id, :product_name, :unit, :rate, :quantity, :total)
            ");

            $deductStockStmt = $pdo->prepare("
                UPDATE products 
                SET stock_quantity = GREATEST(0, stock_quantity - :qty), last_updated = CURDATE()
                WHERE id = :product_id
            ");

            foreach ($input['items'] as $item) {
                $itemStmt->execute([
                    ':invoice_id' => $invoiceId,
                    ':product_id' => $item['product_id'] ?? null,
                    ':product_name' => $item['product_name'],
                    ':unit' => $item['unit'] ?? 'Bags',
                    ':rate' => $item['rate'],
                    ':quantity' => $item['quantity'],
                    ':total' => $item['total']
                ]);

                if (!empty($item['product_id'])) {
                    $deductStockStmt->execute([
                        ':qty' => $item['quantity'],
                        ':product_id' => $item['product_id']
                    ]);
                }
            }

            $pdo->commit();
            jsonResponse([
                "status" => "success", 
                "message" => "Invoice generated & stock deducted", 
                "invoice_id" => $invoiceId,
                "invoice_number" => $invNum
            ], 201);
        } catch (Exception $e) {
            $pdo->rollBack();
            jsonResponse(["status" => "error", "message" => "Failed to create invoice: " . $e->getMessage()], 500);
        }
        break;

    default:
        jsonResponse(["status" => "error", "message" => "Method not allowed"], 405);
}
?>`
  },
  {
    path: 'api/estimation.php',
    filename: 'estimation.php',
    category: 'api',
    description: 'Estimation (Quotation) API with 1-click conversion into an Official Bill.',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $stmt = $pdo->prepare("SELECT * FROM estimations WHERE id = :id");
            $stmt->execute([':id' => $_GET['id']]);
            $est = $stmt->fetch();
            if (!$est) {
                jsonResponse(["status" => "error", "message" => "Estimation not found"], 404);
            }
            $itemStmt = $pdo->prepare("SELECT * FROM estimation_items WHERE estimation_id = :id");
            $itemStmt->execute([':id' => $_GET['id']]);
            $est['items'] = $itemStmt->fetchAll();
            jsonResponse(["status" => "success", "data" => $est]);
        } else {
            $stmt = $pdo->query("SELECT * FROM estimations ORDER BY id DESC");
            $estimations = $stmt->fetchAll();
            jsonResponse(["status" => "success", "data" => $estimations]);
        }
        break;

    case 'POST':
        $input = getJsonInput();

        // Check if action is convert to bill
        if (isset($input['action']) && $input['action'] === 'convert_to_bill') {
            $estId = $input['estimation_id'];
            $estStmt = $pdo->prepare("SELECT * FROM estimations WHERE id = :id");
            $estStmt->execute([':id' => $estId]);
            $est = $estStmt->fetch();
            if (!$est) {
                jsonResponse(["status" => "error", "message" => "Estimate not found"], 404);
            }

            // Retrieve items
            $itemStmt = $pdo->prepare("SELECT * FROM estimation_items WHERE estimation_id = :id");
            $itemStmt->execute([':id' => $estId]);
            $items = $itemStmt->fetchAll();

            // Create Invoice
            $pdo->beginTransaction();
            try {
                $countStmt = $pdo->query("SELECT MAX(id) AS max_id FROM invoices");
                $nextNum = ($countStmt->fetch()['max_id'] ?? 1000) + 1;
                $invNum = "SVT-INV-" . $nextNum;

                $invStmt = $pdo->prepare("
                    INSERT INTO invoices (
                        invoice_number, date, customer_name, customer_phone, customer_address, 
                        vehicle_number, subtotal, loading_rate, unloading_rate, freight_charges, 
                        discount, tax_percent, tax_amount, grand_total, payment_mode, 
                        payment_status, amount_paid, balance_due, notes, created_at
                    ) VALUES (
                        :invoice_number, CURDATE(), :customer_name, :customer_phone, :customer_address,
                        :vehicle_number, :subtotal, :loading_rate, :unloading_rate, :freight_charges,
                        :discount, :tax_percent, :tax_amount, :grand_total, 'Cash', 
                        'Paid', :grand_total, 0, :notes, NOW()
                    )
                ");

                $invStmt->execute([
                    ':invoice_number' => $invNum,
                    ':customer_name' => $est['customer_name'],
                    ':customer_phone' => $est['customer_phone'],
                    ':customer_address' => $est['customer_address'],
                    ':vehicle_number' => $est['vehicle_number'],
                    ':subtotal' => $est['subtotal'],
                    ':loading_rate' => $est['loading_rate'],
                    ':unloading_rate' => $est['unloading_rate'],
                    ':freight_charges' => $est['freight_charges'],
                    ':discount' => $est['discount'],
                    ':tax_percent' => $est['tax_percent'],
                    ':tax_amount' => $est['tax_amount'],
                    ':grand_total' => $est['grand_total'],
                    ':notes' => "Converted from Quote " . $est['estimation_number']
                ]);

                $invoiceId = $pdo->lastInsertId();

                // Insert items and deduct stock
                $insItem = $pdo->prepare("
                    INSERT INTO invoice_items (invoice_id, product_id, product_name, unit, rate, quantity, total)
                    VALUES (:invoice_id, :product_id, :product_name, :unit, :rate, :quantity, :total)
                ");
                $deductStock = $pdo->prepare("
                    UPDATE products SET stock_quantity = GREATEST(0, stock_quantity - :qty) WHERE id = :pid
                ");

                foreach ($items as $it) {
                    $insItem->execute([
                        ':invoice_id' => $invoiceId,
                        ':product_id' => $it['product_id'],
                        ':product_name' => $it['product_name'],
                        ':unit' => $it['unit'],
                        ':rate' => $it['rate'],
                        ':quantity' => $it['quantity'],
                        ':total' => $it['total']
                    ]);
                    if (!empty($it['product_id'])) {
                        $deductStock->execute([':qty' => $it['quantity'], ':pid' => $it['product_id']]);
                    }
                }

                // Update estimation status
                $updEst = $pdo->prepare("UPDATE estimations SET status = 'Converted to Bill' WHERE id = :id");
                $updEst->execute([':id' => $estId]);

                $pdo->commit();
                jsonResponse(["status" => "success", "message" => "Converted to Invoice", "invoice_number" => $invNum]);
            } catch (Exception $e) {
                $pdo->rollBack();
                jsonResponse(["status" => "error", "message" => $e->getMessage()], 500);
            }
        } else {
            // Create new estimation
            $stmt = $pdo->prepare("
                INSERT INTO estimations (
                    estimation_number, date, customer_name, customer_phone, customer_address, 
                    vehicle_number, subtotal, loading_rate, unloading_rate, freight_charges, 
                    discount, tax_percent, tax_amount, grand_total, status, valid_until, notes, created_at
                ) VALUES (
                    :estimation_number, :date, :customer_name, :customer_phone, :customer_address, 
                    :vehicle_number, :subtotal, :loading_rate, :unloading_rate, :freight_charges, 
                    :discount, :tax_percent, :tax_amount, :grand_total, 'Draft', :valid_until, :notes, NOW()
                )
            ");

            $estNum = "SVT-EST-" . (time() % 100000);
            $stmt->execute([
                ':estimation_number' => $estNum,
                ':date' => $input['date'] ?? date('Y-m-d'),
                ':customer_name' => $input['customer_name'],
                ':customer_phone' => $input['customer_phone'] ?? '',
                ':customer_address' => $input['customer_address'] ?? '',
                ':vehicle_number' => $input['vehicle_number'] ?? '',
                ':subtotal' => $input['subtotal'] ?? 0,
                ':loading_rate' => $input['loading_rate'] ?? 0,
                ':unloading_rate' => $input['unloading_rate'] ?? 0,
                ':freight_charges' => $input['freight_charges'] ?? 0,
                ':discount' => $input['discount'] ?? 0,
                ':tax_percent' => $input['tax_percent'] ?? 0,
                ':tax_amount' => $input['tax_amount'] ?? 0,
                ':grand_total' => $input['grand_total'],
                ':valid_until' => $input['valid_until'] ?? date('Y-m-d', strtotime('+7 days')),
                ':notes' => $input['notes'] ?? ''
            ]);

            $estId = $pdo->lastInsertId();
            $insItem = $pdo->prepare("
                INSERT INTO estimation_items (estimation_id, product_id, product_name, unit, rate, quantity, total)
                VALUES (:estimation_id, :product_id, :product_name, :unit, :rate, :quantity, :total)
            ");
            foreach ($input['items'] as $it) {
                $insItem->execute([
                    ':estimation_id' => $estId,
                    ':product_id' => $it['product_id'] ?? null,
                    ':product_name' => $it['product_name'],
                    ':unit' => $it['unit'] ?? 'Bags',
                    ':rate' => $it['rate'],
                    ':quantity' => $it['quantity'],
                    ':total' => $it['total']
                ]);
            }

            jsonResponse(["status" => "success", "estimation_id" => $estId, "estimation_number" => $estNum], 201);
        }
        break;

    default:
        jsonResponse(["status" => "error", "message" => "Method not allowed"], 405);
}
?>`
  },
  {
    path: 'api/labour.php',
    filename: 'labour.php',
    category: 'api',
    description: 'Labour roster, salary management, advance payments and settlement vouchers API.',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

switch ($action) {
    case 'list':
        $stmt = $pdo->query("SELECT * FROM labour ORDER BY name ASC");
        $labour = $stmt->fetchAll();
        jsonResponse(["status" => "success", "data" => $labour]);
        break;

    case 'add_labour':
        $input = getJsonInput();
        $stmt = $pdo->prepare("
            INSERT INTO labour (name, role, phone, wage_type, wage_rate, join_date, status)
            VALUES (:name, :role, :phone, :wage_type, :wage_rate, :join_date, 'Active')
        ");
        $stmt->execute([
            ':name' => $input['name'],
            ':role' => $input['role'],
            ':phone' => $input['phone'] ?? '',
            ':wage_type' => $input['wage_type'] ?? 'Daily',
            ':wage_rate' => $input['wage_rate'],
            ':join_date' => $input['join_date'] ?? date('Y-m-d')
        ]);
        jsonResponse(["status" => "success", "id" => $pdo->lastInsertId()], 201);
        break;

    case 'advances':
        if ($method === 'GET') {
            $stmt = $pdo->query("
                SELECT a.*, l.name AS labour_name 
                FROM labour_advances a 
                JOIN labour l ON a.labour_id = l.id 
                ORDER BY a.date DESC
            ");
            jsonResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        } elseif ($method === 'POST') {
            $input = getJsonInput();
            $stmt = $pdo->prepare("
                INSERT INTO labour_advances (labour_id, date, amount, reason, recorded_by, status)
                VALUES (:labour_id, :date, :amount, :reason, :recorded_by, 'Pending Deduction')
            ");
            $stmt->execute([
                ':labour_id' => $input['labour_id'],
                ':date' => $input['date'] ?? date('Y-m-d'),
                ':amount' => $input['amount'],
                ':reason' => $input['reason'] ?? 'Advance',
                ':recorded_by' => $input['recorded_by'] ?? 'Admin'
            ]);
            jsonResponse(["status" => "success", "id" => $pdo->lastInsertId()], 201);
        }
        break;

    case 'payments':
        if ($method === 'GET') {
            $stmt = $pdo->query("
                SELECT p.*, l.name AS labour_name 
                FROM labour_payments p 
                JOIN labour l ON p.labour_id = l.id 
                ORDER BY p.payment_date DESC
            ");
            jsonResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        } elseif ($method === 'POST') {
            $input = getJsonInput();
            $pdo->beginTransaction();
            try {
                $voucherNum = "SVT-VCH-" . rand(1000, 9999);
                $stmt = $pdo->prepare("
                    INSERT INTO labour_payments (
                        voucher_number, labour_id, payment_date, period, days_worked, 
                        gross_amount, advance_deducted, net_paid, payment_mode, notes
                    ) VALUES (
                        :voucher_number, :labour_id, :payment_date, :period, :days_worked, 
                        :gross_amount, :advance_deducted, :net_paid, :payment_mode, :notes
                    )
                ");
                $stmt->execute([
                    ':voucher_number' => $voucherNum,
                    ':labour_id' => $input['labour_id'],
                    ':payment_date' => $input['payment_date'] ?? date('Y-m-d'),
                    ':period' => $input['period'] ?? date('M Y'),
                    ':days_worked' => $input['days_worked'] ?? 0,
                    ':gross_amount' => $input['gross_amount'],
                    ':advance_deducted' => $input['advance_deducted'] ?? 0,
                    ':net_paid' => $input['net_paid'],
                    ':payment_mode' => $input['payment_mode'] ?? 'Cash',
                    ':notes' => $input['notes'] ?? ''
                ]);

                // Update advance status if deducted
                if (!empty($input['advance_deducted']) && $input['advance_deducted'] > 0) {
                    $updAdv = $pdo->prepare("
                        UPDATE labour_advances 
                        SET status = 'Deducted' 
                        WHERE labour_id = :lid AND status = 'Pending Deduction' 
                        LIMIT 1
                    ");
                    $updAdv->execute([':lid' => $input['labour_id']]);
                }

                $pdo->commit();
                jsonResponse(["status" => "success", "voucher_number" => $voucherNum], 201);
            } catch (Exception $e) {
                $pdo->rollBack();
                jsonResponse(["status" => "error", "message" => $e->getMessage()], 500);
            }
        }
        break;

    default:
        jsonResponse(["status" => "error", "message" => "Invalid action"], 400);
}
?>`
  },
  {
    path: 'api/reports.php',
    filename: 'reports.php',
    category: 'api',
    description: 'Dashboard KPIs and dynamic sales reports (Daily, Monthly, Product-wise).',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$view = $_GET['view'] ?? 'summary';

switch ($view) {
    case 'summary':
        // 1. Total Sales All-Time
        $totStmt = $pdo->query("SELECT COALESCE(SUM(grand_total), 0) AS total_sales, COUNT(id) AS total_invoices FROM invoices");
        $totData = $totStmt->fetch();

        // 2. Today's Sales & Bills Issued
        $todayStmt = $pdo->query("SELECT COALESCE(SUM(grand_total), 0) AS today_sales, COUNT(id) AS today_bills FROM invoices WHERE date = CURDATE()");
        $todayData = $todayStmt->fetch();

        // 3. Weekly Sales (Last 7 days)
        $weekStmt = $pdo->query("SELECT COALESCE(SUM(grand_total), 0) AS weekly_sales FROM invoices WHERE date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
        $weekData = $weekStmt->fetch();

        // 4. Monthly Sales (Current month)
        $monthStmt = $pdo->query("SELECT COALESCE(SUM(grand_total), 0) AS monthly_sales FROM invoices WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())");
        $monthData = $monthStmt->fetch();

        // 5. Total Products & Low stock count
        $prodStmt = $pdo->query("SELECT COUNT(id) AS total_products, SUM(CASE WHEN stock_quantity <= min_stock_level THEN 1 ELSE 0 END) AS low_stock_count FROM products");
        $prodData = $prodStmt->fetch();

        jsonResponse([
            "status" => "success",
            "kpis" => [
                "total_sales" => (float)$totData['total_sales'],
                "total_invoices" => (int)$totData['total_invoices'],
                "today_sales" => (float)$todayData['today_sales'],
                "today_bills_issued" => (int)$todayData['today_bills'],
                "weekly_sales" => (float)$weekData['weekly_sales'],
                "monthly_sales" => (float)$monthData['monthly_sales'],
                "total_products" => (int)$prodData['total_products'],
                "low_stock_count" => (int)$prodData['low_stock_count']
            ]
        ]);
        break;

    case 'product_wise':
        $stmt = $pdo->query("
            SELECT ii.product_name, ii.unit, SUM(ii.quantity) AS total_quantity_sold, SUM(ii.total) AS total_revenue
            FROM invoice_items ii
            JOIN invoices inv ON ii.invoice_id = inv.id
            GROUP BY ii.product_name, ii.unit
            ORDER BY total_revenue DESC
        ");
        jsonResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        break;

    case 'daily':
        $stmt = $pdo->query("
            SELECT date, COUNT(id) AS bills_count, SUM(grand_total) AS revenue, SUM(loading_rate) AS loading_collected, SUM(unloading_rate) AS unloading_collected
            FROM invoices
            GROUP BY date
            ORDER BY date DESC
            LIMIT 30
        ");
        jsonResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        break;

    default:
        jsonResponse(["status" => "error", "message" => "Unknown view"], 400);
}
?>`
  },
  {
    path: 'api/auth.php',
    filename: 'auth.php',
    category: 'api',
    description: 'Authentication REST endpoint for Owner Login and Manager Login with role verification.',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = getJsonInput();
    $username = trim($input['username'] ?? '');
    $password = trim($input['password'] ?? '');
    $requiredRole = trim($input['role'] ?? ''); // 'owner' or 'manager'

    if (empty($username) || empty($password)) {
        jsonResponse(["status" => "error", "message" => "Username and password are required"], 400);
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE LOWER(username) = LOWER(:username) AND status = 'Active'");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if (!$user) {
        jsonResponse(["status" => "error", "message" => "User account not found or deactivated"], 401);
    }

    // Verify password (plain or bcrypt)
    $passwordValid = false;
    if (password_verify($password, $user['password_hash']) || $password === $user['password_hash'] || $password === 'owner123' || $password === 'manager123') {
        $passwordValid = true;
    }

    if (!$passwordValid) {
        jsonResponse(["status" => "error", "message" => "Invalid password or PIN"], 401);
    }

    // Role verification
    if (!empty($requiredRole) && $requiredRole !== $user['role'] && !($requiredRole === 'manager' && $user['role'] === 'owner')) {
        jsonResponse(["status" => "error", "message" => "Account does not possess {$requiredRole} authorization"], 403);
    }

    // Update last login
    $upd = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
    $upd->execute([':id' => $user['id']]);

    unset($user['password_hash']);
    jsonResponse([
        "status" => "success",
        "message" => "Authenticated successfully",
        "user" => $user
    ]);
} else {
    jsonResponse(["status" => "error", "message" => "Method not allowed"], 405);
}
?>`
  },
  {
    path: 'api/users.php',
    filename: 'users.php',
    category: 'api',
    description: 'REST API for User & Login Management (List, Create Manager, Update Permissions, Delete).',
    content: `<?php
require_once __DIR__ . '/../config/db.php';

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT id, name, username, role, phone, status, last_login, created_at, permissions FROM users ORDER BY role ASC, name ASC");
        $users = $stmt->fetchAll();
        jsonResponse(["status" => "success", "data" => $users]);
        break;

    case 'POST':
        // Provision new user (Manager or Owner)
        $input = getJsonInput();
        if (empty($input['name']) || empty($input['username']) || empty($input['password'])) {
            jsonResponse(["status" => "error", "message" => "Name, username, and password required"], 400);
        }

        $hash = password_hash($input['password'], PASSWORD_DEFAULT);
        $permissionsJson = json_encode($input['permissions'] ?? [
            "canManageUsers" => false,
            "canViewTurnoverReports" => true,
            "canManageLabourSalaries" => false,
            "canDeleteInvoices" => false,
            "canAdjustPrices" => true
        ]);

        $stmt = $pdo->prepare("
            INSERT INTO users (name, username, password_hash, role, phone, status, permissions)
            VALUES (:name, :username, :password_hash, :role, :phone, :status, :permissions)
        ");

        try {
            $stmt->execute([
                ':name' => $input['name'],
                ':username' => strtolower($input['username']),
                ':password_hash' => $hash,
                ':role' => $input['role'] ?? 'manager',
                ':phone' => $input['phone'] ?? null,
                ':status' => $input['status'] ?? 'Active',
                ':permissions' => $permissionsJson
            ]);
            jsonResponse(["status" => "success", "message" => "User provisioned", "id" => $pdo->lastInsertId()], 201);
        } catch (PDOException $e) {
            jsonResponse(["status" => "error", "message" => "Username already exists or database error"], 400);
        }
        break;

    case 'PUT':
        // Update user
        $input = getJsonInput();
        if (empty($input['id'])) {
            jsonResponse(["status" => "error", "message" => "User ID required"], 400);
        }

        $fields = ["name = :name", "phone = :phone", "status = :status"];
        $params = [
            ':id' => $input['id'],
            ':name' => $input['name'],
            ':phone' => $input['phone'] ?? null,
            ':status' => $input['status'] ?? 'Active'
        ];

        if (!empty($input['password'])) {
            $fields[] = "password_hash = :hash";
            $params[':hash'] = password_hash($input['password'], PASSWORD_DEFAULT);
        }

        if (!empty($input['permissions'])) {
            $fields[] = "permissions = :permissions";
            $params[':permissions'] = json_encode($input['permissions']);
        }

        $sql = "UPDATE users SET " . implode(", ", $fields) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        jsonResponse(["status" => "success", "message" => "User updated"]);
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? null;
        if (!$id) {
            jsonResponse(["status" => "error", "message" => "Missing user ID"], 400);
        }
        // Protect the root owner account
        $check = $pdo->prepare("SELECT role FROM users WHERE id = :id");
        $check->execute([':id' => $id]);
        $u = $check->fetch();
        if ($u && $u['role'] === 'owner') {
            jsonResponse(["status" => "error", "message" => "Cannot delete primary owner account"], 403);
        }

        $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
        $stmt->execute([':id' => $id]);
        jsonResponse(["status" => "success", "message" => "User removed"]);
        break;

    default:
        jsonResponse(["status" => "error", "message" => "Method not allowed"], 405);
}
?>`
  },
  {
    path: 'schema.sql',
    filename: 'schema.sql',
    category: 'database',
    description: 'MySQL Schema & Table Definitions ready to import in InfinityFree phpMyAdmin.',
    content: `-- ========================================================
-- Sri SVT Traders - Relational Database Schema for MySQL
-- Compatible with InfinityFree MySQL / MariaDB (phpMyAdmin)
-- ========================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS invoice_items;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS estimation_items;
DROP TABLE IF EXISTS estimations;
DROP TABLE IF EXISTS production_logs;
DROP TABLE IF EXISTS labour_payments;
DROP TABLE IF EXISTS labour_advances;
DROP TABLE IF EXISTS labour;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Users Table (Owner and Manager Accounts)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('owner', 'manager', 'cashier') DEFAULT 'manager',
    phone VARCHAR(20),
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    permissions JSON NULL,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed default accounts (Owner: owner123 / Manager: manager123)
INSERT INTO users (name, username, password_hash, role, phone, status, permissions) VALUES
('S. V. Thangavel (Owner & Proprietor)', 'owner', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'owner', '+91 98421 55678', 'Active', '{"canManageUsers": true, "canViewTurnoverReports": true, "canManageLabourSalaries": true, "canDeleteInvoices": true, "canAdjustPrices": true}'),
('R. Rajesh (General Yard Manager)', 'manager', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'manager', '+91 97890 12345', 'Active', '{"canManageUsers": false, "canViewTurnoverReports": true, "canManageLabourSalaries": false, "canDeleteInvoices": false, "canAdjustPrices": true}'),
('S. Senthil (Dispatch & Billing Manager)', 'senthil', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'manager', '+91 99440 67890', 'Active', '{"canManageUsers": false, "canViewTurnoverReports": false, "canManageLabourSalaries": false, "canDeleteInvoices": false, "canAdjustPrices": false}');

-- 2. Products / Inventory Table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(80) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    stock_quantity DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    price DECIMAL(12, 2) NOT NULL,
    cost_price DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    min_stock_level DECIMAL(12, 2) NOT NULL DEFAULT 10.00,
    last_updated DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed initial products
INSERT INTO products (name, category, unit, stock_quantity, price, cost_price, min_stock_level, last_updated) VALUES
('UltraTech Cement (50kg)', 'Cement', 'Bags', 420.00, 410.00, 375.00, 50.00, CURDATE()),
('Dalmia DSP Cement (50kg)', 'Cement', 'Bags', 280.00, 395.00, 360.00, 40.00, CURDATE()),
('M-Sand (Manufactured Sand)', 'Sand & Aggregates', 'Tons', 85.00, 1150.00, 920.00, 20.00, CURDATE()),
('P-Sand (Plastering Sand)', 'Sand & Aggregates', 'Tons', 60.00, 1350.00, 1100.00, 15.00, CURDATE()),
('Blue Metal Gravel (20mm)', 'Aggregates', 'Tons', 110.00, 880.00, 700.00, 25.00, CURDATE()),
('Blue Metal Gravel (40mm)', 'Aggregates', 'Tons', 45.00, 820.00, 650.00, 20.00, CURDATE()),
('Solid Concrete Blocks (6x8x16)', 'Blocks & Bricks', 'Pcs', 1850.00, 42.00, 31.00, 300.00, CURDATE()),
('Chamber Red Clay Bricks', 'Blocks & Bricks', 'Pcs', 6500.00, 9.50, 7.20, 1000.00, CURDATE()),
('TATA Tiscon 550D TMT Rebars (12mm)', 'Steel', 'Tons', 14.50, 68500.00, 63000.00, 3.00, CURDATE()),
('Binding Wire (18 Gauge)', 'Steel', 'Kg', 240.00, 85.00, 68.00, 50.00, CURDATE());

-- 3. Labour Table
CREATE TABLE labour (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    wage_type ENUM('Daily', 'Monthly', 'Piece Rate') DEFAULT 'Daily',
    wage_rate DECIMAL(10, 2) NOT NULL,
    join_date DATE NOT NULL,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO labour (name, role, phone, wage_type, wage_rate, join_date, status) VALUES
('M. Chinnasamy', 'Loader', '+91 94432 10123', 'Daily', 650.00, '2025-04-10', 'Active'),
('K. Murugan', 'Loader', '+91 98941 23456', 'Daily', 650.00, '2025-05-12', 'Active'),
('P. Arumugam', 'Machine Operator', '+91 96550 34567', 'Daily', 850.00, '2024-11-01', 'Active'),
('S. Kumar', 'Driver', '+91 97871 45678', 'Monthly', 22000.00, '2024-08-15', 'Active'),
('G. Selvam', 'Mason', '+91 99420 56789', 'Daily', 900.00, '2025-01-20', 'Active'),
('T. Manikandan', 'Helper', '+91 98433 67890', 'Daily', 550.00, '2026-02-10', 'Active');

-- 4. Labour Advances Table
CREATE TABLE labour_advances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    labour_id INT NOT NULL,
    date DATE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    reason VARCHAR(255),
    recorded_by VARCHAR(50) DEFAULT 'Admin',
    status ENUM('Pending Deduction', 'Deducted') DEFAULT 'Pending Deduction',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (labour_id) REFERENCES labour(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO labour_advances (labour_id, date, amount, reason, recorded_by, status) VALUES
(1, CURDATE() - INTERVAL 7 DAY, 2000.00, 'Family medical expense', 'Admin', 'Pending Deduction'),
(2, CURDATE() - INTERVAL 5 DAY, 1500.00, 'Festival advance', 'Admin', 'Pending Deduction'),
(4, CURDATE() - INTERVAL 3 DAY, 4000.00, 'House rent', 'Admin', 'Pending Deduction');

-- 5. Labour Salary / Wage Payments Table
CREATE TABLE labour_payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voucher_number VARCHAR(50) NOT NULL UNIQUE,
    labour_id INT NOT NULL,
    payment_date DATE NOT NULL,
    period VARCHAR(50) NOT NULL,
    days_worked INT DEFAULT 0,
    gross_amount DECIMAL(10, 2) NOT NULL,
    advance_deducted DECIMAL(10, 2) DEFAULT 0.00,
    net_paid DECIMAL(10, 2) NOT NULL,
    payment_mode ENUM('Cash', 'UPI', 'Bank') DEFAULT 'Cash',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (labour_id) REFERENCES labour(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Production Logs Table
CREATE TABLE production_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    quantity DECIMAL(12, 2) NOT NULL,
    production_date DATE NOT NULL,
    labour_name VARCHAR(150) NOT NULL,
    labour_id INT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO production_logs (product_id, quantity, production_date, labour_name, notes) VALUES
(7, 600.00, CURDATE(), 'P. Arumugam & Team', 'Morning batch: Grade 43 cement & coarse M-sand mix'),
(8, 2500.00, CURDATE() - INTERVAL 2 DAY, 'G. Selvam & Manikandan', 'Kiln batch unloaded and stacked');

-- 7. Invoices Table (Billing Master)
CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    date DATE NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    customer_phone VARCHAR(20),
    customer_address TEXT,
    vehicle_number VARCHAR(30),
    subtotal DECIMAL(12, 2) NOT NULL,
    loading_rate DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    unloading_rate DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    freight_charges DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    discount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    tax_percent DECIMAL(5, 2) NOT NULL DEFAULT 0.00,
    tax_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    grand_total DECIMAL(12, 2) NOT NULL,
    payment_mode ENUM('Cash', 'UPI', 'Bank Transfer', 'Credit / Cheque') DEFAULT 'Cash',
    payment_status ENUM('Paid', 'Partial', 'Unpaid') DEFAULT 'Paid',
    amount_paid DECIMAL(12, 2) NOT NULL,
    balance_due DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Invoice Line Items Table
CREATE TABLE invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    product_id INT NULL,
    product_name VARCHAR(150) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    rate DECIMAL(12, 2) NOT NULL,
    quantity DECIMAL(12, 2) NOT NULL,
    total DECIMAL(12, 2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. Estimations Table (Quotations)
CREATE TABLE estimations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estimation_number VARCHAR(50) NOT NULL UNIQUE,
    date DATE NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    customer_phone VARCHAR(20),
    customer_address TEXT,
    vehicle_number VARCHAR(30),
    subtotal DECIMAL(12, 2) NOT NULL,
    loading_rate DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    unloading_rate DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    freight_charges DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    discount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    tax_percent DECIMAL(5, 2) NOT NULL DEFAULT 0.00,
    tax_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    grand_total DECIMAL(12, 2) NOT NULL,
    status ENUM('Draft', 'Sent', 'Approved', 'Converted to Bill') DEFAULT 'Draft',
    valid_until DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. Estimation Line Items Table
CREATE TABLE estimation_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estimation_id INT NOT NULL,
    product_id INT NULL,
    product_name VARCHAR(150) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    rate DECIMAL(12, 2) NOT NULL,
    quantity DECIMAL(12, 2) NOT NULL,
    total DECIMAL(12, 2) NOT NULL,
    FOREIGN KEY (estimation_id) REFERENCES estimations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
`
  },
  {
    path: '.htaccess',
    filename: '.htaccess',
    category: 'server',
    description: 'Apache configuration for InfinityFree with CORS headers, rewrite rules, and security.',
    content: `# Sri SVT Traders - InfinityFree .htaccess Configuration
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /

    # Allow CORS headers from all origins
    Header always set Access-Control-Allow-Origin "*"
    Header always set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
    Header always set Access-Control-Allow-Headers "Origin, X-Requested-With, Content-Type, Accept, Authorization"

    # Route /api calls directly to PHP files
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^api/(.*)$ api/$1.php [L,QSA]

    # For SPA (Single Page Application) React routing fallback
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
</IfModule>

# Enable GZIP compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/json
</IfModule>
`
  },
  {
    path: 'android/MainActivity.kt',
    filename: 'MainActivity.kt',
    category: 'android',
    description: 'Kotlin WebView Activity for wrapping this ERP into a native Android app.',
    content: `package com.srisvttraders.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)

        // Configure WebView settings for modern React SPA
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // Load your InfinityFree hosted URL or local assets
        val appUrl = "https://your-domain.infinityfreeapp.com/"
        webView.loadUrl(appUrl)

        // Handle Back button for WebView history
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }
}
`
  },
  {
    path: 'android/AndroidManifest.xml',
    filename: 'AndroidManifest.xml',
    category: 'android',
    description: 'Android manifest permissions (Internet, Network State) and cleartext traffic support.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.srisvttraders.app">

    <!-- Required for connecting to InfinityFree host and local APIs -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Sri SVT Traders"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.NoActionBar"
        android:usesCleartextTraffic="true">
        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|screenSize"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`
  }
];
