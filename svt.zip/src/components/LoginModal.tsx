import React, { useState } from 'react';
import { User, Role } from '../types';
import { Shield, KeyRound, UserCheck, Lock, Building2, Check, ArrowRight } from 'lucide-react';

interface Props {
  users: User[];
  currentUser: User;
  onSelectUser: (user: User) => void;
  onClose: () => void;
}

export const LoginModal: React.FC<Props> = ({ users, currentUser, onSelectUser, onClose }) => {
  const [activeTab, setActiveTab] = useState<'owner' | 'manager'>('owner');
  const [username, setUsername] = useState('owner');
  const [password, setPassword] = useState('owner123');
  const [error, setError] = useState('');

  const owners = users.filter((u) => u.role === 'owner');
  const managers = users.filter((u) => u.role === 'manager');

  const handleTabChange = (tab: 'owner' | 'manager') => {
    setActiveTab(tab);
    setError('');
    if (tab === 'owner') {
      setUsername('owner');
      setPassword('owner123');
    } else {
      setUsername('manager');
      setPassword('manager123');
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const matched = users.find((u) => u.username.toLowerCase() === username.toLowerCase());
    if (!matched) {
      setError('User not found.');
      return;
    }
    if (matched.password && matched.password !== password) {
      setError('Incorrect password or PIN.');
      return;
    }
    onSelectUser(matched);
    onClose();
  };

  const handleQuickSelect = (u: User) => {
    onSelectUser(u);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="p-5 bg-slate-900 text-white text-center border-b border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-amber-400 font-bold uppercase">Sri SVT Traders</span>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white text-sm font-bold"
            >
              ✕
            </button>
          </div>
          <h2 className="text-base font-bold tracking-tight">Switch / Authorize User Session</h2>
          <p className="text-xs text-slate-400 mt-0.5">Select Owner or Manager portal</p>
        </div>

        {/* Tab selection */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-100 border-b border-slate-200 text-xs">
          <button
            type="button"
            onClick={() => handleTabChange('owner')}
            className={`py-2 px-3 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'owner'
                ? 'bg-amber-500 text-slate-950 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Owner Portal</span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('manager')}
            className={`py-2 px-3 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'manager'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Manager Portal</span>
          </button>
        </div>

        {/* 1-Click Profile List */}
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <p className="text-[11px] font-semibold text-slate-500 mb-2 uppercase tracking-wide">
            {activeTab === 'owner' ? 'Registered Owners:' : 'Registered Managers:'}
          </p>

          <div className="space-y-1.5">
            {(activeTab === 'owner' ? owners : managers).map((u) => {
              const isCurrent = u.id === currentUser.id;
              return (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => handleQuickSelect(u)}
                  className={`w-full p-2.5 rounded-lg text-left text-xs flex items-center justify-between border transition-all ${
                    isCurrent
                      ? 'bg-amber-50 border-amber-300 text-slate-950 font-semibold'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs uppercase shrink-0 ${
                        u.role === 'owner' ? 'bg-amber-500 text-slate-950' : 'bg-blue-600 text-white'
                      }`}
                    >
                      {u.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-900">{u.name}</p>
                      <p className="text-[10px] text-slate-500 font-mono">@{u.username} · {u.role}</p>
                    </div>
                  </div>

                  {isCurrent ? (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      Active
                    </span>
                  ) : (
                    <span className="text-[11px] text-slate-500 font-medium hover:text-slate-900">
                      Switch →
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Credentials Form */}
        <form onSubmit={handleLogin} className="p-4 space-y-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Username</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 font-mono"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Password / PIN</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded-lg focus:outline-hidden focus:border-amber-500 font-mono"
            />
          </div>

          {error && <p className="text-rose-600 text-[11px] font-medium">{error}</p>}

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 border border-slate-300 rounded-lg font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-4 py-1.5 rounded-lg font-bold shadow-xs text-xs transition-colors ${
                activeTab === 'owner'
                  ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }`}
            >
              Authorize Sign-In
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
