import React from 'react';
import { ActiveTab, User } from '../types';
import { Plus, Menu, LogOut } from 'lucide-react';

interface Props {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  currentUser: User;
  onOpenNewBill: () => void;
  onToggleMobileMenu: () => void;
  onLogout: () => void;
  apiMode: 'local' | 'infinityfree';
}

export const Header: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenNewBill,
  onToggleMobileMenu,
  onLogout,
}) => {
  const isOwner = currentUser.role === 'owner';

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
      <div className="flex items-center justify-between gap-2 sm:gap-6 px-3 sm:px-6 py-2.5 sm:py-3 max-w-7xl mx-auto">
        {/* Zone 1: Mobile Hamburger & Brand Wordmark */}
        <div className="flex items-center gap-1.5 sm:gap-3 min-w-0 shrink">
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-1.5 text-slate-700 hover:text-slate-950 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer shrink-0"
            aria-label="Toggle Navigation Menu"
          >
            <Menu className="w-5 h-5 stroke-[2.2]" />
          </button>

          <button
            onClick={() => setActiveTab('dashboard')}
            className="text-left group cursor-pointer focus-visible:outline-hidden min-w-0"
          >
            <div className="flex items-center gap-1.5">
              <span className="text-sm sm:text-lg font-bold tracking-tight text-slate-950 truncate group-hover:text-amber-600 transition-colors">
                ஸ்ரீ வெங்கடேஸ்வரா
              </span>
              <span className="hidden sm:inline-block text-xs font-semibold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                SVT
              </span>
            </div>
            <p className="text-[10px] text-slate-500 truncate hidden xs:block">
              காஞ்சிபுரம் · 958578 1947
            </p>
          </button>
        </div>

        {/* Zone 2: Contextual View Indicator (Desktop) */}
        <div className="hidden lg:flex items-center gap-2 text-xs text-slate-500 font-medium">
          <span className="font-semibold text-slate-700">SRI SVT TRADERS</span>
          <span className="text-slate-300">/</span>
          <span className="text-slate-950 font-bold uppercase tracking-wider text-[11px] bg-slate-100 px-2 py-0.5 rounded">
            {activeTab === 'dashboard' && 'Dashboard Overview'}
            {activeTab === 'products' && 'Products & Stock'}
            {activeTab === 'raw-material-inbound' && 'Raw Material Inbound (வரவு)'}
            {activeTab === 'production' && 'Production Management'}
            {activeTab === 'billing' && 'Billing & Invoicing'}
            {activeTab === 'estimation' && 'Estimation Quotations'}
            {activeTab === 'sales-report' && 'Sales Reports'}
            {activeTab === 'labour-salary' && 'Labour & Salary'}
            {activeTab === 'login-management' && 'Login Management'}
          </span>
        </div>

        {/* Zone 3: Primary Action, Role Badge & Logout */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          {/* Active Role Badge */}
          <button
            onClick={() => setActiveTab('login-management')}
            className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
              isOwner
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-blue-50 border-blue-200 text-blue-900'
            }`}
            title="Click to view Login Management"
          >
            {isOwner ? (
              <>
                <span>👑</span>
                <span className="font-mono">Owner</span>
              </>
            ) : (
              <>
                <span>📋</span>
                <span className="font-mono">Manager</span>
              </>
            )}
          </button>

          <button
            onClick={onOpenNewBill}
            className="inline-flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg shadow-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2.5]" />
            <span>New Bill</span>
          </button>

          <button
            onClick={onLogout}
            className="inline-flex items-center gap-1 px-2 sm:px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-rose-600 border border-slate-200 hover:border-rose-200 hover:bg-rose-50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            title="Sign out of current account"
          >
            <LogOut className="w-3.5 h-3.5 sm:hidden" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </div>
    </header>
  );
};
